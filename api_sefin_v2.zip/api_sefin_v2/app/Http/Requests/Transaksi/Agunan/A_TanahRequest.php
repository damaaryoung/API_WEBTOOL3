<?php

namespace App\Http\Requests\Transaksi\Agunan;

use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Http\JsonResponse;
use Urameshibr\Requests\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Validation\ValidationException;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Foundation\Http\FormRequest as LaravelFormRequest;

class A_TanahRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules(Request $request)
    {
        $segment = $request->segment(4);

        if ($segment == 'update') {
            $star = '';
        }else{
            $star = '.*';
        }
        
        $rules = [
            'tipe_lokasi_agunan'.$star   => 'in:PERUM,BIASA',
            'rt_agunan'.$star            => 'numeric',
            'rw_agunan'.$star            => 'numeric',
            'luas_tanah'.$star           => 'numeric',
            'luas_bangunan'.$star        => 'numeric',
            'jenis_sertifikat'.$star     => 'in:SHM,SHGB',
            'agunan_bag_depan'.$star     => 'mimes:jpg,jpeg,png,pdf',
            'agunan_bag_jalan'.$star     => 'mimes:jpg,jpeg,png,pdf',
            'agunan_bag_ruangtamu'.$star => 'mimes:jpg,jpeg,png,pdf',
            'agunan_bag_kamarmandi'.$star=> 'mimes:jpg,jpeg,png,pdf',
            'agunan_bag_dapur'.$star     => 'mimes:jpg,jpeg,png,pdf'
        ];

        return $rules;
    }

    public function messages()
    {
        return  [
            // Agunan Tanah Array
            'tipe_lokasi_agunan.*.in'           => ':attribute harus salah satu dari jenis berikut :values',
            'rt_agunan.*.numeric'               => ':attribute harus berupa angka',
            'rw_agunan.*.numeric'               => ':attribute harus berupa angka',
            'luas_tanah.*.numeric'              => ':attribute harus berupa angka',
            'luas_bangunan.*.numeric'           => ':attribute harus berupa angka',
            'jenis_sertifikat.*.in' 
                        => ':attribute harus salah satu dari jenis berikut :values',
            'lamp_agunan_depan.*.mimes'         => ':attribute harus bertipe :values',
            'lamp_agunan_kanan.*.mimes'         => ':attribute harus bertipe :values',
            'lamp_agunan_kiri.*.mimes'          => ':attribute harus bertipe :values',
            'lamp_agunan_belakang.*.mimes'      => ':attribute harus bertipe :values',
            'lamp_agunan_dalam.*.mimes'         => ':attribute harus bertipe :values',

            // Agunan Tanah
            'tipe_lokasi_agunan.in'           => ':attribute harus salah satu dari jenis berikut :values',
            'rt_agunan.numeric'               => ':attribute harus berupa angka',
            'rw_agunan.numeric'               => ':attribute harus berupa angka',
            'luas_tanah.numeric'              => ':attribute harus berupa angka',
            'luas_bangunan.numeric'           => ':attribute harus berupa angka',
            'jenis_sertifikat.in'             => ':attribute harus salah satu dari jenis berikut :values',

            'lamp_agunan_depan.mimes'         => ':attribute harus bertipe :values',
            'lamp_agunan_kanan.mimes'         => ':attribute harus bertipe :values',
            'lamp_agunan_kiri.mimes'          => ':attribute harus bertipe :values',
            'lamp_agunan_belakang.mimes'      => ':attribute harus bertipe :values',
            'lamp_agunan_dalam.mimes'         => ':attribute harus bertipe :values',
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        $errors = (new ValidationException($validator))->errors();
        throw new HttpResponseException(
            // response()->json(['errors' => $errors], JsonResponse::HTTP_UNPROCESSABLE_ENTITY)
            response()->json([
                "code"    => 422,
                "status"  => "not valid request",
                "message" => $errors
            ], JsonResponse::HTTP_UNPROCESSABLE_ENTITY)
        );
    }
}
