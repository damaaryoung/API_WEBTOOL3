<?php

namespace App\Http\Requests\Transaksi\Agunan;

use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Http\JsonResponse;
use Urameshibr\Requests\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Validation\ValidationException;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Foundation\Http\FormRequest as LaravelFormRequest;

class Pe_TanahRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules(Request $request)
    {
        $segment = $request->segment(4);

        if ($segment == 'update') {
            $star = '';
        }else{
            $star = '.*';
        }

        $rules = [
            'status_penghuni'.$star  => 'in:PEMILIK,PENYEWA, KELUARGA',
            // 'bentuk_bangunan'.$star  => 'in:RUMAH,KONTRAKAN,VILLA,RUKO,APARTMENT',
            'kondisi_bangunan'.$star => 'in:LAYAK,KURANG,TIDAK',
            'tgl_taksasi'.$star      => 'date_format:d-m-Y',
        ];

        return $rules;
    }

    public function messages()
    {
        return [
            // Pemeriksaan Agunan Tanah
            'status_penghuni.*.in'              => ':attribute harus salah satu dari jenis berikut :values',
            // 'bentuk_bangunan.*.in'              => ':attribute harus salah satu dari jenis berikut :values',
            'kondisi_bangunan.*.in'             => ':attribute harus salah satu dari jenis berikut :values',
            'tgl_taksasi.*.date_format'         => ':attribute harus berupa angka dengan format :format',

            // Pemeriksaan Agunan Tanah
            'status_penghuni.in'              => ':attribute harus salah satu dari jenis berikut :values',
            // 'bentuk_bangunan.in'              => ':attribute harus salah satu dari jenis berikut :values',
            'kondisi_bangunan.in'             => ':attribute harus salah satu dari jenis berikut :values',
            'tgl_taksasi.date_format'         => ':attribute harus berupa angka dengan format :format'
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        $errors = (new ValidationException($validator))->errors();
        throw new HttpResponseException(
            // response()->json(['errors' => $errors], JsonResponse::HTTP_UNPROCESSABLE_ENTITY)
            response()->json([
                "code"    => 422,
                "status"  => "not valid request",
                "message" => $errors
            ], JsonResponse::HTTP_UNPROCESSABLE_ENTITY)
        );
    }
}
