<?php

namespace App\Http\Requests\Transaksi\Kalkulasi;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Urameshibr\Requests\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Validation\ValidationException;
use Illuminate\Http\Exceptions\HttpResponseException;

class MutasiRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules(Request $request)
    {
        $segment = $request->segment(4);

        if ($segment == 'update') {
            $star = '';
        }else{
            $star = '.*';
        }
        
        return [
            'urutan_mutasi'.$star           => 'integer',
            'no_rekening_mutasi'.$star      => 'numeric',
            'frek_debet_mutasi.*'.$star     => 'integer',
            'nominal_debet_mutasi.*'.$star  => 'integer',
            'frek_kredit_mutasi.*'.$star    => 'integer',
            'nominal_kredit_mutasi.*'.$star => 'integer',
            'saldo_mutasi.*'.$star          => 'integer'
        ];
    }

    public function messages()
    {
        $integer     = ':attribute harus berupa angka / bilangan bulat dan tidak boleh dimulai dari 0';
        $numeric     = ':attribute harus berupa angka';

        return [
            // Single
            'urutan_mutasi.integer'           => $integer,
            'no_rekening_mutasi.numeric'      => $numeric,
            'frek_debet_mutasi.*.integer'     => $integer,
            'nominal_debet_mutasi.*.integer'  => $integer,
            'frek_kredit_mutasi.*.integer'    => $integer,
            'nominal_kredit_mutasi.*.integer' => $integer,
            'saldo_mutasi.*.integer'          => $integer,

            // Array
            'urutan_mutasi.*.integer'           => $integer,
            'no_rekening_mutasi.*.numeric'      => $numeric,
            'frek_debet_mutasi.*.*.integer'     => $integer,
            'nominal_debet_mutasi.*.*.integer'  => $integer,
            'frek_kredit_mutasi.*.*.integer'    => $integer,
            'nominal_kredit_mutasi.*.*.integer' => $integer,
            'saldo_mutasi.*.*.integer'          => $integer,
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        $errors = (new ValidationException($validator))->errors();
        throw new HttpResponseException(
            // response()->json(['errors' => $errors], JsonResponse::HTTP_UNPROCESSABLE_ENTITY)
            response()->json([
                "code"    => 422,
                "status"  => "not valid request",
                "message" => $errors
            ], JsonResponse::HTTP_UNPROCESSABLE_ENTITY)
        );
    }
}
