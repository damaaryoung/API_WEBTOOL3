<?php

namespace App\Http\Controllers\Menu;

use Laravel\Lumen\Routing\Controller as BaseController;
use App\Models\Menu\MenuMaster;
use App\Models\Menu\MenuSub;
use Illuminate\Http\Request;
use Cache;
use DB;

class MenuSubController extends BaseController
{
    public function __construct() 
    {
        $this->time_cache = config('app.cache_exp');
        $this->chunk      = 100;
    }

    public function index() 
    {
        // $query = Cache::remember('mSub', $this->time_cache, function () {
        $query = MenuSub::select('id','nama','url')
        ->addSelect(['menu_master' => MenuMaster::select('url')->whereColumn('id_menu_master', 'menu_master.id')])
        ->where('flg_aktif', 1)->orderBy('id', 'desc')->get()->toArray();
        // });

        if (empty($query)) {
            return response()->json([
                "code"    => 404,
                "status"  => "not found",
                "message" => "Data kosong"
            ], 404);
        }

        try {
            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'count'  => sizeof($query),
                'data'   => $query
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'code'   => 501,
                'status' => 'error',
                'message'=> $e
            ], 501);
        }
    }

    public function store(Request $req) 
    {
        $master = $req->input('id_menu_master');
        $reqNama   = $req->input('nama');
        $nama = strtolower($reqNama);

        $url = preg_replace("/[- ]/", "_", $nama);

        if (!$master) {
            return response()->json([
                "code"    => 400,
                "status"  => "bad request",
                "message" => "Field 'id_menu_master' harus diisi"
            ], 400);
        }

        if (!$reqNama) {
            return response()->json([
                "code"    => 400,
                "status"  => "bad request",
                "message" => "Field 'nama' harus diisi"
            ], 400);
        }

        $data = array(
            'id_menu_master' => $master,
            'nama'           => $nama,
            'url'            => $url,
            'flg_aktif'      => 1
        );

        $query = MenuSub::create($data);
        
        try {
            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'message'=> 'data berhasil dibuat',
                'data'   => $query
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'code'   => 501,
                'status' => 'error',
                'message'=> $e
            ], 501);
        }
    }

    public function show($IdOrSlug) 
    {
        $query = MenuSub::select('id','nama','url', 'flg_aktif')
        ->addSelect(['menu_master' => MenuMaster::select('nama')->whereColumn('id_menu_master', 'menu_master.id')])
        ->where('id', $IdOrSlug)
        ->orWhere('url', $IdOrSlug)
        ->first();


        if (empty($query)) {
            return response()->json([
                "code"    => 404,
                "status"  => "not found",
                "message" => "Data kosong"
            ], 404);
        }

        try {
            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'data'   => $query
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'code'   => 501,
                'status' => 'error',
                'message'=> $e
            ], 501);
        }
    }

    public function update($IdOrSlug, Request $req) 
    {
        $check = MenuSub::where('id', $IdOrSlug)
        ->orWhere('url', $IdOrSlug)->first();

        if (empty($check)) {
            return response()->json([
                'code'    => 404,
                'status'  => 'not found',
                'message' => 'Data Tidak Ada!!'
            ], 404);
        }

        $data = array(
            'id_menu_master' => empty($req->input('id_menu_master')) ? $check->id_menu_master : $req->input('id_menu_master'),
            'nama'           => $nama = empty($req->input('nama'))   ? $check->nama      : $req->input('nama'),
            'url'            => empty($nama)                         ? $check->url       : preg_replace("/[- ]/", "_", strtolower($nama)),
            'flg_aktif'      => empty($req->input('flg_aktif'))      ? $check->flg_aktif : ($req->input('flg_aktif') == 'false' ? 0 : 1)
        );

        MenuSub::where('id', $IdOrSlug)
        ->orWhere('url', $IdOrSlug)
        ->update($data);

        try {
            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'data'   => $data
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'code'   => 501,
                'status' => 'error',
                'message'=> $e
            ], 501);
        }
    }

    public function delete($IdOrSlug) 
    {
        MenuSub::where('id', $IdOrSlug)->orWhere('url', $IdOrSlug)->update(['flg_aktif' => 0]);

        try {
            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'message'=> 'Data dengan URL(IdOrSlug) '.$IdOrSlug.', berhasil dihapus'
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'code'    => 501,
                'status'  => 'error',
                'message' => $e
            ], 501);
        }
    }

    public function trash() 
    {
        $query = MenuSub::select('id','nama','url')
        ->addSelect(['menu_master' => MenuMaster::select('url')->whereColumn('id_menu_master', 'menu_master.id')])
        ->where('flg_aktif', 0)->orderBy('nama', 'asc')->get();

        if (empty($query)) {
            return response()->json([
                "code"    => 404,
                "status"  => "not found",
                "message" => "Data kosong"
            ], 404);
        }

        try {

            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'count'  => $query->count(),
                'data'   => $query
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'code'   => 501,
                'status' => 'error',
                'message'=> $e
            ], 501);
        }
    }

    public function restore($id) 
    {
        MenuSub::where('id', $id)->update(['flg_aktif' => 1]);

        try {
            return response()->json([
                'code'    => 200,
                'status'  => 'success',
                'message' => 'data berhasil dikembalikan'
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                "code"    => 501,
                "status"  => "error",
                "message" => $e
            ], 501);
        }
    }

    public function search($search)
    {
        $query = DB::connection('web')->table('menu_sub as sub')
        ->leftJoin('menu_master as master', 'sub.id_menu_master', 'master.id')
        ->select('sub.id', 'sub.nama', 'sub.url', 'master.url as menu_master')
        ->where("sub.id", "like", "%{$search}%")
        ->orWhere("sub.nama", "like", "%{$search}%")
        ->orWhere("sub.url", "like", "%{$search}%")
        ->orWhere("master.url", "like", "%{$search}%")
        ->get()->toArray();

        if (empty($query)) {
            return response()->json([
                "code"    => 404,
                "status"  => "not found",
                "message" => "Data kosong"
            ], 404);
        }

        try {
            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'count'  => sizeof($query),
                'data'   => $query //->pluck('menu_master')
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'code'   => 501,
                'status' => 'error',
                'message'=> $e
            ], 501);
        }
    }
}
