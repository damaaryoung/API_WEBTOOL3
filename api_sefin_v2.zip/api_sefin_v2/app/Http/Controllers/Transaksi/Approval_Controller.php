<?php

namespace App\Http\Controllers\Transaksi;

use Laravel\Lumen\Routing\Controller as BaseController;
use App\Http\Controllers\Controller as Helper;

use App\Models\Transaksi\Approval;
use App\Models\Transaksi\Transaksi;
use App\Models\Transaksi\TransCAA;
use App\Models\Transaksi\Kalkulasi\FasilitasPinjaman;

use Illuminate\Http\Request;
use Carbon\Carbon;
use DB;

class Approval_Controller extends BaseController
{
    public function index($id_transaksi, Request $req)
    {
        $pic = $req->pic;

        $check_transaksi = DB::connection('web')->table('view_transaksi')->where('id', $id_transaksi)->get();

        if (!$check_transaksi) {
            return response()->json([
                "code"    => 404,
                "status"  => "not found",
                "message" => "Transaksi dengan id transaksi {$id_transaksi} tidak ditemukan"
            ], 404);
        }

        $check_approval = Approval::with('pic')
                ->where('id_transaksi', $id_transaksi)
                ->get()
                ->sortByDesc('pic.jpic.urutan_jabatan');

        if (!$check_approval) {
            return response()->json([
                'code'    => 404,
                'status'  => 'not found',
                'message' => "Approval dengan id transaksi {$id_transaksi} tidak ditemukan"
            ], 404);
        }

        $picApproval = array();
        foreach ($check_approval as $value) {
            $picApproval[] = $value->id;
        }

        if(in_array($pic->id, $picApproval) === false){
            return response()->json([
                'code'    => 401,
                'status'  => 'Error',
                'message' => "Anda tidak berhak melihat data ini. Hanya id PIC berikut: ".implode(',',$picApproval)." yang boleh mengaksesnya"
            ], 401);
        }

        foreach ($check_approval as $val) {

            if ($val->status) {
                $status = $val->status;
            }else{
                $status = 'waiting';
            }

            $data[] = [
                'id_approval'    => $val->id,
                'user_id'        => $val->pic['user']['user_id'],
                'id_pic_approval'=> $val->id_pic,
                'nama_pic'       => $val->pic['nama'],
                'jabatan'        => $val->pic['jpic']['nama_jenis'],
                'batas_plafon'   => $val->pic['plafon_caa'],
                // 'pengajuan_so'   => FasilitasPinjaman::where('id_transaksi', $id_transaksi)->first()->makeHidden('id_transaksi'),
                'approval_plafon' => $val->plafon,
                'approval_tenor'  => $val->tenor,
                'status_approval' => $status,
                'rincian'         => $val->rincian,
                'tanggal_approve' => $val->updated_at
            ];
        }

        try {
            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'count'  => sizeof($data),
                'id_transaksi'  => $id_transaksi,
                'nomor_transaksi' => $check_transaksi->nomor_transaksi,
                'tracking'  => [
                    'status' => [
                        'das'      => $check_transaksi->status_das,
                        'hm'       => $check_transaksi->status_hm,
                        'ao'       => $check_transaksi->status_ao,
                        'ca'       => $check_transaksi->status_ca,
                        'caa'      => $check_transaksi->status_caa,
                        'approval' => $check_transaksi->status_approval
                    ],
                    'pic'   => [
                        'so'    => $check_transaksi->nama_so,
                        'das'   => $check_transaksi->nama_das,
                        'hm'    => $check_transaksi->nama_hm,
                        'ao'    => $check_transaksi->nama_ao,
                        'ca'    => $check_transaksi->nama_ca,
                        'caa'   => $check_transaksi->nama_caa
                    ],
                    'tanggal' => [
                        'tgl_so'  => $check_transaksi->tgl_so,
                        'tgl_das' => $check_transaksi->tgl_das,
                        'tgl_hm'  => $check_transaksi->tgl_hm,
                        'tgl_ao'  => $check_transaksi->tgl_ao,
                        'tgl_ca'  => $check_transaksi->tgl_ca,
                        'tgl_caa' => $check_transaksi->tgl_caa
                    ]
                ],
                'pengajuan_so' => [
                    'jenis_pinjaman'  => $check_transaksi->jenis_pinjaman,
                    'tujuan_pinjaman' => $check_transaksi->tujuan_pinjaman,
                    'plafon'          => (int) $check_transaksi->plafon,
                    'tenor'           => (int) $check_transaksi->tenor
                ],
                'data'   => $data
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                "code"    => 501,
                "status"  => "error",
                "message" => $e
            ], 501);
        }
    }

    public function show($id_transaksi, $id_approval, Request $req)
    {
        $pic = $req->pic;

        $check_transaksi = DB::connection('web')->table('view_transaksi')->where('id', $id_transaksi)->first();

        if (!$check_transaksi) {
            return response()->json([
                "code"    => 404,
                "status"  => "not found",
                "message" => "Transaksi dengan id transaksi {$id_transaksi} tidak ditemukan"
            ], 404);
        }

        $check_approval = Approval::where('id_transaksi', $id_transaksi)->where('id', $id_approval)->first();

        if (!$check_approval) {
            return response()->json([
                "code"    => 404,
                "status"  => "not found",
                "message" => "Approval dengan id transaksi {$id_transaksi} dan id approval {$id_approval} tidak ditemukan"
            ], 404);
        }

        if($pic->id != $check_approval->id_pic){
            return response()->json([
                'code'    => 401,
                'status'  => 'Error',
                'message' => "Anda tidak berhak melihat data ini. Hanya id PIC {$check_approval->id_pic} dan yang terdaftar di approval yang boleh mengaksesnya"
            ], 401);
        }
        
        $tenor_pengajuan  = (int) $check_transaksi->tenor;
        $plafon_pengajuan = (int) $check_transaksi->plafon;
        $plafon_max       = (int) $check_approval->pic['plafon_caa'];

        if($plafon_pengajuan <= $plafon_max) {

            $list_status = array('accept' => true, 'forward' => false, 'reject' => true, 'return' => true);

        }else{

            $list_status = array('accept' => false, 'forward' => true, 'reject' => true, 'return' => true);

        }

        $data = [
            'id_transaksi'   => $check_transaksi->id,
            'id_approval'    => $check_approval->id,
            'nomor_transaksi'=> $check_approval->transaksi['nomor_transaksi'],
            'user_id'           => $check_approval->pic['user_id'],
            'id_pic_approval'   => $check_approval->id_pic,
            'batas_plafon'      => $plafon_max,
            'nama_pic_approval' => $check_approval->pic['nama'],
            'jabatan'           => $check_approval->pic['jpic']['nama_jenis'],
            'tracking'  => [
                'status' => [
                    'das'      => $check_transaksi->status_das,
                    'hm'       => $check_transaksi->status_hm,
                    'ao'       => $check_transaksi->status_ao,
                    'ca'       => $check_transaksi->status_ca,
                    'caa'      => $check_transaksi->status_caa,
                    'approval' => $check_transaksi->status_approval
                ],
                'pic'   => [
                    'so'    => $check_transaksi->nama_so,
                    'das'   => $check_transaksi->nama_das,
                    'hm'    => $check_transaksi->nama_hm,
                    'ao'    => $check_transaksi->nama_ao,
                    'ca'    => $check_transaksi->nama_ca,
                    'caa'   => $check_transaksi->nama_caa
                ],
                'tanggal' => [
                    'tgl_so'  => $check_transaksi->tgl_so,
                    'tgl_das' => $check_transaksi->tgl_das,
                    'tgl_hm'  => $check_transaksi->tgl_hm,
                    'tgl_ao'  => $check_transaksi->tgl_ao,
                    'tgl_ca'  => $check_transaksi->tgl_ca,
                    'tgl_caa' => $check_transaksi->tgl_caa
                ]
            ],
            'pengajuan_so'   => [
                'jenis_pinjaman'  => $check_transaksi->jenis_pinjaman,
                'tujuan_pinjaman' => $check_transaksi->tujuan_pinjaman,
                'plafon'          => $plafon_pengajuan,
                'tenor'           => $tenor_pengajuan
            ],
            'rekomendasi_ao' => DB::connection('web')->table('recom_ao')->where('id_transaksi', $id_transaksi)->first(),
            'rekomendasi_ca' => DB::connection('web')->table('recom_ca')->where('id_transaksi', $id_transaksi)->first(),
            'rekomendasi_pinjaman' => DB::connection('web')->table('rekomendasi_pinjaman')->where('id_transaksi', $id_transaksi)->first(),
            'approval_plafon' => $check_approval->plafon,
            'approval_tenor'  => $check_approval->tenor,
            'rincian'         => $check_approval->rincian,
            'tanggal_approve' => $check_approval->updated_at,

            'list_status' => $list_status
        ];

        try {
            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'data'   => $data
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                "code"    => 501,
                "status"  => "error",
                "message" => $e
            ], 501);
        }
    }

    public function approve($id_transaksi, $id_approval, Request $req)
    {
        $pic = $req->pic;

        $check_transaksi = DB::connection('web')->table('view_transaksi')->where('id', $id_transaksi)->first();

        if (!$check_transaksi) {
            return response()->json([
                "code"    => 404,
                "status"  => "not found",
                "message" => "Transaksi dengan id transaksi {$id_transaksi} tidak ditemukan"
            ], 404);
        }

        $check_approval = Approval::with('pic')
        ->where('id_transaksi', $id_transaksi)
        ->get()->sortByDesc('pic.jpic.urutan_jabatan')->toArray();

        if (!$check_approval) {
            return response()->json([
                "code"    => 404,
                "status"  => "not found",
                "message" => "Approval dengan id transaksi {$id_transaksi} tidak ditemukan"
            ], 404);
        }

        $seKey = array_search(700, array_column($check_approval, 'id_pic'));
        $lastKey = array_key_last($check_approval);

        if ($seKey == false) {
            $to_forward = null;
        }else{
            $ForKey = $seKey + 1;

            $to_forward = $ForKey != $lastKey ? $check_approval[$ForKey]['id_pic'] : null;
        }


        $st = $req->input('status');

        if ($st == 'accept')
        {
            $status = 1;
        }
        elseif ($st == 'forward') 
        {
            $status = 2;
        }
        elseif ($st == 'return') 
        {
            $status = 3;
        }
        elseif ($st == 'reject')
        {
            $status = 4;
        }
        else
        {
            $status = 0;
        }

        $approval = array(
            'plafon'        => $req->input('plafon'),
            'tenor'         => $req->input('tenor'),
            'rincian'       => $req->input('rincian'),
            'status'        => $st,
            'tujuan_forward'=> $st == 'forward' ? $to_forward : null,
            'updated_at'    => Carbon::now()->toDateTimeString()
        );

        if($st === 'return') {
            $transaksi = array(
                'id_pic_caa'      => null,
                'id_pic_approval' => null,
                'status_caa'      => null,
                'catatan_caa'     => null,
                'status_approval' => null,
                'tgl_caa'         => null,
                'tgl_approval'    => null
            );
        }else{
            $transaksi = array(
                'id_pic_approval' => $pic->id,
                'status_approval' => $status,
                'tgl_approval'    => Carbon::now()->toDateTimeString()
            );
        }

        DB::connection('web')->beginTransaction();

        try {
            if ($st === 'return') {
                TransCAA::where('id_transaksi', $id_transaksi)->delete();
            }

            Transaksi::where('id', $id_transaksi)->update($transaksi);
            Approval::where('id', $id_approval)->update($approval);


            DB::connection('web')->commit();

            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'message'=> 'Data untuk berhasil di - '.$st,
                'data'   => array(
                    'approval'  => $approval,
                    'transaksi' => $transaksi
                )
            ], 200);
        } catch (\Exception $e) {
            $err = DB::connection('web')->rollback();
            return response()->json([
                'code'    => 501,
                'status'  => 'error',
                'message' => $err
            ], 501);
        }
    }
}