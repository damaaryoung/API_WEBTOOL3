<?php

namespace App\Http\Controllers\Transaksi;

use Laravel\Lumen\Routing\Controller as BaseController;
use App\Http\Controllers\Controller as Helper;

// use App\Http\Requests\Transaksi\Kalkulasi\FaspinRequest;
use App\Http\Requests\Transaksi\Kalkulasi\PendapatanReq;
use App\Http\Requests\Transaksi\Kalkulasi\KapbulRequest;
use App\Http\Requests\Transaksi\Kalkulasi\MutasiRequest;
use App\Http\Requests\Transaksi\Kalkulasi\LogTabReq;
use App\Http\Requests\Transaksi\Kalkulasi\IACRequest;
use App\Http\Requests\Transaksi\Rekomendasi\RekomCaReq;

// use App\Models\Transaksi\Kalkulasi\FasilitasPinjaman;
// use App\Models\Transaksi\Kalkulasi\PendapatanUsaha;
// use App\Models\Transaksi\Kalkulasi\KapBulanan;

// use App\Models\Transaksi\Rekomendasi\RekomendasiPinjaman;
// use App\Models\Transaksi\Kalkulasi\RingkasanAnalisa;
// use App\Models\Transaksi\AsuransiJiwa\AsuransiJiwa;
// use App\Models\Transaksi\AsuransiJaminan\AsuransiJaminan;

use App\Models\Transaksi\Kalkulasi\MutasiBank;
// use App\Models\Transaksi\Kalkulasi\LogTabungan;
use App\Models\Transaksi\Kalkulasi\InfoACC;
// use App\Models\Transaksi\Rekomendasi\RekomendasiCA;
// use App\Models\Transaksi\Agunan\PemeriksaanAgunTan;
use App\Models\Transaksi\Transaksi;
use Illuminate\Support\Facades\File;

use Illuminate\Http\Request;
use Carbon\Carbon;
use DB;

class CA_Controller extends BaseController
{
    public function update($id_transaksi,  Request $req, PendapatanReq $us_req, KapbulRequest $kap_req, MutasiRequest $mut_req, LogTabReq $log_req, IACRequest $acc_req, RekomCaReq $ca_req)
    {
        $pic = $req->pic;

        $check_trans = Transaksi::where('id',$id_transaksi)
        ->where('status_das', 1)->where('status_hm', 1)->where('status_ao', 1)->first();

        if (empty($check_trans)) {
            return response()->json([
                'code'    => 404,
                'status'  => 'not found',
                'message' => 'Transaksi dengan id '.$id_transaksi.' belum selesai di proses oleh AO'
            ], 404);
        }

        $lamp_dir = 'public/' . $check_trans->nomor_transaksi; // $check_so->debt['no_ktp'];

        $dataTransaksi = array(
            'id_pic_ca'  => $pic->id,
            'status_ca'  => empty($req->input('status_ca')) ? 1 : $req->input('status_ca'),
            'catatan_ca' => $req->input('catatan_ca'),
            'tgl_ca'     => Carbon::now()->toDateTimeString()
        );

        // Check Fasilitas Pinjaman
        $check_faspin = DB::connection('web')->table('fasilitas_pinjaman')
        ->where('id_transaksi', $id_transaksi)->select('segmentasi_bpr')->first();

        if (empty($check_faspin)) {
            return response()->json([
                'code'    => 404,
                'status'  => 'not found',
                'message' => 'Fasilitas Pinjaman dengan id transaksi '.$id_transaksi.' tidak ditemukan'
            ], 404);
        }

        $dataFaspin = array('segmentasi_bpr' => $req->input('segmentasi_bpr'));

        $check_kapbul = DB::connection('web')->table('kapasitas_bulanan')
        ->where('id_transaksi', $id_transaksi)->first();

        if (empty($check_kapbul)) {
            return response()->json([
                'code'    => 404,
                'status'  => 'not found',
                'message' => 'Kapasitas Bulanan dengan id transaksi '.$id_transaksi.' tidak ditemukan'
            ], 404);
        }

        // Start Kapasitas Bulanan
        $inputKapBul = array(
            'pemasukan_cadebt'      => empty($kap_req->input('pemasukan_debitur')) ? $check_kapbul->pemasukan_debitur : $kap_req->input('pemasukan_debitur'),
            'pemasukan_pasangan'    => empty($kap_req->input('pemasukan_pasangan')) ? $check_kapbul->pemasukan_pasangan : $kap_req->input('pemasukan_pasangan'),
            'pemasukan_penjamin'    => empty($kap_req->input('pemasukan_penjamin')) ? $check_kapbul->pemasukan_penjamin : $kap_req->input('pemasukan_penjamin'),
            'biaya_rumah_tangga'    => empty($kap_req->input('biaya_rumah_tangga')) ? $check_kapbul->biaya_rumah_tangga : $kap_req->input('biaya_rumah_tangga'),
            'biaya_transport'       => empty($kap_req->input('biaya_transport')) ? $check_kapbul->biaya_transport : $kap_req->input('biaya_transport'),
            'biaya_pendidikan'      => empty($kap_req->input('biaya_pendidikan')) ? $check_kapbul->biaya_pendidikan : $kap_req->input('biaya_pendidikan'),
            'telp_listr_air'        => empty($kap_req->input('telp_listr_air')) ? $check_kapbul->telp_listr_air : $kap_req->input('telp_listr_air'), // jangan lupa hampir sama dengan pendapatan usaha
            'angsuran'              => empty($kap_req->input('angsuran')) ? $check_kapbul->angsuran : $kap_req->input('angsuran'),
            'biaya_lain'            => empty($kap_req->input('biaya_lain')) ? $check_kapbul->biaya_lain : $kap_req->input('biaya_lain')
        );

        $totalKapBul = array(
            'total_pemasukan'    => $ttl1 = array_sum(array_slice($inputKapBul, 0, 3)),
            'total_pengeluaran'  => $ttl2 = array_sum(array_slice($inputKapBul, 3)),
            'penghasilan_bersih' => $ttl1 - $ttl2,
            'ao_ca'              => 'ca',
            'id_transaksi'       => $id_transaksi
        );

        // $dataKapbul = array_merge($inputKapBul, $totalKapBul);
        // End Kapasitas Bulanan
        
        $check_usaha = DB::connection('web')->table('pendapatan_usaha_cadebt')
        ->where('id_transaksi', $id_transaksi)->first();

        if (empty($check_usaha)) {
            return response()->json([
                'code'    => 404,
                'status'  => 'not found',
                'message' => 'Pendapatan Usaha dengan id transaksi '.$id_transaksi.' tidak ditemukan'
            ], 404);
        }

        // Pendapatan Usaha
        $inputKeUsaha = array(
            'pemasukan_tunai'      => empty($us_req->input('pemasukan_tunai')) ? $check_usaha->pemasukan_tunai : $us_req->input('pemasukan_tunai'),
            'pemasukan_kredit'     => empty($us_req->input('pemasukan_kredit')) ? $check_usaha->pemasukan_kredit : $us_req->input('pemasukan_kredit'),
            'biaya_sewa'           => empty($us_req->input('biaya_sewa')) ? $check_usaha->biaya_sewa : $us_req->input('biaya_sewa'),
            'biaya_gaji_pegawai'   => empty($us_req->input('biaya_gaji_pegawai')) ? $check_usaha->biaya_gaji_pegawai : $us_req->input('biaya_gaji_pegawai'),
            'biaya_belanja_brg'    => empty($us_req->input('biaya_belanja_brg')) ? $check_usaha->biaya_belanja_brg : $us_req->input('biaya_belanja_brg'),
            'biaya_telp_listr_air' => empty($us_req->input('biaya_telp_listr_air')) ? $check_usaha->biaya_telp_listr_air : $us_req->input('biaya_telp_listr_air'),
            'biaya_sampah_kemanan' => empty($us_req->input('biaya_sampah_kemanan')) ? $check_usaha->biaya_sampah_kemanan : $us_req->input('biaya_sampah_kemanan'),
            'biaya_kirim_barang'   => empty($us_req->input('biaya_kirim_barang')) ? $check_usaha->biaya_kirim_barang : $us_req->input('biaya_kirim_barang'),
            'biaya_hutang_dagang'  => empty($us_req->input('biaya_hutang_dagang')) ? $check_usaha->biaya_hutang_dagang : $us_req->input('biaya_hutang_dagang'),
            'biaya_angsuran'       => empty($us_req->input('biaya_angsuran')) ? $check_usaha->biaya_angsuran : $us_req->input('biaya_angsuran'),
            'biaya_lain_lain'      => empty($us_req->input('biaya_lain_lain')) ? $check_usaha->biaya_lain_lain : $us_req->input('biaya_lain_lain')
            );

        $totalKeUsaha = array(
            'total_pemasukan'   => $ttl1 = array_sum(array_slice($inputKeUsaha, 0, 2)),
            'total_pengeluaran' => $ttl2 = array_sum(array_slice($inputKeUsaha, 2)),
            'laba_usaha'        => $ttl1 - $ttl2,
            'ao_ca'             => 'ca', 
            'id_transaksi'      => $id_transaksi
        );

        $dataUsaha = array_merge($inputKeUsaha, $totalKeUsaha);

        // Ceiling Recomendasi Pinjaman
        $dataRekomPin = array(
            'penyimpangan_struktur'=> $req->input('penyimpangan_struktur'),
            'penyimpangan_dokumen' => $req->input('penyimpangan_dokumen'),
            'recom_nilai_pinjaman' => $req->input('recom_nilai_pinjaman'),
            'recom_tenor'          => $req->input('recom_tenor'),
            'recom_angsuran'       => $req->input('recom_angsuran'),
            'recom_produk_kredit'  => $req->input('recom_produk_kredit'),
            'note_recom'           => $req->input('note_recom'),
            'bunga_pinjaman'       => $req->input('bunga_pinjaman'),
            'nama_ca'              => empty($req->input('nama_ca'))
                ? $pic->nama : $req->input('nama_ca'),
            'id_transaksi'         => $id_transaksi
        );

        $rekomen_pendapatan  = $totalKapBul['total_pemasukan']   == null ? 0 : $totalKapBul['total_pemasukan'];
        $rekomen_pengeluaran = $totalKapBul['total_pengeluaran'] == null ? 0 : $totalKapBul['total_pengeluaran'];
        $rekomen_angsuran    = $inputKapBul['angsuran']           == null ? 0 : $inputKapBul['angsuran'];

        // Rekomendasi Angsuran pada table rrekomendasi_pinjaman
        $plafonCA = $dataRekomPin['recom_nilai_pinjaman'] == null ? 0 : $dataRekomPin['recom_nilai_pinjaman'];
        $tenorCA  = $dataRekomPin['recom_tenor']          == null ? 0 : $dataRekomPin['recom_tenor'];
        $bunga    = $dataRekomPin['bunga_pinjaman']       == null ? 0 : ($dataRekomPin['bunga_pinjaman'] / 100);


        if ($plafonCA == 0 && $tenorCA == 0 && $bunga == 0) {
            $recom_angs = 0;
        }else{
            $recom_angs = Helper::recom_angs($plafonCA, $tenorCA, $bunga);
        }
        
        $rekomen_pend_bersih = $rekomen_pendapatan - $rekomen_pengeluaran;

        $disposable_income   = $rekomen_pend_bersih - $recom_angs;


        // End Kapasitas Bulanan
        $dataKapbul = array_merge($inputKapBul, $totalKapBul);

        $check_taksasi = DB::connection('web')->table('periksa_agunan_tanah')
        ->where('id_transaksi', $id_transaksi)
        ->select('nilai_taksasi_agunan')->first();

        if (empty($check_taksasi)) {
            $taksasi = 0;
        }else{
            $taksasi = $check_taksasi->nilai_taksasi_agunan;
        }

        $recom_ltv   = Helper::recom_ltv($plafonCA, $taksasi);
        $recom_idir  = Helper::recom_idir($recom_angs, $rekomen_pendapatan, $rekomen_pengeluaran);
        $recom_dsr   = Helper::recom_dsr($recom_angs, $rekomen_pendapatan, $rekomen_angsuran);

        $recom_hasil = Helper::recom_hasil($recom_dsr, $recom_ltv, $recom_idir);

        // Mutasi Bank
        if (!empty($mut_req->input('no_rekening_mutasi'))){

            $dataMutasi = array();
            for ($i = 0; $i < count($mut_req->input('no_rekening_mutasi')); $i++) {

                $dataMutasi[] = array(
                    'urutan_mutasi' => $mut_req->urutan_mutasi[$i],
                    'nama_bank'     => $mut_req->nama_bank_mutasi[$i],
                    'no_rekening'   => $mut_req->no_rekening_mutasi[$i],
                    'nama_pemilik'  => $mut_req->nama_pemilik_mutasi[$i],

                    'periode' => empty($mut_req->input('periode_mutasi')[$i])
                        ? null : implode(";", $mut_req->periode_mutasi[$i]),

                    'frek_debet' => empty($mut_req->input('frek_debet_mutasi')[$i])
                        ? null : implode(";", $mut_req->frek_debet_mutasi[$i]),

                    'nominal_debet' => empty($mut_req->input('nominal_debet_mutasi')[$i])
                        ? null : implode(";", $mut_req->nominal_debet_mutasi[$i]),

                    'frek_kredit' => empty($mut_req->input('frek_kredit_mutasi')[$i])
                        ? null : implode(";", $mut_req->frek_kredit_mutasi[$i]),

                    'nominal_kredit' => empty($mut_req->input('nominal_kredit_mutasi')[$i])
                        ? null : implode(";", $mut_req->nominal_kredit_mutasi[$i]),

                    'saldo' => empty($mut_req->input('saldo_mutasi')[$i])
                        ? null : implode(";", $mut_req->saldo_mutasi[$i]),

                    'id_transaksi'  => $id_transaksi
                );
            }
        }

        if (!empty($acc_req->input('nama_bank_acc'))) {
            $dataAnalisis = array();
            for ($i = 0; $i < count($acc_req->input('nama_bank_acc')); $i++) {
                $dataAnalisis[] = array(
                    'nama_bank'       => $acc_req->input('nama_bank_acc')[$i],
                    'plafon'          => $acc_req->input('plafon_acc')[$i],
                    'baki_debet'      => $acc_req->input('baki_debet_acc')[$i],
                    'angsuran'        => $acc_req->input('angsuran_acc')[$i],
                    'collectabilitas' => $acc_req->input('collectabilitas_acc')[$i],
                    'jenis_kredit'    => $acc_req->input('jenis_kredit_acc')[$i],
                    'id_transaksi'    => $id_transaksi
                );
            }
        }

        $dataTabungan = array(
            'no_rekening'             => $log_req->input('no_rekening'),
            'nama_bank'               => $log_req->input('nama_bank'),
            'tujuan_pembukaan_rek'    => $log_req->input('tujuan_pembukaan_rek'),
            'penghasilan_per_tahun'   => empty($log_req->input('penghasilan_per_tahun')) ? ($perBUlan * 12) : $log_req->input('penghasilan_per_tahun'),
            'sumber_penghasilan'      => $log_req->input('sumber_penghasilan'),
            'pemasukan_per_bulan'     => $perBUlan = $log_req->input('pemasukan_per_bulan'),
            'frek_trans_pemasukan'    => $log_req->input('frek_trans_pemasukan'),
            'pengeluaran_per_bulan'   => $log_req->input('pengeluaran_per_bulan'),
            'frek_trans_pengeluaran'  => $log_req->input('frek_trans_pengeluaran'),
            'sumber_dana_setoran'     => $log_req->input('sumber_dana_setoran'),
            'tujuan_pengeluaran_dana' => $log_req->input('tujuan_pengeluaran_dana'),
            'id_transaksi'            => $id_transaksi
        );

        $dataRingkasan = array(
            'kuantitatif_ttl_pendapatan'    => $rekomen_pendapatan,
            'kuantitatif_ttl_pengeluaran'   => $rekomen_pengeluaran,
            'kuantitatif_pendapatan_bersih' => $rekomen_pend_bersih,
            'kuantitatif_angsuran'          => $recom_angs,
            'kuantitatif_ltv'               => $recom_ltv,
            'kuantitatif_dsr'               => $recom_dsr,
            'kuantitatif_idir'              => $recom_idir,
            'kuantitatif_hasil'             => $recom_hasil,

            'kualitatif_analisa'     => $req->input('kualitatif_analisa'),
            'kualitatif_strenght'    => $req->input('kualitatif_strenght'),
            'kualitatif_weakness'    => $req->input('kualitatif_weakness'),
            'kualitatif_opportunity' => $req->input('kualitatif_opportunity'),
            'kualitatif_threatness'  => $req->input('kualitatif_threatness'),
            'id_transaksi'           => $id_transaksi
        );

        $dataRecomCA = array(
            'produk'                  => $ca_req->input('produk'), 
            'plafon_kredit'           => $ca_req->input('plafon_kredit'), 
            'jangka_waktu'            => $ca_req->input('jangka_waktu'), 
            'suku_bunga'              => $ca_req->input('suku_bunga'), 
            'pembayaran_bunga'        => $ca_req->input('pembayaran_bunga'), 
            'akad_kredit'             => $ca_req->input('akad_kredit'), 
            'ikatan_agunan'           => $ca_req->input('ikatan_agunan'), 
            'biaya_provisi'           => $ca_req->input('biaya_provisi'), 
            'biaya_administrasi'      => $ca_req->input('biaya_administrasi'), 
            'biaya_credit_checking'   => $ca_req->input('biaya_credit_checking'), 
            'biaya_asuransi_jiwa'     => $ca_req->input('biaya_asuransi_jiwa'), 
            'biaya_asuransi_jaminan'  => $ca_req->input('biaya_asuransi_jaminan'), 
            'notaris'                 => $ca_req->input('notaris'), 
            'biaya_tabungan'          => $ca_req->input('biaya_tabungan'), 
            'rekom_angsuran'              => $ca_req->input('rekom_angsuran'), 
            'angs_pertama_bunga_berjalan' => $ca_req->input('angs_pertama_bunga_berjalan'), 
            'pelunasan_nasabah_ro'  => $ca_req->input('pelunasan_nasabah_ro'), 
            'blokir_dana'           => $ca_req->input('blokir_dana'), 
            'pelunasan_tempat_lain' => $ca_req->input('pelunasan_tempat_lain'), 
            'blokir_angs_kredit'    => $ca_req->input('blokir_angs_kredit'), 
            'id_transaksi'          => $id_transaksi
        );

        $dataAsJiwa = array(
            'nama_asuransi'       => $req->input('nama_asuransi_jiwa'),
            'jangka_waktu'        => $req->input('jangka_waktu_as_jiwa'),
            'nilai_pertanggungan' => $req->input('nilai_pertanggungan_as_jiwa'),
            'jatuh_tempo'         => empty($req->input('jatuh_tempo_as_jiwa')) ? null : Carbon::parse($req->input('jatuh_tempo_as_jiwa'))->format('Y-m-d'),
            'berat_badan'         => $req->input('berat_badan_as_jiwa'),
            'tinggi_badan'        => $req->input('tinggi_badan_as_jiwa'),
            'umur_nasabah'        => $req->input('umur_nasabah_as_jiwa'),
            'id_transaksi'        => $id_transaksi
        );

        if (!empty(  $req->input('jangka_waktu_as_jaminan'))) {

            $asJaminan = array();
            for ($i = 0; $i < count($req->input('jangka_waktu_as_jaminan')); $i++) {

                $asJaminan[] = array(
                    'nama_asuransi'       => $req->nama_asuransi_jaminan[$i],
                    'jangka_waktu'        => $req->jangka_waktu_as_jaminan[$i],
                    'nilai_pertanggungan' => $req->nilai_pertanggungan_as_jaminan[$i],
                    'jatuh_tempo'         => empty($req->input('jatuh_tempo_as_jaminan')[$i])
                        ? null : Carbon::parse($req->jatuh_tempo_as_jaminan[$i])->format('Y-m-d')
                );
            }

            $dataAsJaminan = array(
                'nama_asuransi'       => implode(";", array_column($asJaminan, 'nama_asuransi')),
                'jangka_waktu'        => implode(";", array_column($asJaminan, 'jangka_waktu')),
                'nilai_pertanggungan' => implode(";", array_column($asJaminan, 'nilai_pertanggungan')),
                'jatuh_tempo'         => implode(";", array_column($asJaminan, 'jatuh_tempo')),
                'id_transaksi'        => $id_transaksi
            );
        }

        // dd($dataFaspin, $dataKapbul, $dataUsaha, $dataRekomPin, $dataMutasi, $dataTabungan, $dataRingkasan, $dataAnalisis, $dataRecomCA, $dataAsJiwa, $dataAsJaminan);

        DB::connection('web')->beginTransaction();
        try{

            DB::connection('web')->table('fasilitas_pinjaman')->where('id_transaksi', $id_transaksi)->update($dataFaspin);

            DB::connection('web')->table('kapasitas_bulanan')->where('id_transaksi', $id_transaksi)->update($dataKapbul);

            DB::connection('web')->table('pendapatan_usaha_cadebt')->where('id_transaksi', $id_transaksi)->update($dataUsaha);

            DB::connection('web')->table('ringkasan_analisa_ca')->insert($dataRingkasan);
            DB::connection('web')->table('rekomendasi_pinjaman')->insert($dataRekomPin);
            DB::connection('web')->table('asuransi_jiwa')->insert($dataAsJiwa);

            if (!empty($dataAsJaminan)) {
                DB::connection('web')->table('asuransi_jaminan')->insert($dataAsJaminan);
            }
            
            DB::connection('web')->table('mutasi_bank')->insert($dataMutasi);
            DB::connection('web')->table('log_tabungan_debt')->insert($dataTabungan);
            DB::connection('web')->table('informasi_analisa_cc')->insert($dataAnalisis);
            DB::connection('web')->table('recom_ca')->insert($dataRecomCA);

            DB::connection('web')->table('tb_transaksi')->where('id', $id_transaksi)->update($dataTransaksi);

            DB::connection('web')->commit();

            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'message'=> 'Data untuk CA berhasil dikirim',
                'data'   => [
                    'transaksi'          => $dataTransaksi,
                    'Fasilitas_pinjaman' => $dataFaspin,
                    'kapasitas_bulanan'  => $dataKapbul,
                    'pendapatan_usaha'   => $dataUsaha,
                    'mutasi_bank'        => $dataMutasi,
                    'tabungan'           => $dataTabungan,
                    'analisa_cc'         => $dataAnalisis,
                    'rekomendasi_ca'     => $dataRecomCA,

                    'rekomendasi_pinjaman' => $dataRekomPin,
                    'ringkasan_analisa'    => $dataRingkasan,
                    'asuransi_jiwa'        => $dataAsJiwa,
                    'asuransi_jaminan'     => empty($dataAsJaminan) ? null : $dataAsJaminan
                ]
            ], 200);
        } catch (\Exception $e) {
            $err = DB::connection('web')->rollback();
            return response()->json([
                'code'    => 501,
                'status'  => 'error',
                'message' => $err
            ], 501);
        }
    }

    public function list(Request $req)
    {
        $pic = $req->pic;

        $id_area   = $pic->id_area;
        $id_cabang = $pic->id_cabang;
        $scope     = $pic->jpic['cakupan'];

        $query_dir = DB::connection('web')->table('view_transaksi')
        ->where('status_ca', 'recommend')->get()->toArray();
                
        $query = Helper::checkDir($scope, $query_dir, $id_area, $id_cabang);

        if (!$query) {
            return response()->json([
                "code"    => 404,
                "status"  => "not found",
                "message" => "Data di CA belum ada yang di ubah"
            ], 404);
        }

        $data = array();
        foreach ($query as $val) {
            $data[] = [
                // 'status_revisi'  => $val->revisi >= 1 ? 'Y' : 'N',
                'id_trans_so'    => $val->id,
                'nomor_so'       => $val->nomor_transaksi,
                'nama_so'        => $val->nama_so,
                'nama_ca'        => $val->nama_ca,
                // 'status_ca'      => $val->status_ca,
                // 'status_caa'     => $val->status_caa,
                // 'pic'            => $val->nama_ca,
                'tracking'  => [
                    'status' => [
                        'das'      => $val->status_das,
                        'hm'       => $val->status_hm,
                        'ao'       => $val->status_ao,
                        'ca'       => $val->status_ca,
                        'caa'      => $val->status_caa,
                        'approval' => $val->status_approval
                    ],
                    'pic'   => [
                        'so'    => $val->nama_so,
                        'das'   => $val->nama_das,
                        'hm'    => $val->nama_hm,
                        'ao'    => $val->nama_ao,
                        'ca'    => $val->nama_ca,
                        'caa'   => $val->nama_caa
                    ],
                    'tanggal' => [
                        'tgl_so'  => $val->tgl_so,
                        'tgl_das' => $val->tgl_das,
                        'tgl_hm'  => $val->tgl_hm,
                        'tgl_ao'  => $val->tgl_ao,
                        'tgl_ca'  => $val->tgl_ca,
                        'tgl_caa' => $val->tgl_caa
                    ]
                ],
                'area'           => $val->area,
                'cabang'         => $val->cabang,
                'asal_data'      => $val->asal_data,
                'nama_marketing' => $val->nama_marketing,
                'fasilitas_pinjaman' => [
                    'id'              => $val->id_fasilitas_pinjaman,
                    'plafon'          => $val->plafon,
                    'tenor'           => $val->tenor,
                    'jenis_pinjaman'  => $val->jenis_pinjaman,
                    'tujuan_pinjaman' => $val->tujuan_pinjaman
                ],
                'nama_debitur'   => $val->nama_cadeb,
                // 'rekomendasi_ao' => DB::connection('web')->table('recom_ao')->where('id_transaksi', $val->id)->first(),
                // 'rekomendasi_ca' => DB::connection('web')->table('recom_ca')->where('id_transaksi', $val->id)->first(),
                // 'rekomendasi_pinjaman' => DB::connection('web')->table('rekomendasi_pinjaman')->where('id_transaksi', $val->id)->first(),
                // 'agunan' => [
                //     'tanah'     => DB::connection('web')->table('agunan_tanah')->where('id_transaksi', $val->id)->select('id', 'jenis_sertifikat as jenis')->get(),
                //     'kendaraan' => DB::connection('web')->table('agunan_kendaraan')->where('id_transaksi', $val->id)->select('id', 'jenis')->get()
                // ],
                'tgl_so'  => $val->tgl_so,
                'tgl_das' => $val->tgl_das,
                'tgl_hm'  => $val->tgl_hm,
                'tgl_ao'  => $val->tgl_ao,
                // 'tgl_transaksi' => $val->tgl_ca,
                'tgl_ca'  => $val->tgl_ca,
                // 'approval'      => DB::connection('web')->table('tb_approval')->where('id_transaksi', $val->id)->select("id","id_pic","plafon","tenor","rincian", "status", "updated_at as tgl_approve")->get()
            ];
        }


        try {
            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'count'  => sizeof($data),
                'data'   => $data
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                "code"    => 501,
                "status"  => "error",
                "message" => $e
            ], 501);
        }
    }

    public function display($id_transaksi, Request $req)
    {
        $pic = $req->pic; // From PIC middleware

        $id_area   = $pic->id_area;
        $id_cabang = $pic->id_cabang;
        $scope     = $pic->jpic['cakupan'];

        $query_dir = DB::connection('web')->table('view_transaksi')
        ->where('status_ca', 'recommend')->get()->toArray();

        $query = Helper::checkDir($scope, $query_dir, $id_area, $id_cabang);

        if (!$query) {
            return response()->json([
                'code'    => 404,
                'status'  => 'not found',
                'message' => 'Transaksi dengan id '.$id.' belum selesai diproses oleh CA'
            ], 404);
        }

        $transaksi = $query[0];

        $mutasi = MutasiBank::where('id_transaksi', $id_transaksi)->get()->toArray();
           
        if($mutasi != []){
            foreach($mutasi as $i => $mut){
                $doub[$i] = array_slice($mut, 0, 5);
            }

            // $arr = array();
            foreach($mutasi as $i => $mut){
                $slice[$i] = array_slice($mut, 5);
                foreach($slice as $key => $val){
                    foreach($val as $row => $col){
                        $arr[$i][$row] = explode(";",$col);
                    }
                }
            }

            // $dataMut = array();
            foreach ($arr as $key => $subarr)
            {
                foreach ($subarr as $subkey => $subvalue)
                {
                    foreach($subvalue as $childkey => $childvalue)
                    {   
                        $out[$key][$childkey][$subkey] = ($childvalue);
                    }

                    $dataMutasi[$key] = array_merge($doub[$key], array('table' => $out[$key]));
                }
            }
        }else{
            $dataMutasi = null;
        }

        // $check_ca->getRelations(); // get all the related models
        // $check_ca->getRelation('author'); // to get only related author model

        $data = array(
            'id_trans_so' => $transaksi->id,
            'nomor_so'    => $transaksi->nomor_transaksi,
            'nama_so'     => $transaksi->nama_so,
            'nama_ao'     => $transaksi->nama_ao,
            'nama_ca'     => $transaksi->nama_ca,
            'tracking'  => [
                'status' => [
                    'das'      => $transaksi->status_das,
                    'hm'       => $transaksi->status_hm,
                    'ao'       => $transaksi->status_ao,
                    'ca'       => $transaksi->status_ca,
                    'caa'      => $transaksi->status_caa,
                    'approval' => $transaksi->status_approval
                ],
                'pic'   => [
                    'so'    => $transaksi->nama_so,
                    'das'   => $transaksi->nama_das,
                    'hm'    => $transaksi->nama_hm,
                    'ao'    => $transaksi->nama_ao,
                    'ca'    => $transaksi->nama_ca,
                    'caa'   => $transaksi->nama_caa
                ],
                'tanggal' => [
                    'tgl_so'  => $transaksi->tgl_so,
                    'tgl_das' => $transaksi->tgl_das,
                    'tgl_hm'  => $transaksi->tgl_hm,
                    'tgl_ao'  => $transaksi->tgl_ao,
                    'tgl_ca'  => $transaksi->tgl_ca,
                    'tgl_caa' => $transaksi->tgl_caa
                ]
            ],
            'data_debitur'  => DB::connection('web')->table('calon_debitur')->where('id_transaksi', $id_transaksi)->first(),
            'data_pasangan' => DB::connection('web')->table('pasangan_calon_debitur')->where('id_transaksi', $id_transaksi)->first(),
            'data_penjamin' => DB::connection('web')->table('penjamin_calon_debitur')->where('id_transaksi', $id_transaksi)->get(),

            // Setelah input di AO
            'data_agunan' => [
                'agunan_tanah' => DB::connection('web')->table('agunan_tanah')->where('id_transaksi', $id_transaksi)->get(),
                'agunan_kendaraan' => DB::connection('web')->table('agunan_kendaraan')->where('id_transaksi', $id_transaksi)->get(),
            ],
            'pemeriksaan' => [
                'agunan_tanah' => DB::connection('web')->table('periksa_agunan_tanah')->where('id_transaksi', $id_transaksi)->get(),
                'agunan_kendaraan' => DB::connection('web')->table('periksa_agunan_kendaraan')->where('id_transaksi', $id_transaksi)->get(),
            ],
            'verifikasi'    => DB::connection('web')->table('tb_verifikasi')->where('id_transaksi', $id_transaksi)->first(),
            'validasi'      => DB::connection('web')->table('tb_validasi')->where('id_transaksi', $id_transaksi)->first(),
            'kapasitas_bulanan' => DB::connection('web')->table('kapasitas_bulanan')->where('id_transaksi', $id_transaksi)->first(),
            'pendapatan_usaha' => DB::connection('web')->table('pendapatan_usaha_cadebt')->where('id_transaksi', $id_transaksi)->first(),
            'rekomendasi_ao' => DB::connection('web')->table('recom_ao')->where('id_transaksi', $id_transaksi)->first(),

            'mutasi_bank'           => $dataMutasi,
            'data_keuangan'         => DB::connection('web')->table('log_tabungan_debt')->where('id_transaksi', $id_transaksi)->get(),
            'informasi_analisa_cc'  => array(
                'table'         => $iac = InfoACC::where('id_transaksi', $id_transaksi)->get()->toArray(),
                'total_plafon'  => array_sum(array_column($iac,'plafon')),
                'total_baki_debet' => array_sum(array_column($iac,'baki_debet')),
                'angsuran'         => array_sum(array_column($iac,'angsuran')),
                'collectabitas_tertinggi' => max(array_column($iac,'collectabilitas'))
            ),
            'ringkasan_analisa'     => DB::connection('web')->table('ringkasan_analisa_ca')->where('id_transaksi', $id_transaksi)->first(),
            'rekomendasi_pinjaman'  => DB::connection('web')->table('rekomendasi_pinjaman')->where('id_transaksi', $id_transaksi)->first(),
            'rekomendasi_ca'        => DB::connection('web')->table('recom_ca')->where('id_transaksi', $id_transaksi)->first(),
            'asuransi_jiwa'         => DB::connection('web')->table('asuransi_jiwa')->where('id_transaksi', $id_transaksi)->first(),
            'asuransi_jaminan'      => DB::connection('web')->table('asuransi_jaminan')->where('id_transaksi', $id_transaksi)->get(),
            // 'status_ca'             => $transaksi->status_ca,
            'tgl_so'  => $transaksi->tgl_so,
            'tgl_das' => $transaksi->tgl_das,
            'tgl_hm'  => $transaksi->tgl_hm,
            'tgl_ao'  => $transaksi->tgl_ao,
            // 'tgl_transaksi'  => $transaksi->tgl_ca,
            'tgl_ca'  => $transaksi->tgl_ca
        );

        try {
            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'data'   => $data
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                "code"    => 501,
                "status"  => "error",
                "message" => $e
            ], 501);
        }
    }

    public function filter($memo, $status, Request $req)
    {
        $pic = $req->pic; // From PIC middleware

        if ($memo != 'ca' && $memo != 'caa') {
            return response()->json([
                'code'    => 404,
                'status'  => 'not found',
                'message' => 'filter hanya aktif untuk ca dan caa'
            ], 404);
        }

        if ($status != 'recommend' && $status != 'waiting' && $status != 'not_recommend') {
            return response()->json([
                'code'    => 404,
                'status'  => 'not found',
                'message' => 'status hanya diantara berikut: recommend, not_recommend, waiting'
            ], 404);
        }

        $id_area   = $pic->id_area;
        $id_cabang = $pic->id_cabang;
        $scope     = $pic->jpic['cakupan'];

        $query_dir = DB::connection('web')->table('view_transaksi')->get()->toArray();

        $query = Helper::checkDir($scope, $query_dir, $id_area, $id_cabang);

        $subQuery = Helper::filter($query, "status_{$memo}", $status, false, false, false);

        if (!$subQuery) {
            return response()->json([
                'code'    => 404,
                'status'  => 'not found',
                'message' => 'Data di tidak ditemukan'
            ], 404);
        }

        $tgl = "tgl_{$memo}";

        $data = array();
        foreach ($subQuery as $key => $val) {
            $data[] = [
                'id_trans_so'    => $val->id,
                'nomor_so'       => $val->nomor_transaksi,
                "ao" => [
                    'status_ao'     => $val->status_ao,
                    'catatan_ao'    => $val->catatan_ao
                ],
                "ca" => [
                    'status_ca'     => $val->status_ca,
                    'catatan_ca'    => $val->catatan_ca
                ],
                // 'pic'            => $val->pic,
                'pic' => [
                    'so'    => $val->nama_so,
                    'ao'    => $val->nama_ao,
                    'ca'    => $val->nama_ca,
                ],
                'tracking'  => [
                    'status' => [
                        'das'      => $val->status_das,
                        'hm'       => $val->status_hm,
                        'ao'       => $val->status_ao,
                        'ca'       => $val->status_ca,
                        'caa'      => $val->status_caa,
                        'approval' => $val->status_approval
                    ],
                    'pic'   => [
                        'so'    => $val->nama_so,
                        'das'   => $val->nama_das,
                        'hm'    => $val->nama_hm,
                        'ao'    => $val->nama_ao,
                        'ca'    => $val->nama_ca,
                        'caa'   => $val->nama_caa
                    ],
                    'tanggal' => [
                        'tgl_so'  => $val->tgl_so,
                        'tgl_das' => $val->tgl_das,
                        'tgl_hm'  => $val->tgl_hm,
                        'tgl_ao'  => $val->tgl_ao,
                        'tgl_ca'  => $val->tgl_ca,
                        'tgl_caa' => $val->tgl_caa
                    ]
                ],
                'area'           => $val->area,
                'cabang'         => $val->cabang,
                'asal_data'      => $val->asal_data,
                'nama_marketing' => $val->nama_marketing,
                'nama_debitur'   => $val->nama_cadeb,
                'plafon'         => $val->plafon,
                'tenor'          => $val->tenor,
                'tgl_transaksi'  => $val->$tgl
            ];
        }
        
        try {
            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'count'  => sizeof($data),
                'data'   => $data
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                "code"    => 501,
                "status"  => "error",
                "message" => $e
            ], 501);
        }
    }

    public function search($search, Request $req)
    {
        $pic = $req->pic; // From PIC middleware

        $id_area   = $pic->id_area;
        $id_cabang = $pic->id_cabang;
        $scope     = $pic->jpic['cakupan'];

        $query_dir = DB::connection('web')->select("CALL cari_transaksi('{$search}')");

        $query = Helper::checkDir($scope, $query_dir, $id_area, $id_cabang);

        $subQuery = Helper::filter($query, "status_ao", 'recommend', false, false, false);

        if (!$subQuery) {
            return response()->json([
                'code'    => 404,
                'status'  => 'not found',
                'message' => 'Pencarian tidak ditemukan'
            ], 404);
        }

        $data = array();
        foreach ($subQuery as $val) 
        {
            $data[] = [
                'id_trans_so'    => $val->id,
                'nomor_so'       => $val->nomor_transaksi,
                // 'nomor_ao'       => $val->nomor_ao,
                // 'nomor_ca'       => $val->nomor_ca,
                'tracking'  => [
                    'status' => [
                        'das'      => $val->status_das,
                        'hm'       => $val->status_hm,
                        'ao'       => $val->status_ao,
                        'ca'       => $val->status_ca,
                        'caa'      => $val->status_caa,
                        'approval' => $val->status_approval
                    ],
                    'pic'   => [
                        'so'    => $val->nama_so,
                        'das'   => $val->nama_das,
                        'hm'    => $val->nama_hm,
                        'ao'    => $val->nama_ao,
                        'ca'    => $val->nama_ca,
                        'caa'   => $val->nama_caa
                    ],
                    'tanggal' => [
                        'tgl_so'  => $val->tgl_so,
                        'tgl_das' => $val->tgl_das,
                        'tgl_hm'  => $val->tgl_hm,
                        'tgl_ao'  => $val->tgl_ao,
                        'tgl_ca'  => $val->tgl_ca,
                        'tgl_caa' => $val->tgl_caa
                    ]
                ],
                'nama_so'        => $val->nama_so,
                'nama_ao'        => $val->nama_ao,
                'pic'            => $val->nama_ca,
                'nama_ca'        => $val->nama_ca,
                'area'           => $val->area,
                'cabang'         => $val->cabang,
                'asal_data'      => $val->asal_data,
                'nama_marketing' => $val->nama_marketing,
                'nama_debitur'   => $val->nama_cadeb,
                'plafon'         => $val->plafon,
                'tenor'          => $val->tenor,
                'status_ao'      => $val->status_ao,
                'tgl_so'         => $val->tgl_so,
                'tgl_das'        => $val->tgl_das,
                'tgl_hm'         => $val->tgl_hm,
                'tgl_ao'         => $val->tgl_ao,
                'tgl_transaksi'  => $val->tgl_ca
            ];
        }

        try {
            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'count'  => sizeof($data),
                'data'   => $data
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                "code"    => 501,
                "status"  => "error",
                "message" => $e
            ], 501);
        }
    }
}