<?php

namespace App\Http\Controllers\Transaksi;

use Laravel\Lumen\Routing\Controller as BaseController;
use App\Http\Controllers\Controller as Helper;

use App\Models\Transaksi\Nasabah\Penjamin;
use App\Models\Transaksi\Nasabah\Pasangan;
use App\Models\Transaksi\Nasabah\Debitur;
use App\Models\Transaksi\Transaksi;
use Illuminate\Support\Facades\File;

use Illuminate\Http\Request;
use Carbon\Carbon;
use DB;

class Admin_Controller extends BaseController
{
    public function show($id_transaksi, Request $req)
    {
        $pic = $req->pic; // From PIC middleware

        $id_area   = $pic->id_area;
        $id_cabang = $pic->id_cabang;
        $scope     = $pic->jpic['cakupan'];

        $query_dir = DB::connection('web')->table('view_transaksi')->where('id', $id_transaksi)->get()->toArray();

        $query = Helper::checkDir($scope, $query_dir, $id_area, $id_cabang);

        if (!$query) {
            return response()->json([
                "code"    => 404,
                "status"  => "not found",
                "message" => "Data dengan id ".$id_transaksi." tidak ditemukan"
            ], 404);
        }

        $transaksi  = $query[0];

        $pen = Penjamin::whereIn('id', explode(",", $transaksi->id_penjamin))->get();

        if ($pen != '[]') {
            $penjamin = array();
            foreach ($pen as $key => $value) {
                $penjamin[$key] = [
                    "id"               => $value->id,
                    "nama_ktp"         => $value->nama_ktp,
                    "nama_ibu_kandung" => $value->nama_ibu_kandung,
                    "no_ktp"           => $value->no_ktp,
                    "no_npwp"          => $value->no_npwp,
                    "tempat_lahir"     => $value->tempat_lahir,
                    "tgl_lahir"        => $value->tgl_lahir,
                    "jenis_kelamin"    => $value->jenis_kelamin,
                    "alamat_ktp"       => $value->alamat_ktp,
                    "no_telp"          => $value->no_telp,
                    "hubungan_debitur" => $value->hubungan_debitur,
                    "lampiran" => [
                        "lamp_ktp"          => $value->lamp_ktp,
                        "lamp_ktp_pasangan" => $value->lamp_ktp_pasangan,
                        "lamp_kk"           => $value->lamp_kk,
                        "lamp_buku_nikah"   => $value->lamp_buku_nikah
                    ]
                ];
            }
        }else{
            $penjamin = null;
        }

        $debitur = Debitur::where('id_transaksi', $id_transaksi)->first();

        $data = [
            'id'             => $transaksi->id,
            'nomor_so'       => $transaksi->nomor_transaksi,
            'nama_so'        => $transaksi->nama_so,
            'area'   => [
                'id'    => $transaksi->id_area,
                'nama'  => $transaksi->area
            ],
            'id_cabang'      => $transaksi->id_cabang,
            'nama_cabang'    => $transaksi->cabang,
            'asal_data'      => $transaksi->asal_data,
            'nama_marketing' => $transaksi->nama_marketing,
            'tracking'  => [
                'status' => [
                    'das'      => $transaksi->status_das,
                    'hm'       => $transaksi->status_hm,
                    'ao'       => $transaksi->status_ao,
                    'ca'       => $transaksi->status_ca,
                    'caa'      => $transaksi->status_caa,
                    'approval' => $transaksi->status_approval
                ],
                'pic'   => [
                    'so'    => $transaksi->nama_so,
                    'das'   => $transaksi->nama_das,
                    'hm'    => $transaksi->nama_hm,
                    'ao'    => $transaksi->nama_ao,
                    'ca'    => $transaksi->nama_ca,
                    'caa'   => $transaksi->nama_caa
                ],
                'tanggal' => [
                    'tgl_so'  => $transaksi->tgl_so,
                    'tgl_das' => $transaksi->tgl_das,
                    'tgl_hm'  => $transaksi->tgl_hm,
                    'tgl_ao'  => $transaksi->tgl_ao,
                    'tgl_ca'  => $transaksi->tgl_ca,
                    'tgl_caa' => $transaksi->tgl_caa
                ]
            ],
            'das'=> [
                'status'  => $transaksi->status_das,
                'catatan' => $transaksi->catatan_das
            ],
            'hm' => [
                'status'  => $transaksi->status_hm,
                'catatan' => $transaksi->catatan_hm
            ],
            'plafon'          => $transaksi->plafon,
            'tenor'           => $transaksi->tenor,
            'fasilitas_pinjaman'  => [
                'id'              => $transaksi->id_fasilitas_pinjaman,
                'jenis_pinjaman'  => $transaksi->jenis_pinjaman,
                'tujuan_pinjaman' => $transaksi->tujuan_pinjaman,
                'plafon'          => $transaksi->plafon,
                'tenor'           => $transaksi->tenor,
            ],
            'data_debitur' => [
                'id'                    => $debitur->id,
                'nama_lengkap'          => $debitur->nama_lengkap,
                'gelar_keagamaan'       => $debitur->gelar_keagamaan,
                'gelar_pendidikan'      => $debitur->gelar_pendidikan,
                'jenis_kelamin'         => $debitur->jenis_kelamin,
                'status_nikah'          => $debitur->status_nikah,
                'ibu_kandung'           => $debitur->ibu_kandung,
                'no_ktp'                => $debitur->no_ktp,
                'no_ktp_kk'             => $debitur->no_ktp_kk,
                'no_kk'                 => $debitur->no_kk,
                'no_npwp'               => $debitur->no_npwp,
                'tempat_lahir'          => $debitur->tempat_lahir,
                'tgl_lahir'             => $debitur->tgl_lahir,
                'agama'                 => $debitur->agama,
                'alamat_ktp'            => $debitur->alamat_ktp,
                'rt_ktp'                => $debitur->rt_ktp,
                'rw_ktp'                => $debitur->rw_ktp,
                'provinsi_ktp'          => $debitur->id_prov_ktp,
                'nama_provinsi_ktp'     => $debitur->prov_ktp['nama'],
                'kabupaten_ktp'         => $debitur->id_kab_ktp,
                'nama_kabupaten_ktp'    => $debitur->kab_ktp['nama'],
                'kecamatan_ktp'         => $debitur->id_kec_ktp,
                'nama_kecamatan_ktp'    => $debitur->kec_ktp['nama'],
                'kelurahan_ktp'         => $debitur->id_kel_ktp,
                'nama_kelurahan_ktp'    => $debitur->kel_ktp['nama'],
                'kode_pos_ktp'          => $debitur->kel_ktp['kode_pos'],
                'alamat_domisili'       => $debitur->alamat_domisili,
                'rt_domisili'           => $debitur->rt_domisili,
                'rw_domisili'           => $debitur->rw_domisili,
                'provinsi_domisili'     => $debitur->id_prov_domisili,
                'nama_provinsi_domisili'=> $debitur->prov_dom['nama'],
                'kabupaten_domisili'    => $debitur->id_kab_domisili,
                'nama_kabupaten_domisili'=> $debitur->kab_dom['nama'],
                'kecamatan_domisili'    => $debitur->id_kec_domisili,
                'nama_kecamatan_domisili'=> $debitur->kec_dom['nama'],
                'kelurahan_domisili'    => $debitur->id_kel_domisili,
                'nama_kelurahan_domisili' => $debitur->kel_dom['nama'],
                'kode_pos_domisili'     => $debitur->kel_dom['kode_pos'],
                'pendidikan_terakhir'   => $debitur->pendidikan_terakhir,
                'jumlah_tanggungan'     => $debitur->jumlah_tanggungan,
                'no_telp'               => $debitur->no_telp,
                'no_hp'                 => $debitur->no_hp,
                'alamat_surat'          => $debitur->alamat_surat,
                'lamp_ktp'              => $debitur->lamp_ktp,
                'lamp_kk'               => $debitur->lamp_kk,
                'lamp_sertifikat'       => $debitur->lamp_sertifikat,
                'lamp_sttp_pbb'         => $debitur->lamp_sttp_pbb,
                'lamp_imb'              => $debitur->lamp_imb
            ],
            'data_pasangan' => DB::connection('web')->table('pasangan_calon_debitur')
            ->where('id_transaksi', $id_transaksi)
            ->select(
                'nama_lengkap', 'nama_ibu_kandung', 'jenis_kelamin', 'no_ktp', 'no_ktp_kk', 'no_npwp', 'tempat_lahir', DB::connection('web')->raw('DATE_FORMAT(tgl_lahir, "%d-%m-%Y") as tgl_lahir'), 'alamat_ktp', 'no_telp', 'lamp_ktp', 'lamp_buku_nikah'
            )->first(),
            'data_penjamin' => $penjamin,
            'status'        => $transaksi->status_das,
            'note'          => $transaksi->catatan_das,
            'lampiran'  => [
                'ideb'    => explode(";", $transaksi->lamp_ideb),
                'pefindo' => explode(";", $transaksi->lamp_pefindo)
            ],
            'tgl_transaksi' => $transaksi->tgl_so
        ];

        try {
            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'data'   => $data
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                "code"    => 501,
                "status"  => "error",
                "message" => $e
            ], 501);
        }
    }

    public function update($id_transaksi, Request $req)
    {
        $pic = $req->pic; // From PIC middleware

        $check_trans = DB::connection('web')->table('view_transaksi')->where('id', $id_transaksi)->select('nomor_transaksi', 'id_pic_das', 'id_pic_hm', 'status_das', 'catatan_das', 'status_hm', 'catatan_hm', 'lamp_ideb', 'lamp_pefindo', 'form_persetujuan_ideb')->first();

        if (!$check_trans) {
            return response()->json([
                'code'    => 404,
                'status'  => 'not found',
                'message' => 'Data Tidak Ada!!'
            ], 404);
        }

        $lamp_dir = 'public/'.$check_trans->nomor_transaksi;

        if($files = $req->file('lamp_ideb')){
            
            $path = $lamp_dir.'/ideb';

            $check = $check_trans->lamp_ideb;

            $arrayPath = array();
            foreach($files as $file)
            {
                $exIdeb = $file->getClientOriginalExtension();

                if ($exIdeb != 'ideb' && $exIdeb != 'pdf')
                {
                    return response()->json([
                        "code"    => 422,
                        "status"  => "not valid request",
                        "message" => "file ideb harus berupa format ideb / pdf"
                    ], 422);
                }

                // Check Directory
                if(!File::isDirectory($path)){
                    File::makeDirectory($path, 0777, true, true);
                }
                    
                // Delete File is Exists
                if(!empty($check))
                {
                    File::delete($check);
                }

                $name = $file->getClientOriginalName();

                // Save Image to Directory
                $file->move($path, $name);
                $arrayPath[] = $path . '/' . $name;
            }

            $im_ideb = implode(";", $arrayPath);
        }else{
            $im_ideb = $check_trans->lamp_ideb;
        }

        if($files = $req->file('lamp_pefindo')){
            
            $check = $check_trans->lamp_pefindo;
            $path  = $lamp_dir.'/pefindo';
            $name  = '';

            $arrayPath = array();
            foreach($files as $file)
            {
                $exIdeb = $file->getClientOriginalExtension();

                if (
                    $exIdeb != 'png' && 
                    $exIdeb != 'jpg' &&
                    $exIdeb != 'jpeg'&&
                    $exIdeb != 'PNG' &&
                    $exIdeb != 'JPG' &&
                    $exIdeb != 'JPEG'&&
                    $exIdeb != 'pdf' &&
                    $exIdeb != 'PDF'
                    )
                {
                    return response()->json([
                        "code"    => 422,
                        "status"  => "not valid request",
                        "message" => "file pefindo harus berformat: png, jpg, jpeg, pdf"
                    ], 422);
                }

                $arrayPath[] = Helper::uploadImg($check, $file, $path, $name);
            }

            $im_pef = implode(";", $arrayPath);
        }else{
            $im_pef = $check_trans->lamp_pefindo;
        }

        if ($check_trans->status_das == 'complete') {
            $data = array(
                'id_pic_hm'   => $pic->id,
                'status_hm'   => empty($req->input('status_hm')) ? 1 : $req->input('status_hm'),
                'catatan_hm'  => empty($req->input('catatan_hm')) ? $check_trans->catatan_hm : $req->input('catatan_hm'),
                'tgl_hm'      => Carbon::now()->toDateTimeString()
            );
        }else{
            $data = array(
                'id_pic_das'  => $pic->id,
                'catatan_das' => empty($req->input('catatan_das')) ? $check_trans->catatan_das : $req->input('catatan_das'),
                'status_das'  => empty($req->input('status_das')) ? 1 : $req->input('status_das'),
                'lamp_ideb'   => $im_ideb,
                'lamp_pefindo'=> $im_pef,
                'tgl_das'     => Carbon::now()->toDateTimeString()
            );
        }


        DB::connection('web')->beginTransaction();

        try{
            Transaksi::where('id', $id_transaksi)->update($data);

            DB::connection('web')->commit();

            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'message'=> 'Data berhasil dibuat',
                'data'   => $data
            ], 200);
        }catch (\Exception $e) {
            $err = DB::connection('web')->rollback();
            return response()->json([
                'code'    => 501,
                'status'  => 'error',
                'message' => 'terjadi kesalahan, mohon beri laporan kepada backend'
            ], 501);
        }
    }

    public function search($search, Request $req)
    {
        $pic = $req->pic; // From PIC middleware

        $id_area   = $pic->id_area;
        $id_cabang = $pic->id_cabang;
        $scope     = $pic->jpic['cakupan'];

        $query_dir = DB::connection('web')->select("CALL cari_transaksi('{$search}')");

        $query = Helper::checkDir($scope, $query_dir, $id_area, $id_cabang);

        Helper::filter($query, 'status_ao', 'waiting', false, false, false);

        if (empty($query)) {
            return response()->json([
                'code'    => 404,
                'status'  => 'not found',
                'message' => 'Pencarian tidak ditemukan'
            ], 404);
        }

        $data = array();
        foreach ($query as $key => $val) 
        {
            $data[] = array(
                "id"              => $val->id,
                "nomor_transaksi" => $val->nomor_transaksi, 
                "nama_so"         => $val->nama_so,
                "area"            => $val->area,
                "cabang"          => $val->cabang,
                "asal_data"       => $val->asal_data,
                "nama_marketing"  => $val->nama_marketing,
                "nama_cadeb"      => $val->nama_cadeb,
                'fasilitas_pinjaman'  => [
                    'id'              => $val->id_fasilitas_pinjaman,
                    'jenis_pinjaman'  => $val->jenis_pinjaman,
                    'tujuan_pinjaman' => $val->tujuan_pinjaman,
                    'plafon'          => $val->plafon,
                    'tenor'           => $val->tenor,
                ],
                'tracking'  => [
                    'status' => [
                        'das'      => $val->status_das,
                        'hm'       => $val->status_hm,
                        'ao'       => $val->status_ao,
                        'ca'       => $val->status_ca,
                        'caa'      => $val->status_caa,
                        'approval' => $val->status_approval
                    ],
                    'pic'   => [
                        'so'    => $val->nama_so,
                        'das'   => $val->nama_das,
                        'hm'    => $val->nama_hm,
                        'ao'    => $val->nama_ao,
                        'ca'    => $val->nama_ca,
                        'caa'   => $val->nama_caa
                    ],
                    'tanggal' => [
                        'tgl_so'  => $val->tgl_so,
                        'tgl_das' => $val->tgl_das,
                        'tgl_hm'  => $val->tgl_hm,
                        'tgl_ao'  => $val->tgl_ao,
                        'tgl_ca'  => $val->tgl_ca,
                        'tgl_caa' => $val->tgl_caa
                    ]
                ],
                "tgl_so"  => $val->tgl_so
            );
        }

        try {
            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'count'  => sizeof($data),
                'data'   => $data
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                "code"    => 501,
                "status"  => "error",
                "message" => $e
            ], 501);
        }
    }

    public function list_das(Request $req)
    {
        $pic = $req->pic; // From PIC middleware

        $id_area   = $pic->id_area;
        $id_cabang = $pic->id_cabang;
        $scope     = $pic->jpic['cakupan'];

        $query_dir = DB::connection('web')->table('view_transaksi')
        ->where('status_das', 'complete')->get()->toArray();
                
        $query = Helper::checkDir($scope, $query_dir, $id_area, $id_cabang);

        if (!$query) {
            return response()->json([
                "code"    => 404,
                "status"  => "not found",
                "message" => "Data di SO belum ada yang di ubah"
            ], 404);
        }

        foreach ($query as $val) {
            // $data[$key] = [
            //     'id'             => $val->id,
            //     'nomor_transaksi'=> $val->nomor_transaksi,
                // 'tracking'  => [
                //     'status' => [
                //         'das'      => $val->status_das,
                //         'hm'       => $val->status_hm,
                //         'ao'       => $val->status_ao,
                //         'ca'       => $val->status_ca,
                //         'caa'      => $val->status_caa,
                //         'approval' => $val->status_approval
                //     ],
                //     'pic'   => [
                //         'so'    => $val->nama_so,
                //         'das'   => $val->nama_das,
                //         'hm'    => $val->nama_hm,
                //         'ao'    => $val->nama_ao,
                //         'ca'    => $val->nama_ca,
                //         'caa'   => $val->nama_caa
                //     ],
                //     'tanggal' => [
                //         'tgl_so'  => $val->tgl_so,
                //         'tgl_das' => $val->tgl_das,
                //         'tgl_hm'  => $val->tgl_hm,
                //         'tgl_ao'  => $val->tgl_ao,
                //         'tgl_ca'  => $val->tgl_ca,
                //         'tgl_caa' => $val->tgl_caa
                //     ]
                // ],
            //     'nama_so'        => $val->nama_so,
            //     'area'           => $val->area,
            //     'cabang'         => $val->cabang,
            //     'asal_data'      => $val->asal_data,
            //     'nama_marketing' => $val->nama_marketing,
            //     'nama_debitur'   => $val->nama_cadeb,
            //     'plafon'         => $val->plafon,
            //     'tenor'          => $val->tenor,
            //     'tgl_so'         => $val->tgl_so
            // ];
            
            $data[] = [
                'id'       => $val->id,
                'nomor_so' => $val->nomor_transaksi,
                'das'      => [
                    'status'  => $val->status_das,
                    'catatan' => $val->catatan_das
                ],
                'hm'            => [
                    'status'  => $val->status_hm,
                    'catatan' => $val->catatan_hm
                ],
                'ao'            => [
                    'status'  => $val->status_ao,
                    'catatan' => $val->catatan_ao
                ],
                'pic'            => $val->nama_so,
                'area'           => $val->area,
                'cabang'         => $val->cabang,
                'asal_data'      => $val->asal_data,
                'nama_marketing' => $val->nama_marketing,
                'nama_debitur'   => $val->nama_cadeb,
                'plafon'         => $val->plafon,
                'tenor'          => $val->tenor,
                'tgl_transaksi'  => $val->tgl_so
            ];
        }

        try {
            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'count'  => sizeof($data),
                'data'   => $data
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                "code"    => 501,
                "status"  => "error",
                "message" => $e
            ], 501);
        }
    }

    public function list_hm(Request $req)
    {
        $pic = $req->pic; // From PIC middleware

        $id_area   = $pic->id_area;
        $id_cabang = $pic->id_cabang;
        $scope     = $pic->jpic['cakupan'];

        $query_dir = DB::connection('web')->table('view_transaksi')
        ->where('status_das', 'complete')
        ->where('status_hm', 'complete')
        ->get()->toArray();
                
        $query = Helper::checkDir($scope, $query_dir, $id_area, $id_cabang);

        if (!$query) {
            return response()->json([
                "code"    => 404,
                "status"  => "not found",
                "message" => "Data di Admin Das belum ada yang di ubah"
            ], 404);
        }

        foreach ($query as $key => $val) {            
            $data[$key] = [
                'id'       => $val->id,
                'nomor_so' => $val->nomor_transaksi,
                'das'      => [
                    'status'  => $val->status_das,
                    'catatan' => $val->catatan_das
                ],
                'hm'            => [
                    'status'  => $val->status_hm,
                    'catatan' => $val->catatan_hm
                ],
                'ao'            => [
                    'status'  => $val->status_ao,
                    'catatan' => $val->catatan_ao
                ],
                'pic'            => $val->nama_so,
                'area'           => $val->area,
                'cabang'         => $val->cabang,
                'asal_data'      => $val->asal_data,
                'nama_marketing' => $val->nama_marketing,
                'nama_debitur'   => $val->nama_cadeb,
                'plafon'         => $val->plafon,
                'tenor'          => $val->tenor,
                'tgl_transaksi'  => $val->tgl_so
            ];
        }

        try {
            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'count'  => sizeof($data),
                'data'   => $data
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                "code"    => 501,
                "status"  => "error",
                "message" => $e
            ], 501);
        }
    }
}