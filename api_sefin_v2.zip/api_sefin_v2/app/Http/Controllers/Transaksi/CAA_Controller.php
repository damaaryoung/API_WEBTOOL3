<?php

namespace App\Http\Controllers\Transaksi;

use Laravel\Lumen\Routing\Controller as BaseController;
use App\Http\Controllers\Controller as Helper;

// use App\Http\Requests\Transaksi\Kalkulasi\FaspinRequest;
use App\Http\Requests\Transaksi\Kalkulasi\PendapatanReq;
use App\Http\Requests\Transaksi\Kalkulasi\KapbulRequest;
use App\Http\Requests\Transaksi\Kalkulasi\MutasiRequest;
use App\Http\Requests\Transaksi\Kalkulasi\LogTabReq;
use App\Http\Requests\Transaksi\Kalkulasi\IACRequest;
use App\Http\Requests\Transaksi\Rekomendasi\RekomCaReq;

// use App\Models\Transaksi\Kalkulasi\FasilitasPinjaman;
// use App\Models\Transaksi\Kalkulasi\PendapatanUsaha;
// use App\Models\Transaksi\Kalkulasi\KapBulanan;

// use App\Models\Transaksi\Rekomendasi\RekomendasiPinjaman;
// use App\Models\Transaksi\Kalkulasi\RingkasanAnalisa;
// use App\Models\Transaksi\AsuransiJiwa\AsuransiJiwa;
// use App\Models\Transaksi\AsuransiJaminan\AsuransiJaminan;

use App\Models\Transaksi\TransCAA;
use App\Models\Transaksi\Approval;
use App\Models\Transaksi\Verifikasi\Penyimpangan;
use App\Models\Transaksi\Kalkulasi\MutasiBank;
// use App\Models\Transaksi\Kalkulasi\LogTabungan;
use App\Models\Transaksi\Kalkulasi\InfoACC;
// use App\Models\Transaksi\Rekomendasi\RekomendasiCA;
// use App\Models\Transaksi\Agunan\PemeriksaanAgunTan;
use App\Models\Transaksi\Transaksi;
use App\Models\Master\JPIC;
use Illuminate\Support\Facades\File;

use Illuminate\Http\Request;
use Carbon\Carbon;
use DB;

class CAA_Controller extends BaseController
{
    public function update($id_transaksi,  Request $req, PendapatanReq $us_req, KapbulRequest $kap_req, MutasiRequest $mut_req, LogTabReq $log_req, IACRequest $acc_req, RekomCaReq $ca_req)
    {
        $pic = $req->pic;

        $check_trans = Transaksi::where('id',$id_transaksi)
        ->where('status_ca', 1)->first();

        if (empty($check_trans)) {
            return response()->json([
                'code'    => 404,
                'status'  => 'not found',
                'message' => 'Transaksi dengan id '.$id_transaksi.' selesai di proses oleh CA'
            ], 404);
        }

        $dataTransaksi = array(
            'id_pic_caa' => $pic->id,
            'status_caa' => empty($req->input('status_caa')) ? 1 : $req->input('status_caa'),
            'catatan_caa' => $req->input('catatan_caa'),
            'tgl_caa'     => Carbon::now()->toDateTimeString()
        );

        $check_caa = DB::connection('web')->table('trans_caa')->where('id_transaksi', $id_transaksi)->first();

        if (empty($check_caa)) {
            /** Check Lampiran CAA */
            $check_file_report_mao      = '';
            $check_file_report_mca      = '';
            $check_file_tempat_tinggal  = '';
            $check_file_lain            = '';
            $check_file_usaha           = '';
            $check_file_agunan          = '';
            /** */
        }else{
            /** Check Lampiran CAA */
            $check_file_report_mao      = $check_caa->file_report_mao;
            $check_file_report_mca      = $check_caa->file_report_mca;
            $check_file_tempat_tinggal  = $check_caa->file_tempat_tinggal;
            $check_file_lain            = $check_caa->file_lain;
            $check_file_usaha           = $check_caa->file_usaha;
            $check_file_agunan          = $check_caa->file_agunan;
            /** */
        }


        // $lamp_dir = 'public/'.$check->debt['no_ktp'];
        $lamp_dir = 'public/' . $check_trans->nomor_transaksi; // $check_so->debt['no_ktp'];

        // file_report_mao
        if($file = $req->file('file_report_mao')){

            $path = $lamp_dir.'/mcaa/file_report_mao';

            $name = ''; //$file->getClientOriginalName();

            $check_file = $check_file_report_mao;
            
            $file_report_mao = Helper::uploadImg($check_file, $file, $path, $name);

        }else{
            $file_report_mao = $check_file_report_mao;
        }

        // file_report_mca
        if($file = $req->file('file_report_mca')){

            $path = $lamp_dir.'/mcaa/file_report_mca';

            $name = '';
            
            $check_file = $check_file_report_mca;
            
            $file_report_mca = Helper::uploadImg($check_file, $file, $path, $name);

        }else{
            $file_report_mca = $check_file_report_mca;
        }

        // Agunan Files Condition
        $statusFileAgunan = $req->input('status_file_agunan');

        if ($statusFileAgunan == 'ORIGINAL') {
            for ($i = 0; $i < count($req->file_agunan); $i++){
                $listAgunan[] = $req->file_agunan;
            }

            $file_agunan = implode(";", $listAgunan);
        }elseif($statusFileAgunan == 'CUSTOM'){

            if($files = $req->file('file_agunan')){

                $check_file = $check_file_agunan;
                $path = $lamp_dir.'/mcaa/file_agunan';
                $i = 0;
                
                $name = '';

                $arrayPath = array();
                foreach($files as $file)
                {
                    if (
                        $file->getClientOriginalExtension() != 'pdf'  &&
                        $file->getClientOriginalExtension() != 'jpg'  &&
                        $file->getClientOriginalExtension() != 'jpeg' &&
                        $file->getClientOriginalExtension() != 'png'  &&
                        $file->getClientOriginalExtension() != 'gif'
                    ){
                        return response()->json([
                            "code"    => 422,
                            "status"  => "not valid request",
                            "message" => ["file_usaha.".$i => ["file_usaha.".$i." harus bertipe jpg, jpeg, png, pdf"]]
                        ], 422);
                    }

                    $arrayPath[] = Helper::uploadImg($check_file, $file, $path, $name);
                }

                $file_agunan = implode(";", $arrayPath);
            }else{
                $file_agunan = $check_file_agunan;
            }
        }else{
            $file_agunan = null;
        }

        // Usaha Files Condition
        $statusFileUsaha = $req->input('status_file_usaha');
        if ($statusFileUsaha == 'ORIGINAL') {
            for ($i = 0; $i < count($req->input('file_usaha')); $i++){
                $listUsaha[] = $req->input('file_usaha');
            }

            $file_usaha = implode(";", $listUsaha);

        }elseif ($statusFileUsaha == 'CUSTOM') {

            if($files = $req->file('file_usaha')){
                $i = 0;
                $path = $lamp_dir.'/mcaa/file_usaha';
                $name = '';
                
                $check_file = $check_file_usaha;

                $arrayPath = array();
                foreach($files as $file)
                {
                    if (
                        $file->getClientOriginalExtension() != 'pdf'  &&
                        $file->getClientOriginalExtension() != 'jpg'  &&
                        $file->getClientOriginalExtension() != 'jpeg' &&
                        $file->getClientOriginalExtension() != 'png'  &&
                        $file->getClientOriginalExtension() != 'gif'
                    ){
                        return response()->json([
                            "code"    => 422,
                            "status"  => "not valid request",
                            "message" => ["file_usaha.".$i => ["file_usaha.".$i." harus bertipe jpg, jpeg, png, pdf"]]
                        ], 422);
                    }

                    $arrayPath[] = Helper::uploadImg($check_file, $file, $path, $name);
                }

                $file_usaha = implode(";", $arrayPath);
            }else{
                $file_usaha = $check_file_usaha;
            }
        }else{
            $file_usaha = null;
        }

        // Home File
        if($file = $req->file('file_tempat_tinggal')){

            $path = $lamp_dir.'/mcaa/file_tempat_tinggal';

            $name = '';
            
            $check_file = $check_file_tempat_tinggal;
            
            $file_report_mao = Helper::uploadImg($check_file, $file, $path, $name);

        }else{
            $file_tempat_tinggal = $check_file_tempat_tinggal;
        }

        // Othe File
        if($file = $req->file('file_lain')){

            $path = $lamp_dir.'/mcaa/file_lain';

            $name = '';
            
            $check_file = $check_file_lain;
            
            $file_lain = Helper::uploadImg($check_file, $file, $path, $name);

        }else{
            $file_lain = $check_file_lain;
        }

        // Email Team CAA
        if (!empty($req->input('team_caa'))) {
            $arrTeam = array();
            for ($i = 0; $i < count($req->input('team_caa')); $i++) {
                $arrTeam['team'][$i] = $req->input('team_caa')[$i];
            }

            $team_caa = implode(",", $arrTeam['team']);

        }else{
            $arrTeam  = null;
            $team_caa = null;
        }

        $dataTransaksi = array(
            'id_pic_caa' => $pic->id,
            'status_caa' => 1,
            'catatan_caa'=> $req->input('catatan_caa'),
            'tgl_caa'    => Carbon::now()->toDateTimeString()
        );

        $dataCAA = array(
            'id_transaksi'       => $id_transaksi,
            'pic_team_caa'       => $team_caa,
            'penyimpangan'       => $req->input('penyimpangan'),
            'rincian'            => $req->input('rincian'),
            'file_report_mao'    => $file_report_mao,
            'file_report_mca'    => $file_report_mca,
            'status_file_agunan' => $req->input('status_file_agunan'),
            'file_agunan'        => $file_agunan,
            'status_file_usaha'  => $req->input('status_file_usaha'),
            'file_usaha'         => $file_usaha,
            'file_tempat_tinggal'=> $file_tempat_tinggal,
            'file_lain'          => $file_lain,
            // 'created_at'         => Carbon::now()->toDateTimeString()
        );

        $dataPenyimpangan = array(
            'biaya_provisi'         => $req->input('biaya_provisi'),
            'biaya_admin'           => $req->input('biaya_admin'),
            'biaya_kredit'          => $req->input('biaya_kredit'),
            'ltv'                   => $req->input('ltv'),
            'tenor'                 => $req->input('tenor'),
            'kartu_pinjaman'        => $req->input('kartu_pinjaman'),
            'sertifikat_diatas_50'  => $req->input('sertifikat_diatas_50'),
            'sertifikat_diatas_150' => $req->input('sertifikat_diatas_150'),
            'profesi_beresiko'      => $req->input('profesi_beresiko'),
            'jaminan_kp_tenor_48'   => $req->input('jaminan_kp_tenor_48'),
        );

        // dd($dataCAA,$dataPenyimpangan,$approval);

        DB::connection('web')->beginTransaction();

        try {
            $storeCAA = TransCAA::create($dataCAA);

            if (!empty($dataPenyimpangan)) {
                DB::connection('web')->table('penyimpangan_caa')->insert(
                    array_merge($dataPenyimpangan, array('id_transaksi' => $id_transaksi, 'id_trans_caa' => $storeCAA->id))
                );
            }

            $approval = array();
            for ($i=0; $i < count($arrTeam['team']); $i++){

                $approval[] = DB::connection('web')->table('tb_approval')->insert([
                    'id_pic'        => $arrTeam['team'][$i],
                    'id_area'       => $pic->id_area,
                    'id_cabang'     => $pic->id_cabang,
                    'status'        => 'waiting',
                    'id_transaksi'  => $id_transaksi,
                    'id_trans_caa'  => $storeCAA->id,
                    'created_at'    => Carbon::now()->toDateTimeString()
                ]);
            }

            Transaksi::where('id', $id_transaksi)->update($dataTransaksi);

            DB::connection('web')->commit();

            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'message'=> 'Data untuk CAA berhasil dikirim',
                'data'   => [
                    'caa'          => $storeCAA,
                    'penyimpangan' => array_merge($dataPenyimpangan, array('id_transaksi' => $id_transaksi)),
                    'pic_approval' => $team_caa
                ]
            ], 200);
        } catch (\Exception $e) {
            $err = DB::connection('web')->rollback();
            return response()->json([
                'code'    => 501,
                'status'  => 'error',
                'message' => $err
            ], 501);
        }
    }

    public function list(Request $req)
    {
        $pic = $req->pic;

        $id_area   = $pic->id_area;
        $id_cabang = $pic->id_cabang;
        $scope     = $pic->jpic['cakupan'];

        $query_dir = DB::connection('web')->table('view_transaksi')
        ->where('status_ca', 'recommend')->get()->toArray();
                
        $query = Helper::checkDir($scope, $query_dir, $id_area, $id_cabang);

        if (!$query) {
            return response()->json([
                "code"    => 404,
                "status"  => "not found",
                "message" => "Data di CAA belum ada yang di ubah"
            ], 404);
        }

        $team_caa = JPIC::where('bagian', 'team_caa')->select('nama_jenis')->orderBy('urutan_jabatan', 'desc')->get()->toArray();

        $data = array();
        foreach ($query as $val) {

            $komite =  DB::connection('web')->table('tb_approval as appro')
                ->leftJoin('m_pic as pic', 'appro.id_pic', 'pic.id')
                ->leftJoin('mj_pic as jp', 'pic.id_mj_pic', 'jp.id')
                ->where('appro.id_transaksi', $val->id)
                ->select("appro.id","appro.id_pic","appro.plafon","appro.tenor","appro.rincian", "appro.status", "appro.updated_at as tgl_approve", "pic.nama as nama_pic", "pic.plafon_caa as max_plafon", "jp.nama_jenis as jabatan")->orderBy('jp.urutan_jabatan', 'desc')->get()->toArray();
            
            $team = array();
            $array_values = array();
            for ($i = 0; $i < sizeof($team_caa); $i++) {
                $array_values[] = $team_caa[$i]['nama_jenis'];
                $maps[] = Helper::filter($komite, 'jabatan', $team_caa[$i]['nama_jenis'], false, false, false);

                if (!$maps[$i]) {
                    $team[$i] = [];
                }else{
                    foreach ($maps[$i] as $key => $value) {
                        $team[] = $value;
                    }
                }
            }

            $combine = array_combine(str_replace(" ","_", $array_values), $team);

            $data[] = [
                // 'status_revisi'  => $val->revisi >= 1 ? 'Y' : 'N',
                'id_trans_so'    => $val->id,
                'nomor_so'       => $val->nomor_transaksi,
                'nama_so'        => $val->nama_so,
                'nama_ca'        => $val->nama_ca,
                'nama_caa'       => $val->nama_caa,
                // 'status_ca'      => $val->status_ca,
                // 'status_caa'     => $val->status_caa,
                // 'pic'            => $val->nama_ca,
                'tracking'  => [
                    'status' => [
                        'das'      => $val->status_das,
                        'hm'       => $val->status_hm,
                        'ao'       => $val->status_ao,
                        'ca'       => $val->status_ca,
                        'caa'      => $val->status_caa,
                        'approval' => $val->status_approval
                    ],
                    'pic'   => [
                        'so'    => $val->nama_so,
                        'das'   => $val->nama_das,
                        'hm'    => $val->nama_hm,
                        'ao'    => $val->nama_ao,
                        'ca'    => $val->nama_ca,
                        'caa'   => $val->nama_caa
                    ],
                    'tanggal' => [
                        'tgl_so'  => $val->tgl_so,
                        'tgl_das' => $val->tgl_das,
                        'tgl_hm'  => $val->tgl_hm,
                        'tgl_ao'  => $val->tgl_ao,
                        'tgl_ca'  => $val->tgl_ca,
                        'tgl_caa' => $val->tgl_caa
                    ]
                ],
                'area'           => $val->area,
                'cabang'         => $val->cabang,
                'asal_data'      => $val->asal_data,
                'nama_marketing' => $val->nama_marketing,
                'fasilitas_pinjaman' => [
                    'id'              => $val->id_fasilitas_pinjaman,
                    'plafon'          => $val->plafon,
                    'tenor'           => $val->tenor,
                    'jenis_pinjaman'  => $val->jenis_pinjaman,
                    'tujuan_pinjaman' => $val->tujuan_pinjaman
                ],
                'nama_debitur'   => $val->nama_cadeb,
                'rekomendasi_ao' => DB::connection('web')->table('recom_ao')->where('id_transaksi', $val->id)->first(),
                'rekomendasi_ca' => DB::connection('web')->table('recom_ca')->where('id_transaksi', $val->id)->first(),
                'rekomendasi_pinjaman' => DB::connection('web')->table('rekomendasi_pinjaman')->where('id_transaksi', $val->id)->first(),
                'agunan' => [
                    'tanah'     => DB::connection('web')->table('agunan_tanah')->where('id_transaksi', $val->id)->select('id', 'jenis_sertifikat as jenis')->get(),
                    'kendaraan' => DB::connection('web')->table('agunan_kendaraan')->where('id_transaksi', $val->id)->select('id', 'jenis')->get()
                ],
                'tgl_transaksi' => $val->tgl_ca,
                'approval'      => $combine
            ];
        }


        try {
            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'count'  => sizeof($data),
                'data'   => $data
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                "code"    => 501,
                "status"  => "error",
                "message" => $e
            ], 501);
        }
    }

    public function display($id_transaksi, Request $req)
    {
        $pic = $req->pic; // From PIC middleware

        $id_area   = $pic->id_area;
        $id_cabang = $pic->id_cabang;
        $scope     = $pic->jpic['cakupan'];

        $query_dir = DB::connection('web')->table('view_transaksi')
        ->where('status_caa', 'recommend')->where('id', $id_transaksi)->get()->toArray();

        $query = Helper::checkDir($scope, $query_dir, $id_area, $id_cabang);

        if (!$query) {
            return response()->json([
                'code'    => 404,
                'status'  => 'not found',
                'message' => 'Transaksi dengan id '.$id_transaksi.' belum selesai diproses oleh CAA'
            ], 404);
        }

        $transaksi = $query[0];

        $mutasi = MutasiBank::where('id_transaksi', $id_transaksi)->get()->toArray();
           
        if($mutasi != []){
            foreach($mutasi as $i => $mut){
                $doub[$i] = array_slice($mut, 0, 5);
            }

            // $arr = array();
            foreach($mutasi as $i => $mut){
                $slice[$i] = array_slice($mut, 5);
                foreach($slice as $key => $val){
                    foreach($val as $row => $col){
                        $arr[$i][$row] = explode(";",$col);
                    }
                }
            }

            // $dataMut = array();
            foreach ($arr as $key => $subarr)
            {
                foreach ($subarr as $subkey => $subvalue)
                {
                    foreach($subvalue as $childkey => $childvalue)
                    {   
                        $out[$key][$childkey][$subkey] = ($childvalue);
                    }

                    $dataMutasi[$key] = array_merge($doub[$key], array('table' => $out[$key]));
                }
            }
        }else{
            $dataMutasi = null;
        }

        $team_caa = JPIC::where('bagian', 'team_caa')->select('nama_jenis')->orderBy('urutan_jabatan', 'desc')->get()->toArray();

        $komite =  DB::connection('web')->table('tb_approval as appro')
                ->leftJoin('m_pic as pic', 'appro.id_pic', 'pic.id')
                ->leftJoin('mj_pic as jp', 'pic.id_mj_pic', 'jp.id')
                ->where('appro.id_transaksi', $transaksi->id)
                ->select("appro.id","appro.id_pic","appro.plafon","appro.tenor","appro.rincian", "appro.status", "appro.updated_at as tgl_approve", "pic.nama as nama_pic", "pic.plafon_caa as max_plafon", "jp.nama_jenis as jabatan")->orderBy('jp.urutan_jabatan', 'desc')->get()->toArray();

        $team = array();
        $array_values = array();
        for ($i = 0; $i < sizeof($team_caa); $i++) {
            $array_values[] = $team_caa[$i]['nama_jenis'];
            $maps[] = Helper::filter($komite, 'jabatan', $team_caa[$i]['nama_jenis'], false, false, false);

            if (!$maps[$i]) {
                $team[$i] = [];
            }else{
                foreach ($maps[$i] as $key => $value) {
                    $team[] = $value;
                }
            }
        }

        $combine = array_combine(str_replace(" ","_", $array_values), $team);

        $data = array(
            'id_trans_so' => $transaksi->id,
            'nomor_so'    => $transaksi->nomor_transaksi,
            'nama_so'     => $transaksi->nama_so,
            'nama_ao'     => $transaksi->nama_ao,
            'nama_ca'     => $transaksi->nama_ca,
            'nama_caa'    => $transaksi->nama_caa,
            'tracking'  => [
                'status' => [
                    'das'      => $transaksi->status_das,
                    'hm'       => $transaksi->status_hm,
                    'ao'       => $transaksi->status_ao,
                    'ca'       => $transaksi->status_ca,
                    'caa'      => $transaksi->status_caa,
                    'approval' => $transaksi->status_approval
                ],
                'pic'   => [
                    'so'    => $transaksi->nama_so,
                    'das'   => $transaksi->nama_das,
                    'hm'    => $transaksi->nama_hm,
                    'ao'    => $transaksi->nama_ao,
                    'ca'    => $transaksi->nama_ca,
                    'caa'   => $transaksi->nama_caa
                ],
                'tanggal' => [
                    'tgl_so'  => $transaksi->tgl_so,
                    'tgl_das' => $transaksi->tgl_das,
                    'tgl_hm'  => $transaksi->tgl_hm,
                    'tgl_ao'  => $transaksi->tgl_ao,
                    'tgl_ca'  => $transaksi->tgl_ca,
                    'tgl_caa' => $transaksi->tgl_caa
                ]
            ],
            'data_debitur'  => DB::connection('web')->table('calon_debitur')->where('id_transaksi', $id_transaksi)->first(),
            'data_pasangan' => DB::connection('web')->table('pasangan_calon_debitur')->where('id_transaksi', $id_transaksi)->first(),
            'data_penjamin' => DB::connection('web')->table('penjamin_calon_debitur')->where('id_transaksi', $id_transaksi)->get(),

            // Setelah input di AO
            'data_agunan' => [
                'agunan_tanah' => DB::connection('web')->table('agunan_tanah')->where('id_transaksi', $id_transaksi)->get(),
                'agunan_kendaraan' => DB::connection('web')->table('agunan_kendaraan')->where('id_transaksi', $id_transaksi)->get(),
            ],
            'pemeriksaan' => [
                'agunan_tanah' => DB::connection('web')->table('periksa_agunan_tanah')->where('id_transaksi', $id_transaksi)->get(),
                'agunan_kendaraan' => DB::connection('web')->table('periksa_agunan_kendaraan')->where('id_transaksi', $id_transaksi)->get(),
            ],
            'verifikasi'    => DB::connection('web')->table('tb_verifikasi')->where('id_transaksi', $id_transaksi)->first(),
            'validasi'      => DB::connection('web')->table('tb_validasi')->where('id_transaksi', $id_transaksi)->first(),
            'kapasitas_bulanan' => DB::connection('web')->table('kapasitas_bulanan')->where('id_transaksi', $id_transaksi)->first(),
            'pendapatan_usaha' => DB::connection('web')->table('pendapatan_usaha_cadebt')->where('id_transaksi', $id_transaksi)->first(),
            'rekomendasi_ao' => DB::connection('web')->table('recom_ao')->where('id_transaksi', $id_transaksi)->first(),

            'mutasi_bank'           => $dataMutasi,
            'data_keuangan'         => DB::connection('web')->table('log_tabungan_debt')->where('id_transaksi', $id_transaksi)->get(),
            'informasi_analisa_cc'  => array(
                'table'         => $iac = InfoACC::where('id_transaksi', $id_transaksi)->get()->toArray(),
                'total_plafon'  => array_sum(array_column($iac,'plafon')),
                'total_baki_debet' => array_sum(array_column($iac,'baki_debet')),
                'angsuran'         => array_sum(array_column($iac,'angsuran')),
                'collectabitas_tertinggi' => max(array_column($iac,'collectabilitas'))
            ),
            'ringkasan_analisa'     => DB::connection('web')->table('ringkasan_analisa_ca')->where('id_transaksi', $id_transaksi)->first(),
            'rekomendasi_pinjaman'  => DB::connection('web')->table('rekomendasi_pinjaman')->where('id_transaksi', $id_transaksi)->first(),
            'rekomendasi_ca'        => DB::connection('web')->table('recom_ca')->where('id_transaksi', $id_transaksi)->first(),
            'asuransi_jiwa'         => DB::connection('web')->table('asuransi_jiwa')->where('id_transaksi', $id_transaksi)->first(),
            'asuransi_jaminan'      => DB::connection('web')->table('asuransi_jaminan')->where('id_transaksi', $id_transaksi)->get(),
            'trans_caa'        => DB::connection('web')->table('trans_caa')->where('id_transaksi', $id_transaksi)->first(),
            'penyimpangan_caa' => Penyimpangan::where('id_transaksi', $id_transaksi)->first(),
            'approval'      => $combine,
            // 'status_ca'             => $transaksi->status_ca,
            'tgl_so'  => $transaksi->tgl_so,
            'tgl_das' => $transaksi->tgl_das,
            'tgl_hm'  => $transaksi->tgl_hm,
            'tgl_ao'  => $transaksi->tgl_ao,
            // 'tgl_transaksi'  => $transaksi->tgl_caa,
            'tgl_ca'  => $transaksi->tgl_ca,
            'tgl_caa' => $transaksi->tgl_caa,
        );

        try {
            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'data'   => $data
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                "code"    => 501,
                "status"  => "error",
                "message" => $e
            ], 501);
        }
    }

    public function filter($memo, $status, Request $req)
    {
        $pic = $req->pic; // From PIC middleware

        if ($memo != 'caa' && $memo != 'approval') {
            return response()->json([
                'code'    => 404,
                'status'  => 'not found',
                'message' => 'filter hanya aktif untuk caa dan approval'
            ], 404);
        }

        if ($status != 'recommend' && $status != 'waiting' && $status != 'not_recommend') {
            return response()->json([
                'code'    => 404,
                'status'  => 'not found',
                'message' => 'status hanya diantara berikut: recommend, not_recommend, waiting, accept, progress, return, reject'
            ], 404);
        }

        $id_area   = $pic->id_area;
        $id_cabang = $pic->id_cabang;
        $scope     = $pic->jpic['cakupan'];

        $query_dir = DB::connection('web')->table('view_transaksi')->get()->toArray();

        $query = Helper::checkDir($scope, $query_dir, $id_area, $id_cabang);

        $subQuery = Helper::filter($query, "status_{$memo}", $status, false, false, false);

        if (!$subQuery) {
            return response()->json([
                'code'    => 404,
                'status'  => 'not found',
                'message' => 'Data di tidak ditemukan'
            ], 404);
        }

        $tgl = "tgl_{$memo}";

        $data = array();
        foreach ($subQuery as $key => $val) {
            $data[] = [
                'id'              => $val->id,
                'nomor_transaksi' => $val->nomor_transaksi,
                'tracking'  => [
                    'status' => [
                        'das'      => $val->status_das,
                        'hm'       => $val->status_hm,
                        'ao'       => $val->status_ao,
                        'ca'       => $val->status_ca,
                        'caa'      => $val->status_caa,
                        'approval' => $val->status_approval
                    ],
                    'pic'   => [
                        'so'    => $val->nama_so,
                        'das'   => $val->nama_das,
                        'hm'    => $val->nama_hm,
                        'ao'    => $val->nama_ao,
                        'ca'    => $val->nama_ca,
                        'caa'   => $val->nama_caa
                    ],
                    'tanggal' => [
                        'tgl_so'  => $val->tgl_so,
                        'tgl_das' => $val->tgl_das,
                        'tgl_hm'  => $val->tgl_hm,
                        'tgl_ao'  => $val->tgl_ao,
                        'tgl_ca'  => $val->tgl_ca,
                        'tgl_caa' => $val->tgl_caa
                    ]
                ],
                'area'           => $val->area,
                'cabang'         => $val->cabang,
                'asal_data'      => $val->asal_data,
                'nama_marketing' => $val->nama_marketing,
                'nama_debitur'   => $val->nama_cadeb,
                'fasilitas_pinjaman'  => [
                    'id'              => $val->id_fasilitas_pinjaman,
                    'jenis_pinjaman'  => $val->jenis_pinjaman,
                    'tujuan_pinjaman' => $val->tujuan_pinjaman,
                    'plafon'          => $val->plafon,
                    'tenor'           => $val->tenor,
                ]
            ];
        }
        
        try {
            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'count'  => sizeof($data),
                'data'   => $data
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                "code"    => 501,
                "status"  => "error",
                "message" => $e
            ], 501);
        }
    }

    public function search($search, Request $req)
    {
        $pic = $req->pic; // From PIC middleware

        $id_area   = $pic->id_area;
        $id_cabang = $pic->id_cabang;
        $scope     = $pic->jpic['cakupan'];

        $query_dir = DB::connection('web')->select("CALL cari_transaksi('{$search}')");

        $query = Helper::checkDir($scope, $query_dir, $id_area, $id_cabang);

        $subQuery = Helper::filter($query, "status_ca", 'recommend', false, false, false);

        if (!$subQuery) {
            return response()->json([
                'code'    => 404,
                'status'  => 'not found',
                'message' => 'Pencarian tidak ditemukan'
            ], 404);
        }

        $data = array();
        foreach ($subQuery as $val) 
        {
            $data[] = [
                'id'                => $val->id,
                'nomor_transaksi'   => $val->nomor_transaksi,
                'tracking'  => [
                    'status' => [
                        'das'      => $val->status_das,
                        'hm'       => $val->status_hm,
                        'ao'       => $val->status_ao,
                        'ca'       => $val->status_ca,
                        'caa'      => $val->status_caa,
                        'approval' => $val->status_approval
                    ],
                    'pic'   => [
                        'so'    => $val->nama_so,
                        'das'   => $val->nama_das,
                        'hm'    => $val->nama_hm,
                        'ao'    => $val->nama_ao,
                        'ca'    => $val->nama_ca,
                        'caa'   => $val->nama_caa
                    ],
                    'tanggal' => [
                        'tgl_so'  => $val->tgl_so,
                        'tgl_das' => $val->tgl_das,
                        'tgl_hm'  => $val->tgl_hm,
                        'tgl_ao'  => $val->tgl_ao,
                        'tgl_ca'  => $val->tgl_ca,
                        'tgl_caa' => $val->tgl_caa
                    ]
                ],
                'area'           => $val->area,
                'cabang'         => $val->cabang,
                'asal_data'      => $val->asal_data,
                'nama_marketing' => $val->nama_marketing,
                'nama_debitur'   => $val->nama_cadeb,
                'fasilitas_pinjaman' => [
                    'id'              => $val->id_fasilitas_pinjaman,
                    'plafon'          => $val->plafon,
                    'tenor'           => $val->tenor,
                    'jenis_pinjaman'  => $val->jenis_pinjaman,
                    'tujuan_pinjaman' => $val->tujuan_pinjaman
                ]
            ];
        }

        try {
            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'count'  => sizeof($data),
                'data'   => $data
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                "code"    => 501,
                "status"  => "error",
                "message" => $e
            ], 501);
        }
    }
}