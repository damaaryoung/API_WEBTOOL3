<?php

namespace App\Http\Controllers\Transaksi;

use Laravel\Lumen\Routing\Controller as BaseController;
use App\Http\Controllers\Controller as Helper;

use App\Http\Requests\Transaksi\Agunan\A_TanahRequest;
use App\Http\Requests\Transaksi\Agunan\Pe_TanahRequest;
use App\Http\Requests\Transaksi\Agunan\A_KendaraanRequest;
use App\Http\Requests\Transaksi\Agunan\Pe_KendaraanRequest;
use App\Http\Requests\Transaksi\Verifikasi\VerifRequest;
use App\Http\Requests\Transaksi\Verifikasi\ValidRequest;
use App\Http\Requests\Transaksi\Kalkulasi\KapbulRequest;
use App\Http\Requests\Transaksi\Kalkulasi\PendapatanReq;
use App\Http\Requests\Transaksi\Rekomendasi\RekomAoReq;

use App\Models\Transaksi\Agunan\PemeriksaanAgunTan;
use App\Models\Transaksi\Agunan\PemeriksaanAgunKen;
use App\Models\Transaksi\Agunan\AgunanTanah;
use App\Models\Transaksi\Agunan\AgunanKendaraan;
use App\Models\Transaksi\Kalkulasi\KapBulanan;
use App\Models\Transaksi\Kalkulasi\PendapatanUsaha;
use App\Models\Transaksi\Verifikasi\VerifModel;
use App\Models\Transaksi\Verifikasi\ValidModel;
use App\Models\Transaksi\Rekomendasi\RekomendasiAO;
use App\Models\Transaksi\Nasabah\Penjamin;
use App\Models\Transaksi\Nasabah\Pasangan;
use App\Models\Transaksi\Nasabah\Debitur;
use App\Models\Transaksi\Transaksi;
use Illuminate\Support\Facades\File;

use Illuminate\Http\Request;
use Carbon\Carbon;
use DB;

class AO_Controller extends BaseController
{
    public function update($id_transaksi,  Request $req, A_TanahRequest $tan_req, Pe_TanahRequest $petan_req, A_KendaraanRequest $ken_req, Pe_KendaraanRequest $peken_req, VerifRequest $ver_req, ValidRequest $val_req, KapbulRequest $kapbul_req, PendapatanReq $penus_req, RekomAoReq $rekom_req)
    {
        $pic = $req->pic;

        $check_trans = Transaksi::where('id',$id_transaksi)->where('status_das', 1)->where('status_hm', 1)->first();

        if (empty($check_trans)) {
            return response()->json([
                'code'    => 404,
                'status'  => 'not found',
                'message' => 'Data dengan id transaksi '.$id_transaksi.' belum selesai di proses oleh admin'
            ], 404);
        }

        $lamp_dir = 'public/' . $check_trans->nomor_transaksi; // $check_so->debt['no_ktp'];

        // Form Persetujuan Ideb
        $check_form_persetujuan_ideb = $check_trans->form_persetujuan_ideb;
        
        if($file = $req->file('form_persetujuan_ideb')){
            $formP = $file->getClientOriginalExtension();

            if (
                $formP != 'png' && 
                $formP != 'jpg' &&
                $formP != 'jpeg'&&
                $formP != 'PNG' &&
                $formP != 'JPG' &&
                $formP != 'JPEG'&&
                $formP != 'pdf' &&
                $formP != 'PDF'
            )
            {
                return response()->json([
                    "code"    => 422,
                    "status"  => "not valid request",
                    "message" => "Lampiran Form Persetujuan Ideb harus berformat: png, jpg, jpeg, pdf"
                ], 422);
            }

            $path = $lamp_dir.'/ideb';
            $name = 'form_persetujuan_ideb';

            $check_file = $check_form_persetujuan_ideb;

            $form_persetujuan_ideb = Helper::uploadImg($check_file, $file, $path, $name);
        }else{
            $form_persetujuan_ideb = $check_form_persetujuan_ideb;
        }

        $dataTransaksi = array(
            'id_pic_ao'             => $pic->id,
            'status_ao'             => empty($req->input('status_ao')) ? 1 : $req->input('status_ao'),
            'catatan_ao'            => $req->input('catatan_ao'),
            'form_persetujuan_ideb' => $form_persetujuan_ideb,
            'tgl_ao'                => Carbon::now()->toDateTimeString()
        );

        $dataRecomAO = array(
            'produk'                => $req->input('produk'),
            'plafon_kredit'         => $req->input('plafon_kredit'),
            'jangka_waktu'          => $req->input('jangka_waktu'),
            'suku_bunga'            => $req->input('suku_bunga'),
            'pembayaran_bunga'      => $req->input('pembayaran_bunga'),
            'akad_kredit'           => $req->input('akad_kredit'),
            'ikatan_agunan'         => $req->input('ikatan_agunan'),
            'analisa_ao'            => $req->input('analisa_ao'),
            'biaya_provisi'         => $req->input('biaya_provisi'),
            'biaya_administrasi'    => $req->input('biaya_administrasi'),
            'biaya_credit_checking' => $req->input('biaya_credit_checking'),
            'biaya_tabungan'        => $req->input('biaya_tabungan'),
            'id_transaksi'          => $id_transaksi
        );

        $dataVerifikasi = array(
            'ver_ktp_debt'            => $req->input('ver_ktp_debt'),
            'ver_kk_debt'             => $req->input('ver_kk_debt'),
            'ver_akta_cerai_debt'     => $req->input('ver_akta_cerai_debt'),
            'ver_akta_kematian_debt'  => $req->input('ver_akta_kematian_debt'),
            'ver_rek_tabungan_debt'   => $req->input('ver_rek_tabungan_debt'),
            'ver_sertifikat_debt'     => $req->input('ver_sertifikat_debt'),
            'ver_sttp_pbb_debt'       => $req->input('ver_sttp_pbb_debt'),
            'ver_imb_debt'            => $req->input('ver_imb_debt'),
            'ver_ktp_pasangan'        => $req->input('ver_ktp_pasangan'),
            'ver_akta_nikah_pasangan' => $req->input('ver_akta_nikah_pasangan'),
            'ver_data_penjamin'       => $req->input('ver_data_penjamin'),
            'ver_sku_debt'            => $req->input('ver_sku_debt'),
            'ver_pembukuan_usaha_debt'=> $req->input('ver_pembukuan_usaha_debt'),
            'catatan'                 => $req->input('catatan_verifikasi'),
            'id_transaksi'            => $id_transaksi
        );

        $dataValidasi = array(
            'val_data_debt'       => $req->input('val_data_debt'),
            'val_lingkungan_debt' => $req->input('val_lingkungan_debt'),
            'val_domisili_debt'   => $req->input('val_domisili_debt'),
            'val_pekerjaan_debt'  => $req->input('val_pekerjaan_debt'),
            'val_data_pasangan'   => $req->input('val_data_pasangan'),
            'val_data_penjamin'   => $req->input('val_data_penjamin'),
            'val_agunan'          => $req->input('val_agunan'),
            'catatan'             => $req->input('catatan_validasi'),
            'id_transaksi'        => $id_transaksi
        );

        /** Lampiran Agunan Tanah */
        if($files = $req->file('agunan_bag_depan')){
            $path = $lamp_dir.'/agunan_tanah';
            $name = 'agunan_bag_depan';

            $check_file = '';

            $arrayPath = array();
            foreach($files as $file)
            {
                $arrayPath[] = Helper::uploadImg($check_file, $file, $path, $name);
            }

            $agunan_bag_depan = $arrayPath;
        }else{
            $agunan_bag_depan = null;
        }

        if($files = $req->file('agunan_bag_jalan')){
            $path = $lamp_dir.'/agunan_tanah';
            $name = 'agunan_bag_jalan';

            $check_file = '';

            $arrayPath = array();
            foreach($files as $file)
            {
                $arrayPath[] = Helper::uploadImg($check_file, $file, $path, $name);
            }

            $agunan_bag_jalan = $arrayPath;
        }else{
            $agunan_bag_jalan = null;
        }

        if($files = $req->file('agunan_bag_ruangtamu')){
            $path = $lamp_dir.'/agunan_tanah';
            $name = 'agunan_bag_ruangtamu';

            $check_file = '';

            $arrayPath = array();
            foreach($files as $file)
            {
                $arrayPath[] = Helper::uploadImg($check_file, $file, $path, $name);
            }

            $agunan_bag_ruangtamu = $arrayPath;
        }else{
            $agunan_bag_ruangtamu = null;
        }

        if($files = $req->file('agunan_bag_kamarmandi')){
            $path = $lamp_dir.'/agunan_tanah';
            $name = 'agunan_bag_kamarmandi';

            $check_file = '';

            $arrayPath = array();
            foreach($files as $file)
            {
                $arrayPath[] = Helper::uploadImg($check_file, $file, $path, $name);
            }

            $agunan_bag_kamarmandi = $arrayPath;
        }else{
            $agunan_bag_kamarmandi = null;
        }

        if($files = $req->file('agunan_bag_dapur')){
            $path = $lamp_dir.'/agunan_tanah';
            $name = 'agunan_bag_dapur';

            $check_file = '';

            $arrayPath = array();
            foreach($files as $file)
            {
                $arrayPath[] = Helper::uploadImg($check_file, $file, $path, $name);
            }

            $agunan_bag_dapur = $arrayPath;
        }else{
            $agunan_bag_dapur = null;
        }

        /** Lampiran Agunan Kendaraan */
        if ($files = $req->file('lamp_agunan_depan_ken')) {
            $path = $lamp_dir.'/agunan_kendaraan';
            $name = 'agunan_depan';

            $check_file = '';

            $arrayPath = array();
            foreach($files as $file)
            {
                $arrayPath[] = Helper::uploadImg($check_file, $file, $path, $name);
            }

            $lamp_agunan_depan_ken = $arrayPath;
        }else{
            $lamp_agunan_depan_ken = null;
        }


        if ($files = $req->file('lamp_agunan_kanan_ken')) {
            $path = $lamp_dir.'/agunan_kendaraan';
            $name = 'agunan_kanan';

            $check_file = '';

            $arrayPath = array();
            foreach($files as $file)
            {
                $arrayPath[] = Helper::uploadImg($check_file, $file, $path, $name);
            }

            $lamp_agunan_kanan_ken = $arrayPath;
        }else{
            $lamp_agunan_kanan_ken = null;
        }


        if ($files = $req->file('lamp_agunan_kiri_ken')) {
            $path = $lamp_dir.'/agunan_kendaraan';
            $name = 'agunan_kiri';

            $check_file = '';

            $arrayPath = array();
            foreach($files as $file)
            {
                $arrayPath[] = Helper::uploadImg($check_file, $file, $path, $name);
            }

            $lamp_agunan_kiri_ken = $arrayPath;
        }else{
            $lamp_agunan_kiri_ken = null;
        }


        if ($files = $req->file('lamp_agunan_belakang_ken')) {
            $path = $lamp_dir.'/agunan_kendaraan';
            $name = 'agunan_belakang';

            $check_file = '';

            $arrayPath = array();
            foreach($files as $file)
            {
                $arrayPath[] = Helper::uploadImg($check_file, $file, $path, $name);
            }

            $lamp_agunan_belakang_ken = $arrayPath;
        }else{
            $lamp_agunan_belakang_ken = null;
        }

        if ($files = $req->file('lamp_agunan_dalam_ken')) {
            $path = $lamp_dir.'/agunan_kendaraan';
            $name = 'agunan_dalam';

            $check_file = '';

            $arrayPath = array();
            foreach($files as $file)
            {
                $arrayPath[] = Helper::uploadImg($check_file, $file, $path, $name);
            }

            $lamp_agunan_dalam_ken = $arrayPath;
        }else{
            $lamp_agunan_dalam_ken = null;
        }

        // Tambahan Agunan Tanah
        if ($files = $req->file('lamp_imb')) {
            $path = $lamp_dir.'/agunan_tanah';
            $name = 'lamp_imb';

            $check_file = '';

            $arrayPath = array();
            foreach($files as $file)
            {
                $arrayPath[] = Helper::uploadImg($check_file, $file, $path, $name);
            }

            $lamp_imb_tan = $arrayPath;
        }else{
            $lamp_imb_tan = null;
        }

        if ($files = $req->file('lamp_pbb')) {
            $path = $lamp_dir.'/agunan_tanah';
            $name = 'lamp_pbb';

            $check_file = '';

            $arrayPath = array();
            foreach($files as $file)
            {
                $arrayPath[] = Helper::uploadImg($check_file, $file, $path, $name);
            }

            $lamp_pbb_tan = $arrayPath;
        }else{
            $lamp_pbb_tan = null;
        }

        if ($files = $req->file('lamp_sertifikat')) {
            $path = $lamp_dir.'/agunan_tanah';
            $name = 'lamp_sertifikat';

            $check_file = '';

            $arrayPath = array();
            foreach($files as $file)
            {
                $arrayPath[] = Helper::uploadImg($check_file, $file, $path, $name);
            }

            $lamp_sertifikat_tan = $arrayPath;
        }else{
            $lamp_sertifikat_tan = null;
        }

        // Agunan Tanah
        if (!empty($req->input('tipe_lokasi_agunan'))) {

            $daAguTa = array();
            for ($i = 0; $i < count($req->input('tipe_lokasi_agunan')); $i++){

                $daAguTa[] = [
                    'tipe_lokasi'             => $req->tipe_lokasi_agunan[$i],
                    'alamat'                  => $req->alamat_agunan[$i],
                    'id_provinsi'             => $req->id_prov_agunan[$i],
                    'id_kabupaten'            => $req->id_kab_agunan[$i],
                    'id_kecamatan'            => $req->id_kec_agunan[$i],
                    'id_kelurahan'            => $req->id_kel_agunan[$i],
                    'rt'                      => $req->rt_agunan[$i],
                    'rw'                      => $req->rw_agunan[$i],
                    'luas_tanah'              => $req->luas_tanah[$i],
                    'luas_bangunan'           => $req->luas_bangunan[$i],
                    'nama_pemilik_sertifikat' => $req->nama_pemilik_sertifikat[$i],
                    'jenis_sertifikat'        => $req->jenis_sertifikat[$i],
                    'no_sertifikat'           => $req->no_sertifikat[$i],
                    'tgl_ukur_sertifikat'     => $req->tgl_ukur_sertifikat[$i],
                    'tgl_berlaku_shgb'        => empty($req->tgl_berlaku_shgb[$i])
                        ? null : Carbon::parse($req->tgl_berlaku_shgb[$i])->format('Y-m-d'),
                    'no_imb'                  => $req->no_imb[$i],
                    'njop'                    => $req->njop[$i],
                    'nop'                     => $req->nop[$i],
                    'agunan_bag_depan'        => $agunan_bag_depan[$i],
                    'agunan_bag_jalan'        => $agunan_bag_jalan[$i],
                    'agunan_bag_ruangtamu'    => $agunan_bag_ruangtamu[$i],
                    'agunan_bag_kamarmandi'   => $agunan_bag_kamarmandi[$i],
                    'agunan_bag_dapur'        => $agunan_bag_dapur[$i],
                    'lamp_imb'                => $lamp_imb_tan,
                    'lamp_pbb'                => $lamp_pbb_tan,
                    'lamp_sertifikat'         => $lamp_sertifikat_tan,
                    'id_transaksi'            => $id_transaksi
                ];
            }
        }else{
            $daAguTa = null;
        }

        // Pemeriksaaan AGunan Tanah
        if (!empty($req->input('nama_penghuni')))
        {
            $pemAguTa = array();
            for ($i = 0; $i < count($req->input('nama_penghuni')); $i++){
                $pemAguTa[] = [
                    'nama_penghuni'                 => $req->nama_penghuni_agunan[$i],
                    'status_penghuni'               => $req->status_penghuni_agunan[$i],
                    'bentuk_bangunan'               => $req->bentuk_bangunan_agunan[$i],
                    'kondisi_bangunan'              => $req->kondisi_bangunan_agunan[$i],
                    'fasilitas'                     => $req->fasilitas_agunan[$i],
                    'listrik'                       => $req->listrik_agunan[$i],
                    'nilai_taksasi_agunan'          => $req->nilai_taksasi_agunan[$i],
                    'nilai_taksasi_bangunan'        => $req->nilai_taksasi_bangunan[$i],
                    'tgl_taksasi'                   => empty($req->tgl_taksasi_agunan[$i]) ? null : Carbon::parse($req->tgl_taksasi_agunan[$i])->format('Y-m-d'),
                    'nilai_likuidasi'               => $req->nilai_likuidasi_agunan[$i],
                    'nilai_agunan_independen'       => $req->nilai_agunan_independen[$i],
                    'perusahaan_penilai_independen' => $req->perusahaan_penilai_independen[$i],
                    'id_transaksi'                  => $id_transaksi
                ];
            }
        }else{
            $pemAguTa = null;
        }

        // Agunan Kendaraan
        if (!empty($req->input('no_bpkb_ken'))) {

            $daAguKe = array();
            for ($i = 0; $i < count($req->input('no_bpkb_ken')); $i++) {

                $daAguKe[] = [
                    'no_bpkb'              => $req->no_bpkb_ken[$i],
                    'nama_pemilik'         => $req->nama_pemilik_ken[$i],
                    'alamat_pemilik'       => $req->alamat_pemilik_ken[$i],
                    'merk'                 => $req->merk_ken[$i],
                    'jenis'                => $req->jenis_ken[$i],
                    'no_rangka'            => $req->no_rangka_ken[$i],
                    'no_mesin'             => $req->no_mesin_ken[$i],
                    'warna'                => $req->warna_ken[$i],
                    'tahun'                => $req->tahun_ken[$i],
                    'no_polisi'            => $req->no_polisi_ken[$i],
                    'no_stnk'              => $req->no_stnk_ken[$i],
                    'tgl_kadaluarsa_pajak' => empty($req->tgl_exp_pajak_ken[$i]) ? null : Carbon::parse($req->tgl_exp_pajak_ken[$i])->format('Y-m-d'),
                    'tgl_kadaluarsa_stnk'  => empty($req->tgl_exp_stnk_ken[$i]) ? null : Carbon::parse($req->tgl_exp_stnk_ken[$i])->format('Y-m-d'),
                    'no_faktur' => $req->no_faktur_ken[$i],
                    'lamp_agunan_depan'    => $lamp_agunan_depan_ken[$i],
                    'lamp_agunan_kanan'    => $lamp_agunan_kanan_ken[$i],
                    'lamp_agunan_kiri'     => $lamp_agunan_kiri_ken[$i],
                    'lamp_agunan_belakang' => $lamp_agunan_belakang_ken[$i],
                    'lamp_agunan_dalam'    => $lamp_agunan_dalam_ken[$i],
                    'id_transaksi'         => $id_transaksi
                ];
            }
        }else{
            $daAguKe = null;
        }

        // Pemeriksaan Agunan Kendaraan
        if (!empty($req->input('nama_pengguna'))) {
            $pemAguKe = array();
            for ($i = 0; $i < count($req->input('nama_pengguna')); $i++){
                $pemAguKe[] = [
                    'nama_pengguna'        => $req->nama_pengguna_ken[$i],
                    'status_pengguna'      => $req->status_pengguna_ken[$i],
                    'jml_roda_kendaraan'   => $req->jml_roda_ken[$i],
                    'kondisi_kendaraan'    => $req->kondisi_ken[$i],
                    'keberadaan_kendaraan' => $req->keberadaan_ken[$i],
                    'body'                 => $req->body_ken[$i],
                    'interior'             => $req->interior_ken[$i],
                    'km'                   => $req->km_ken[$i],
                    'modifikasi'           => $req->modifikasi_ken[$i],
                    'aksesoris'            => $req->aksesoris_ken[$i],
                    'id_transaksi'         => $id_transaksi
                ];
            }
        }else{
            $pemAguKe = null;
        }

        // Start Kapasitas Bulanan
        $inputKapBul = array(
            'pemasukan_cadebt'      => $req->input('pemasukan_debitur'),
            'pemasukan_pasangan'    => $req->input('pemasukan_pasangan'),
            'pemasukan_penjamin'    => $req->input('pemasukan_penjamin'),
            'biaya_rumah_tangga'    => $req->input('biaya_rumah_tangga'),
            'biaya_transport'       => $req->input('biaya_transport'),
            'biaya_pendidikan'      => $req->input('biaya_pendidikan'),
            'telp_listr_air'        => $req->input('telp_listr_air'), // jangan lupa hampir sama dengan pendapatan usaha
            'angsuran'              => $req->input('angsuran'),
            'biaya_lain'            => $req->input('biaya_lain')
        );

        $total_KapBul = array(
            'total_pemasukan'    => $ttl1 = array_sum(array_slice($inputKapBul, 0, 3)),
            'total_pengeluaran'  => $ttl2 = array_sum(array_slice($inputKapBul, 3)),
            'penghasilan_bersih' => $ttl1 - $ttl2,
            'id_transaksi'       => $id_transaksi,
            'ao_ca'              => 'ao'
        );

        $kapBul = array_merge($inputKapBul, $total_KapBul);
        // End Kapasitas Bulanan

        // Pendapatan Usaha
        if (!empty($req->input('pemasukan_tunai'))) {
            $inputKeUsaha = array(
                'pemasukan_tunai'      => $req->input('pemasukan_tunai'),
                'pemasukan_kredit'     => $req->input('pemasukan_kredit'),
                'biaya_sewa'           => $req->input('biaya_sewa'),
                'biaya_gaji_pegawai'   => $req->input('biaya_gaji_pegawai'),
                'biaya_belanja_brg'    => $req->input('biaya_belanja_brg'),
                'biaya_telp_listr_air' => $req->input('biaya_telp_listr_air'),
                'biaya_sampah_kemanan' => $req->input('biaya_sampah_kemanan'),
                'biaya_kirim_barang'   => $req->input('biaya_kirim_barang'),
                'biaya_hutang_dagang'  => $req->input('biaya_hutang_dagang'),
                'biaya_angsuran'       => $req->input('biaya_angsuran'),
                'biaya_lain_lain'      => $req->input('biaya_lain_lain')
            );

            $total_KeUsaha = array(
                'total_pemasukan'      => $ttl1 = array_sum(array_slice($inputKeUsaha, 0, 2)),
                'total_pengeluaran'    => $ttl2 = array_sum(array_slice($inputKeUsaha, 2)),
                'laba_usaha'           => $ttl1 - $ttl2,
                'id_transaksi'         => $id_transaksi,
                'ao_ca'                => 'ao'
            );

            $dataKeUsaha = array_merge($inputKeUsaha, $total_KeUsaha);
        }else{
            $dataKeUsaha = null;
        }

        // dd($dataTransaksi, $daAguTa, $pemAguTa, $daAguKe, $pemAguKe, $dataValidasi, $dataVerifikasi, $kapBul, $dataKeUsaha, $dataRecomAO);

        DB::connection('web')->beginTransaction();
        try{
            DB::connection('web')->table('tb_transaksi')->where('id', $id_transaksi)->update($dataTransaksi);

            if (!empty($daAguTa)) {
                for ($i = 0; $i < count($daAguTa); $i++) {
                    DB::connection('web')->table('agunan_tanah')->insert($daAguTa[$i]);
                }
            }

            if (!empty($pemAguTa)) {
                for ($i = 0; $i < count($pemAguTa); $i++) {
                    DB::connection('web')->table('periksa_agunan_tanah')->insert($pemAguTa[$i]);
                }
            }

            if (!empty($daAguKe)) {
                for ($i = 0; $i < count($daAguKe); $i++) {
                    $store_kendaraan = DB::connection('web')->table('agunan_kendaraan')->insert($daAguKe[$i]);
                }
            }

            if (!empty($pemAguKe)) {
                for ($i = 0; $i < count($pemAguKe); $i++) {
                    $store_pem_kendaraan = DB::connection('web')->table('periksa_agunan_kendaraan')->insert($pemAguKe[$i]);
                }
            }

            DB::connection('web')->table('tb_validasi')->insert($dataValidasi);

            DB::connection('web')->table('tb_verifikasi')->insert($dataVerifikasi);

            DB::connection('web')->table('kapasitas_bulanan')->insert($kapBul);

            if (!empty($dataKeUsaha)) {
                DB::connection('web')->table('pendapatan_usaha_cadebt')->insert($dataKeUsaha);
            }

            if (!empty($dataRecomAO)) {
                DB::connection('web')->table('recom_ao')->insert($dataRecomAO);
            }

            DB::connection('web')->commit();

            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'message'=> 'Data untuk AO berhasil dikirim',
                'data'   => [
                    'transaksi'                    => $dataTransaksi,
                    'agunan_tanah'                 => $daAguTa,
                    'pemeriksaan_agunan_tanah'     => $pemAguTa,
                    'agunan_kendaraan'             => $daAguKe,
                    'pemeriksaan_agunan_kendaraan' => $pemAguKe,
                    'validasi'                     => $dataValidasi,
                    'verifikasi'                   => $dataVerifikasi,
                    'kapasitas_bulanan'            => $kapBul,
                    'pendapatan_usaha'             => $dataKeUsaha,
                    'rekomendasi_ao'               => $dataRecomAO
                ]
            ], 200);
        } catch (\Exception $e) {
            $err = DB::connection('web')->rollback();
            return response()->json([
                'code'    => 501,
                'status'  => 'error',
                'message' => $err
            ], 501);
        }
    }

    public function search($search, Request $req)
    {
        $pic = $req->pic; // From PIC middleware

        $id_area   = $pic->id_area;
        $id_cabang = $pic->id_cabang;
        $scope     = $pic->jpic['cakupan'];

        // $query_dir = DB::connection('web')->select("CALL cari_transaksi('{$search}')");
        $query_dir = DB::connection('web')->select("CALL cari_transaksi('{$search}')");

        $query = Helper::checkDir($scope, $query_dir, $id_area, $id_cabang);

        $subQuery = Helper::filter($query, 'status_das', 'complete', false, false, false);

        if (empty($query)) {
            return response()->json([
                'code'    => 404,
                'status'  => 'not found',
                'message' => 'Pencarian tidak ditemukan'
            ], 404);
        }

        $data = array();
        foreach ($query as $key => $val) 
        {
            $data[] = array(
                "id"              => $val->id,
                "nomor_transaksi" => $val->nomor_transaksi, 
                "nama_so"         => $val->nama_so,
                "nama_ao"         => $val->nama_ao,
                "area"            => $val->area,
                "cabang"          => $val->cabang,
                "asal_data"       => $val->asal_data,
                "nama_marketing"  => $val->nama_marketing,
                "nama_cadeb"      => $val->nama_cadeb,
                'fasilitas_pinjaman'  => [
                    'id'              => $val->id_fasilitas_pinjaman,
                    'jenis_pinjaman'  => $val->jenis_pinjaman,
                    'tujuan_pinjaman' => $val->tujuan_pinjaman,
                    'plafon'          => $val->plafon,
                    'tenor'           => $val->tenor,
                ],
                'tracking'  => [
                    'status' => [
                        'das'      => $val->status_das,
                        'hm'       => $val->status_hm,
                        'ao'       => $val->status_ao,
                        'ca'       => $val->status_ca,
                        'caa'      => $val->status_caa,
                        'approval' => $val->status_approval
                    ],
                    'pic'   => [
                        'so'    => $val->nama_so,
                        'das'   => $val->nama_das,
                        'hm'    => $val->nama_hm,
                        'ao'    => $val->nama_ao,
                        'ca'    => $val->nama_ca,
                        'caa'   => $val->nama_caa
                    ],
                    'tanggal' => [
                        'tgl_so'  => $val->tgl_so,
                        'tgl_das' => $val->tgl_das,
                        'tgl_hm'  => $val->tgl_hm,
                        'tgl_ao'  => $val->tgl_ao,
                        'tgl_ca'  => $val->tgl_ca,
                        'tgl_caa' => $val->tgl_caa
                    ]
                ],
                "tgl_so" => $val->tgl_so,
                "tgl_ao" => $val->tgl_ao
            );
        }

        try {
            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'count'  => sizeof($data),
                'data'   => $data
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                "code"    => 501,
                "status"  => "error",
                "message" => $e
            ], 501);
        }
    }

    public function list(Request $req)
    {
        $pic = $req->pic; // From PIC middleware

        $id_area   = $pic->id_area;
        $id_cabang = $pic->id_cabang;
        $scope     = $pic->jpic['cakupan'];

        $query_dir = DB::connection('web')->table('view_transaksi')
        ->where('status_das', 'complete')
        ->where('status_das', 'complete')
        ->where('status_ao', 'recommend')
        ->get()->toArray();
                
        $query = Helper::checkDir($scope, $query_dir, $id_area, $id_cabang);

        if (!$query) {
            return response()->json([
                "code"    => 404,
                "status"  => "not found",
                "message" => "Data di belum ada yang di ubah"
            ], 404);
        }

        $data = array();
        foreach ($query as $val) {
            $data[] = [
                // 'id'              => $val->id,
                'id_trans_so'        => $val->id,
                // 'nomor_transaksi' => $val->nomor_transaksi,
                'nomor_so'           => $val->nomor_transaksi,
                'nama_so'            => $val->nama_so,
                'nama_ao'            => $val->nama_ao,
                "ao" => [
                    'status_ao'     => $val->status_ao,
                    'catatan_ao'    => $val->catatan_ao
                ],
                "ca" => [
                    'status_ca'     => $val->status_ca,
                    'catatan_ca'    => $val->catatan_ca
                ],
                "caa" => [
                    'status_caa'     => $val->status_caa,
                    'catatan_caa'    => $val->catatan_caa
                ],
                // 'tracking'  => [
                //     'status' => [
                //         'das'      => $val->status_das,
                //         'hm'       => $val->status_hm,
                //         'ao'       => $val->status_ao,
                //         'ca'       => $val->status_ca,
                //         'caa'      => $val->status_caa,
                //         'approval' => $val->status_approval
                //     ],
                //     'pic'   => [
                //         'so'    => $val->nama_so,
                //         'das'   => $val->nama_das,
                //         'hm'    => $val->nama_hm,
                //         'ao'    => $val->nama_ao,
                //         'ca'    => $val->nama_ca,
                //         'caa'   => $val->nama_caa
                //     ],
                //     'tanggal' => [
                //         'tgl_so'  => $val->tgl_so,
                //         'tgl_das' => $val->tgl_das,
                //         'tgl_hm'  => $val->tgl_hm,
                //         'tgl_ao'  => $val->tgl_ao,
                //         'tgl_ca'  => $val->tgl_ca,
                //         'tgl_caa' => $val->tgl_caa
                //     ]
                // ],
                'pic'            => $val->nama_ao,
                'area'           => $val->area,
                'cabang'         => $val->cabang,
                'asal_data'      => $val->asal_data,
                'nama_marketing' => $val->nama_marketing,
                'nama_debitur'   => $val->nama_cadeb,
                'plafon'         => $val->plafon,
                'tenor'          => $val->tenor,
                'tgl_so'         => $val->tgl_so,
                'tgl_ao'         => $val->tgl_ao
            ];
        }

        try {
            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'count'  => sizeof($data),
                'data'   => $data
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                "code"    => 501,
                "status"  => "error",
                "message" => $e
            ], 501);
        }
    }

    public function display($id_transaksi, Request $req)
    {
        $pic = $req->pic; // From PIC middleware

        $id_area   = $pic->id_area;
        $id_cabang = $pic->id_cabang;
        $scope     = $pic->jpic['cakupan'];

        $query_dir = DB::connection('web')->table('view_transaksi')
        ->where('id', $id_transaksi)
        ->where('status_das', 'complete')
        ->where('status_hm', 'complete')
        ->where('status_ao', 'recommend')
        ->get()->toArray();

        $query = Helper::checkDir($scope, $query_dir, $id_area, $id_cabang);

        if (!$query) {
            return response()->json([
                "code"    => 404,
                "status"  => "not found",
                "message" => "Data dengan id ".$id_transaksi." belum selesai di proses oleh AO"
            ], 404);
        }

        $val  = $query[0];

        $pen = Penjamin::where('id_transaksi', $id_transaksi)->get();

        if ($pen != '[]') {
            $penjamin = array();
            foreach ($pen as $key => $value) {
                $penjamin[$key] = [
                    "id"               => $value->id,
                    "nama_ktp"         => $value->nama_ktp,
                    "nama_ibu_kandung" => $value->nama_ibu_kandung,
                    "no_ktp"           => $value->no_ktp,
                    "no_npwp"          => $value->no_npwp,
                    "tempat_lahir"     => $value->tempat_lahir,
                    "tgl_lahir"        => $value->tgl_lahir,
                    "jenis_kelamin"    => $value->jenis_kelamin,
                    "alamat_ktp"       => $value->alamat_ktp,
                    "no_telp"          => $value->no_telp,
                    "hubungan_debitur" => $value->hubungan_debitur,
                    "lampiran" => [
                        "lamp_ktp"          => $value->lamp_ktp,
                        "lamp_ktp_pasangan" => $value->lamp_ktp_pasangan,
                        "lamp_kk"           => $value->lamp_kk,
                        "lamp_buku_nikah"   => $value->lamp_buku_nikah
                    ]
                ];
            }
        }else{
            $penjamin = null;
        }

        $data = array(
            'id'          => $val->id,
            'nomor_so'    => $val->nomor_transaksi,
            'nama_so'     => $val->nama_so,
            'nama_ao'     => $val->nama_ao,
            'status_ao'   => $val->status_ao,
            'status_ca'   => $val->status_ca,
            // 'tracking'  => [
            //     'status' => [
            //         'das'      => $val->status_das,
            //         'hm'       => $val->status_hm,
            //         'ao'       => $val->status_ao,
            //         'ca'       => $val->status_ca,
            //         'caa'      => $val->status_caa,
            //         'approval' => $val->status_approval
            //     ],
            //     'pic'   => [
            //         'so'    => $val->nama_so,
            //         'das'   => $val->nama_das,
            //         'hm'    => $val->nama_hm,
            //         'ao'    => $val->nama_ao,
            //         'ca'    => $val->nama_ca,
            //         'caa'   => $val->nama_caa
            //     ],
            //     'tanggal' => [
            //         'tgl_so'  => $val->tgl_so,
            //         'tgl_das' => $val->tgl_das,
            //         'tgl_hm'  => $val->tgl_hm,
            //         'tgl_ao'  => $val->tgl_ao,
            //         'tgl_ca'  => $val->tgl_ca,
            //         'tgl_caa' => $val->tgl_caa
            //     ]
            // ],
            'das'=> [
                'status'  => $val->status_das,
                'catatan' => $val->catatan_das
            ],
            'hm' => [
                'status'  => $val->status_hm,
                'catatan' => $val->catatan_hm
            ],
            'ao' => [
                'status'  => $val->status_ao,
                'catatan' => $val->catatan_ao
            ],
            'lampiran'  => [
                "ideb"      => explode(";", $val->lamp_ideb),
                "pefindo"   => explode(";", $val->lamp_pefindo)
            ],
            'pic'   => [
                'id'      => $val->id_pic_ao,
                'nama'    => $val->nama_ao,
            ],
            'area'   => [
                'id'      => $val->id_area,
                'nama'    => $val->area
            ],
            'cabang' => [
                'id'   => $val->id_cabang,
                'nama' => $val->cabang,
            ],
            'asaldata'  => [
                'id'   => $val->id_asal_data,
                'nama' => $val->asal_data
            ],
            'nama_marketing' => $val->nama_marketing,
            'fasilitas_pinjaman'  => [
                'id'              => $val->id_fasilitas_pinjaman,
                'jenis_pinjaman'  => $val->jenis_pinjaman,
                'tujuan_pinjaman' => $val->tujuan_pinjaman,
                'plafon'          => $val->plafon,
                'tenor'           => $val->tenor,
            ],
            'data_debitur'  => Debitur::where('id_transaksi', $id_transaksi)->first()->makeHidden('id_transaksi'),
            'data_pasangan' => Pasangan::where('id_transaksi', $id_transaksi)->first()->makeHidden('id_transaksi'),
            'data_penjamin' => $penjamin,

            // Setelah input di AO
            'data_agunan' => [
                'agunan_tanah' => AgunanTanah::where('id_transaksi', $id_transaksi)->get()->makeHidden('id_transaksi'),
                'agunan_kendaraan' => AgunanKendaraan::where('id_transaksi', $id_transaksi)->get()->makeHidden('id_transaksi'),
            ],
            'pemeriksaan' => [
                'agunan_tanah' => PemeriksaanAgunTan::where('id_transaksi', $id_transaksi)->get()->makeHidden('id_transaksi'),
                'agunan_kendaraan' => PemeriksaanAgunKen::where('id_transaksi', $id_transaksi)->get()->makeHidden('id_transaksi'),
            ],
            'verifikasi'    => VerifModel::where('id_transaksi', $id_transaksi)->first()->makeHidden('id_transaksi'),
            'validasi'      => ValidModel::where('id_transaksi', $id_transaksi)->first()->makeHidden('id_transaksi'),
            'kapasitas_bulanan' => KapBulanan::where('id_transaksi', $id_transaksi)->first()->makeHidden('id_transaksi'),
            'pendapatan_usaha' => PendapatanUsaha::where('id_transaksi', $id_transaksi)->first()->makeHidden('id_transaksi'),
            'rekomendasi_ao' => RekomendasiAO::where('id_transaksi', $id_transaksi)->first()->makeHidden('id_transaksi'),
            'tgl_transaksi' => $val->tgl_so,
            'tgl_das'       => $val->tgl_das,
            'tgl_hm'        => $val->tgl_hm,
            'tgl_ao'        => $val->tgl_ao
        );

        try {
            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'data'   => $data
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                "code"    => 501,
                "status"  => "error",
                "message" => $e
            ], 501);
        }
    }

    public function filter($memo, $status, Request $req)
    {
        $pic = $req->pic;

        $id_area   = $pic->id_area;
        $id_cabang = $pic->id_cabang;
        $scope     = $pic->jpic['cakupan'];

        if ($memo != 'ao' && $memo != 'ca') {
            return response()->json([
                'code'    => 404,
                'status'  => 'not found',
                'message' => 'filter hanya aktif untuk ao dan ca'
            ], 404);
        }

        if ($status != 'recommend' && $status != 'waiting' && $status != 'not_recommend') {
            return response()->json([
                'code'    => 404,
                'status'  => 'not found',
                'message' => 'status hanya diantara berikut: recommend, not_recommend, waiting'
            ], 404);
        }

        $query_dir = DB::connection('web')->table('view_transaksi')->get()->toArray();

        $query = Helper::checkDir($scope, $query_dir, $id_area, $id_cabang);

        $subQuery = Helper::filter($query, "status_{$memo}", $status, false, false, false);

        if (!$subQuery) {
            return response()->json([
                'code'    => 404,
                'status'  => 'not found',
                'message' => 'Data tidak ditemukan'
            ], 404);
        }

        $tgl = "tgl_{$memo}";

        $data = array();
        foreach ($subQuery as $val) {

            $data[] = [
                'id_trans_so' => $val->id,
                'nomor_so'    => $val->nomor_transaksi,
                'nama_so'     => $val->nama_so,
                'nama_ao'     => $val->nama_ao,
                "ao" => [
                    'status_ao'     => $val->status_ao,
                    'catatan_ao'    => $val->catatan_ao
                ],
                "ca" => [
                    'status_ca'     => $val->status_ca,
                    'catatan_ca'    => $val->catatan_ca
                ],
                'area'           => $val->area,
                'cabang'         => $val->cabang,
                'asal_data'      => $val->asal_data,
                'nama_marketing' => $val->nama_marketing,
                'nama_debitur'   => $val->nama_cadeb,
                'plafon'         => $val->plafon,
                'tenor'          => $val->tenor,
                'tgl_transaksi'  => $val->$tgl
            ];
        }
        
        try {
            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'count'  => sizeof($data),
                'data'   => $data
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                "code"    => 501,
                "status"  => "error",
                "message" => $e
            ], 501);
        }
    }
}