<?php

namespace App\Http\Controllers\Transaksi;

use Laravel\Lumen\Routing\Controller as BaseController;
use App\Http\Controllers\Controller as Helper;
// use App\Http\Requests\Transaksi\BlankRequest;
use App\Http\Requests\Transaksi\Kalkulasi\FaspinRequest;
use App\Http\Requests\Transaksi\Nasabah\DebiturRequest;
use App\Http\Requests\Transaksi\Nasabah\PasanganRequest;
use App\Http\Requests\Transaksi\Nasabah\PenjaminRequest;

use App\Models\Transaksi\Kalkulasi\FasilitasPinjaman;
use App\Models\Transaksi\Nasabah\Penjamin;
use App\Models\Transaksi\Nasabah\Pasangan;
use App\Models\Transaksi\Nasabah\Debitur;
use App\Models\Transaksi\Transaksi;
use App\Models\Master\JPIC;
use App\Models\Master\PIC;

use Illuminate\Http\Request;
use Carbon\Carbon;
use DB;

class SO_Controller extends BaseController
{
    public function store(Request $request, FaspinRequest $fas_req, DebiturRequest $deb_req, PasanganRequest $pas_req, PenjaminRequest $pen_req)
    {

        $countTSO = Transaksi::latest('id','nomor_so')->first();

        if ($countTSO == null) {
            $lastNumb = 1;
        }else{
            $no = $countTSO->nomor_transaksi;

            $arr = explode("-", $no, 5);

            $lastNumb = $arr[4] + 1;
        }

        //Data Transaksi SO
        $now   = Carbon::now();
        $year  = $now->year;
        $month = $now->month;
        
        $pic = $request->pic; // From PIC middleware

        //  ID-Cabang - AO / CA / SO - Bulan - Tahun - NO. Urut
        $nomor_so = $pic->id_cabang.'-'.$pic->jpic['nama_jenis'].'-'.$month.'-'.$year.'-'.$lastNumb; //  ID-Cabang - AO / CA / SO - Bulan - Tahun - NO. Urut

        $dataTransaksi = array(
            'nomor_transaksi' => $nomor_so,
            'id_pic_so'       => $pic->id,
            'id_area'         => $pic->id_area,
            'id_cabang'       => $pic->id_cabang,
            'id_asal_data'    => $request->input('id_asal_data'),
            'nama_marketing'  => $request->input('nama_marketing'),
            'flg_aktif'       => 1,
            'tgl_so'          => $now->toDateTimeString()
        );

        // Data Fasilitas Pinjaman
        $dataFasPin = array(
            'jenis_pinjaman'  => $fas_req->input('jenis_pinjaman'),
            'tujuan_pinjaman' => $fas_req->input('tujuan_pinjaman'),
            'plafon'          => $fas_req->input('plafon_pinjaman'),
            'tenor'           => $fas_req->input('tenor_pinjaman')
        );

        $dateExpires   = strtotime($now); // time to integer
        $day_in_second = 60 * 60 * 24 * 30;

        $ktp        = $deb_req->input('no_ktp');
        // $no_ktp_kk  = $req->input('no_ktp_kk');
        $no_ktp_pas = $pas_req->input('no_ktp_pas');
        // $no_ktp_pen = $req->input('no_ktp_pen');


        $check_ktp_dpm = DB::connection("web")->table("view_nasabah")->where("NO_ID", $ktp)->first();

        if ($check_ktp_dpm == null) {
            $NASABAH_ID = null;
        }else{
            $NASABAH_ID = $check_ktp_dpm->NASABAH_ID;
        }

        $check_ktp_web = Debitur::select('id', 'no_ktp', 'nama_lengkap', 'created_at')->where('no_ktp', $ktp)->first();

        if($check_ktp_web != null){

            $created_at = $check_ktp_web->created_at->timestamp;

            $compare_day_in_second = $dateExpires - $created_at;

            if ($compare_day_in_second <= $day_in_second) {
                return response()->json([
                    "code"    => 403,
                    "status"  => "Expired",
                    'message' => "Akun belum aktif kembali, belum ada 1 bulan yang lalu, tepatnya pada tanggal '".Carbon::parse($check_ktp_web->created_at)->format("d-m-Y")."' debitur dengan nama '{$check_ktp_web->nama_lengkap}' telah melakukan pengajuan"
                ], 403);
            }else{
                return response()->json([
                    "code"    => 200,
                    "status"  => "success",
                    "message" => "Akun telah ada di sistem, gunakan endpoint berikut apabila ingin menggunakan datanya",
                    "endpoint"=> "/api/debitur/".$check_ktp_web->id
                ], 200);
            }
        }else{
            $check_ktp_debt = Debitur::where('no_ktp', $ktp)->first();

            if (!empty($check_ktp_debt) && !empty($check_ktp_debt->no_ktp)) {
                return response()->json([
                    "code"    => 422,
                    "status"  => "not valid request",
                    "message" => 'no ktp telah ada yang menggunakan'
                ], 422);
            }

            if (!empty($check_ktp_debt) && !empty($check_ktp_debt->no_ktp_kk)) {
                return response()->json([
                    "code"    => 422,
                    "status"  => "not valid request",
                    "message" => 'no ktp di kk telah ada yang menggunakan'
                ], 422);
            }

            if (!empty($check_ktp_debt) && !empty($check_ktp_debt->no_npwp)) {
                return response()->json([
                    "code"    => 422,
                    "status"  => "not valid request",
                    "message" => 'no npwp telah ada yang menggunakan'
                ], 422);
            }

            if (!empty($check_ktp_debt) && !empty($check_ktp_debt->no_telp)) {
                return response()->json([
                    "code"    => 422,
                    "status"  => "not valid request",
                    "message" => 'no telp telah ada yang menggunakan'
                ], 422);
            }

            if (!empty($check_ktp_debt) && !empty($check_ktp_debt->no_hp)) {
                return response()->json([
                    "code"    => 422,
                    "status"  => "not valid request",
                    "message" => 'no hp telah ada yang menggunakan'
                ], 422);
            }

            $check_ktp_pas = Pasangan::where('no_ktp', $no_ktp_pas)->first();

            if (!empty($check_ktp_pas) && !empty($check_ktp_pas->no_ktp)) {
                return response()->json([
                    "code"    => 422,
                    "status"  => "not valid request",
                    "message" => 'no ktp pasangan telah ada yang menggunakan'
                ], 422);
            }

            if (!empty($check_ktp_pas) && !empty($check_ktp_pas->no_ktp_kk)) {
                return response()->json([
                    "code"    => 422,
                    "status"  => "not valid request",
                    "message" => 'no ktp di kk pasangan telah ada yang menggunakan'
                ], 422);
            }

            if (!empty($check_ktp_pas) && !empty($check_ktp_pas->no_npwp)) {
                return response()->json([
                    "code"    => 422,
                    "status"  => "not valid request",
                    "message" => 'no npwp pasangan telah ada yang menggunakan'
                ], 422);
            }

            if (!empty($check_ktp_pas) && !empty($check_ktp_pas->no_telp)) {
                return response()->json([
                    "code"    => 422,
                    "status"  => "not valid request",
                    "message" => 'no telp pasangan telah ada yang menggunakan'
                ], 422);
            }

            $lamp_dir  = 'public/' . $nomor_so;
            $path_debt = $lamp_dir . '/debitur';
            $path_pas  = $lamp_dir . '/pasangan';
            $path_penj = $lamp_dir . '/penjamin';

            if($file = $deb_req->file('lamp_ktp')){
                $name       = 'ktp';
                $check_file = 'null';

                $lamp_ktp = Helper::uploadImg($check_file, $file, $path_debt, $name);
            }else{
                $lamp_ktp = null;
            }

            if($file = $deb_req->file('lamp_kk')){
                $name       = 'kk';
                $check_file = 'null';
            
                $lamp_kk = Helper::uploadImg($check_file, $file, $path_debt, $name);
            }else{
                $lamp_kk = null;
            }

            if($file = $deb_req->file('lamp_sertifikat')){
                $name       = 'sertifikat';
                $check_file = 'null';
            
                $lamp_sertifikat = Helper::uploadImg($check_file, $file, $path_debt, $name);
            }else{
                $lamp_sertifikat = null;
            }

            if($file = $deb_req->file('lamp_pbb')){
                $name       = 'pbb';
                $check_file = 'null';
            
                $lamp_sttp_pbb = Helper::uploadImg($check_file, $file, $path_debt, $name);
            }else{
                $lamp_sttp_pbb = null;
            }

            if($file = $deb_req->file('lamp_imb')){
                $name       = 'imb';
                $check_file = 'null';
            
                $lamp_imb = Helper::uploadImg($check_file, $file, $path_debt, $name);
            }else{
                $lamp_imb = null;
            }

            if($file = $deb_req->file('foto_agunan_rumah')){
                $name = 'foto_agunan_rumah';
                $check_file = 'null';
            
                $foto_agunan_rumah = Helper::uploadImg($check_file, $file, $path_debt, $name);
            }else{
                $foto_agunan_rumah = null;
            }

            if ($file = $deb_req->file('lamp_surat_cerai')) {
                $name       = 'lamp_surat_cerai';
                $check_file = 'null';
            
                $lamp_surat_cerai = Helper::uploadImg($check_file, $file, $path_debt, $name);
            }else{
                $lamp_surat_cerai = null;
            }

            // Data Calon Debitur
            $dataDebitur = array(
                'nama_lengkap'          => $deb_req->input('nama_lengkap'),
                'gelar_keagamaan'       => $deb_req->input('gelar_keagamaan'),
                'gelar_pendidikan'      => $deb_req->input('gelar_pendidikan'),
                'jenis_kelamin'         => $deb_req->input('jenis_kelamin'),
                'status_nikah'          => $deb_req->input('status_nikah'),
                'ibu_kandung'           => $deb_req->input('ibu_kandung'),
                'no_ktp'                => $ktp,
                'no_ktp_kk'             => $deb_req->input('no_ktp_kk'),
                'no_kk'                 => $deb_req->input('no_kk'),
                'no_npwp'               => $deb_req->input('no_npwp'),
                'tempat_lahir'          => $deb_req->input('tempat_lahir'),
                'tgl_lahir'             => empty($deb_req->input('tgl_lahir')) ? null : Carbon::parse($deb_req->input('tgl_lahir'))->format('Y-m-d'),
                'agama'                 => $deb_req->input('agama'),
                'alamat_ktp'            => $alamat_ktp  = $deb_req->input('alamat_ktp'),
                'rt_ktp'                => $rt_ktp      = $deb_req->input('rt_ktp'),
                'rw_ktp'                => $rw_ktp      = $deb_req->input('rw_ktp'),
                'id_prov_ktp'           => $id_prov_ktp = $deb_req->input('id_provinsi_ktp'),
                'id_kab_ktp'            => $id_kab_ktp  = $deb_req->input('id_kabupaten_ktp'),
                'id_kec_ktp'            => $id_kec_ktp  = $deb_req->input('id_kecamatan_ktp'),
                'id_kel_ktp'            => $id_kel_ktp  = $deb_req->input('id_kelurahan_ktp'),

                'alamat_domisili'       => empty($deb_req->input('alamat_domisili')) ? $alamat_ktp : $deb_req->input('alamat_domisili'),
                'rt_domisili'           => empty($deb_req->input('rt_domisili'))     ? $rt_ktp : $deb_req->input('rt_domisili'),
                'rw_domisili'           => empty($deb_req->input('rw_domisili'))     ? $rw_ktp : $deb_req->input('rw_domisili'),
                'id_prov_domisili'      => empty($deb_req->input('id_provinsi_domisili')) ? $id_prov_ktp : $deb_req->input('id_provinsi_domisili'),
                'id_kab_domisili'       => empty($deb_req->input('id_kabupaten_domisili')) ? $id_kab_ktp : $deb_req->input('id_kabupaten_domisili'),
                'id_kec_domisili'       => empty($deb_req->input('id_kecamatan_domisili')) ? $id_kec_ktp : $deb_req->input('id_kecamatan_domisili'),
                'id_kel_domisili'       => empty($deb_req->input('id_kelurahan_domisili')) ? $id_kel_ktp : $deb_req->input('id_kelurahan_domisili'),

                'pendidikan_terakhir'   => $deb_req->input('pendidikan_terakhir'),
                'jumlah_tanggungan'     => $deb_req->input('jumlah_tanggungan'),
                'no_telp'               => $deb_req->input('no_telp'),
                'no_hp'                 => $deb_req->input('no_hp'),
                'alamat_surat'          => $deb_req->input('alamat_surat'),
                'lamp_ktp'              => $lamp_ktp,
                'lamp_kk'               => $lamp_kk,
                'lamp_sertifikat'       => $lamp_sertifikat,
                'lamp_sttp_pbb'         => $lamp_sttp_pbb,
                'lamp_imb'              => $lamp_imb,
                'lamp_surat_cerai'      => $lamp_surat_cerai,
                'foto_agunan_rumah'     => $foto_agunan_rumah,
                'NASABAH_ID'            => $NASABAH_ID
            );

            // Lampiran Pasangan
            if($file = $pas_req->file('lamp_ktp_pas')){
                $name       = 'ktp';
                $check_file = 'null';
            
                $lamp_ktp_pas = Helper::uploadImg($check_file, $file, $path_pas, $name);
            }else{
                $lamp_ktp_pas = null;
            }

            if($file = $pas_req->file('lamp_buku_nikah_pas')){
                $name       = 'buku_nikah';
                $check_file = 'null';
            
                $lamp_buku_nikah_pas = Helper::uploadImg($check_file, $file, $path_pas, $name);
            }else{
                $lamp_buku_nikah_pas = null;
            }

            if (!empty($pas_req->input('nama_lengkap_pas'))) {

                $alamat_ktp_pas = empty($pas_req->input('alamat_ktp_pas')) ? $dataDebitur['alamat_ktp'] : $pas_req->input('alamat_ktp_pas');

            }else{
                $alamat_ktp_pas = null;
            }

            // Data Pasangan Calon Debitur
            $dataPasangan = array(
                'nama_lengkap'     => $pas_req->input('nama_lengkap_pas'),
                'nama_ibu_kandung' => $pas_req->input('nama_ibu_kandung_pas'),
                'jenis_kelamin'    => $pas_req->input('jenis_kelamin_pas'),
                'no_ktp'           => $pas_req->input('no_ktp_pas'),
                'no_ktp_kk'        => $pas_req->input('no_ktp_kk_pas'),
                'no_npwp'          => $pas_req->input('no_npwp_pas'),
                'tempat_lahir'     => $pas_req->input('tempat_lahir_pas'),
                'tgl_lahir'        => empty($pas_req->input('tgl_lahir_pas')) ? null : Carbon::parse($pas_req->input('tgl_lahir_pas'))->format('Y-m-d'),
                'alamat_ktp'       => $alamat_ktp_pas,
                'no_telp'          => $pas_req->input('no_telp_pas'),
                'lamp_ktp'         => $lamp_ktp_pas,
                'lamp_buku_nikah'  => $lamp_buku_nikah_pas
            );

            // Lampiran Penjamin
            if($files = $pen_req->file('lamp_ktp_pen')){
                $name       = 'ktp_penjamin';
                $check_file = 'null';

                $arrayPath = array();
                foreach($files as $file)
                {
                    $arrayPath[] = Helper::uploadImg($check_file, $file, $path_penj, $name);
                }

                $lamp_ktp_pen = $arrayPath;
            }else{
                $lamp_ktp_pen = null;
            }

            if($files = $pen_req->file('lamp_ktp_pasangan_pen')){
                $name       = 'ktp_pasangan_penjamin';
                $check_file = 'null';

                $arrayPath = array();
                foreach($files as $file)
                {
                    $arrayPath[] = Helper::uploadImg($check_file, $file, $path_penj, $name);
                }

                $lamp_ktp_pasangan_pen = $arrayPath;
            }else{
                $lamp_ktp_pasangan_pen = null;
            }

            if($files = $pen_req->file('lamp_kk_pen')){
                $name       = 'kk_penjamin';
                $check_file = 'null';

                $arrayPath = array();
                foreach($files as $file)
                {
                    $arrayPath[] = Helper::uploadImg($check_file, $file, $path_penj, $name);
                }

                $lamp_kk_pen = $arrayPath;
            }else{
                $lamp_kk_pen = null;
            }

            if($files = $pen_req->file('lamp_buku_nikah_pen')){
                $name       = 'buku_nikah_penjamin';
                $check_file = 'null';

                $arrayPath = array();
                foreach($files as $file)
                {
                    $arrayPath[] = Helper::uploadImg($check_file, $file, $path_penj, $name);
                }

                $lamp_buku_nikah_pen = $arrayPath;
            }else{
                $lamp_buku_nikah_pen = null;
            }

            if (!empty($pen_req->input('nama_ktp_pen'))) 
            {

                $dataPenjamin = array();
                for ($i = 0; $i < count($pen_req->input('nama_ktp_pen')); $i++) 
                {
                    $dataPenjamin[] = [
                        'nama_ktp'         => empty($pen_req->nama_ktp_pen[$i])         ? null : $pen_req->nama_ktp_pen[$i],
                        'nama_ibu_kandung' => empty($pen_req->nama_ibu_kandung_pen[$i]) ? null : $pen_req->nama_ibu_kandung_pen[$i],
                        'no_ktp'           => empty($pen_req->no_ktp_pen[$i])           ? null : $pen_req->no_ktp_pen[$i],
                        'no_npwp'          => empty($pen_req->no_npwp_pen[$i])          ? null : $pen_req->no_npwp_pen[$i],
                        'tempat_lahir'     => empty($pen_req->tempat_lahir_pen[$i])     ? null : $pen_req->tempat_lahir_pen[$i],
                        'tgl_lahir'        => empty($pen_req->tgl_lahir_pen[$i])        ? null : Carbon::parse($pen_req->tgl_lahir_pen[$i])->format('Y-m-d'),
                        'jenis_kelamin'    => empty($pen_req->jenis_kelamin_pen[$i])    ? null : $pen_req->jenis_kelamin_pen[$i],
                        'alamat_ktp'       => empty($pen_req->alamat_ktp_pen[$i])       ? null : $pen_req->alamat_ktp_pen[$i],
                        'no_telp'          => empty($pen_req->no_telp_pen[$i])          ? null : $pen_req->no_telp_pen[$i],
                        'hubungan_debitur' => empty($pen_req->hubungan_debitur_pen[$i]) ? null : $pen_req->hubungan_debitur_pen[$i],
                        'lamp_ktp'         => empty($lamp_ktp_pen[$i])                  ? null : $lamp_ktp_pen[$i],
                        'lamp_ktp_pasangan'=> empty($lamp_ktp_pasangan_pen[$i])         ? null : $lamp_ktp_pasangan_pen[$i],
                        'lamp_kk'          => empty($lamp_kk_pen[$i])                   ? null : $lamp_kk_pen[$i],
                        'lamp_buku_nikah'  => empty($lamp_buku_nikah_pen[$i])           ? null : $lamp_buku_nikah_pen[$i]
                    ];
                }
            }else{
                $dataPenjamin = null;
            }
        }

        // dd($dataTransaksi, $dataFasPin, $dataDebitur, $dataPasangan, $dataPenjamin);

        DB::connection('web')->beginTransaction();
        try {
            $store_transaksi = Transaksi::create($dataTransaksi);

            $id_transaksi = array('id_transaksi' => $store_transaksi->id);

            $faspin        = array_merge($dataFasPin, $id_transaksi);
            $store_faspin  = FasilitasPinjaman::create($faspin);

            $deb       = array_merge($dataDebitur, $id_transaksi);
            $store_deb = Debitur::create($deb);

            if (!empty($dataPasangan)) {
                $pas       = array_merge($dataPasangan, $id_transaksi);
                $store_pas = Pasangan::create($pas);
            }else{
                $store_pas = null;
            }

            if (!empty($dataPenjamin)) {

                $store_pen = array();
                for ($i = 0; $i < count($dataPenjamin); $i++) {

                    $store_pen[] = Penjamin::create(array_merge($dataPenjamin[$i], $id_transaksi));

                }
            }else{
                $store_pen = null;
            }

            DB::connection('web')->commit();

            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'message'=> 'Data berhasil dibuat',
                'data'   => [
                    'transaksi'          => $store_transaksi,
                    'fasilitas_pinjaman' => $store_faspin,
                    'debitur'            => $store_deb,
                    'pasangan'           => $store_pas,
                    'penjamin'           => $store_pen,
                ]
            ], 200);
        }catch (\Exception $e) {
            $err = DB::connection('web')->rollback();
            return response()->json([
                'code'    => 501,
                'status'  => 'error',
                'message' => $err
            ], 501);
        }
    }

    public function update($id_transaksi, Request $request, FaspinRequest $fas_req, DebiturRequest $deb_req, PasanganRequest $pas_req, PenjaminRequest $pen_req)
    {
        $check_trans = Transaksi::where('id', $id_transaksi)->first();

        if ($check_trans == null) {
            return response()->json([
                "code"    => 404,
                "status"  => "not found",
                "message" => "Data dengan id ".$id_transaksi." tidak ada di SO atau belum di rekomendasikan oleh Admin"
            ], 404);
        }

        $dataTransaksi = array(
            'id_asal_data'    => empty($request->input('id_asal_data'))   ? $check_trans->id_asal_data   : $request->input('id_asal_data'),
            'nama_marketing'  => empty($request->input('nama_marketing')) ? $check_trans->nama_marketing : $request->input('nama_marketing')
        );

        $c_faspin = FasilitasPinjaman::where('id_transaksi', $id_transaksi)->first();

        if ($c_faspin == null) {
            return response()->json([
                "code"    => 404,
                "status"  => "not found",
                "message" => "Data Fasilitas Pinjaman dengan id transaksi ".$id_transaksi." tida ditemukan"
            ], 404);
        }

        // Data Fasilitas Pinjaman
        $dataFasPin = array(
            'jenis_pinjaman'  => empty($fas_req->input('jenis_pinjaman'))  ? $c_faspin->jenis_pinjaman : $fas_req->input('jenis_pinjaman'),
            'tujuan_pinjaman' => empty($fas_req->input('tujuan_pinjaman')) ? $c_faspin->tujuan_pinjaman : $fas_req->input('tujuan_pinjaman'),
            'plafon'          => empty($fas_req->input('plafon_pinjaman')) ? $c_faspin->plafon : $fas_req->input('plafon_pinjaman'),
            'tenor'           => empty($fas_req->input('tenor_pinjaman'))  ? $c_faspin->tenor : $fas_req->input('tenor_pinjaman')
        );

        $c_deb = Debitur::where('id_transaksi', $id_transaksi)->first();

        if ($c_deb == null) {
            return response()->json([
                "code"    => 404,
                "status"  => "not found",
                "message" => "Data Calon Debitur dengan id transaksi ".$id_transaksi." tida ditemukan"
            ], 404);
        }

        $lamp_dir  = 'public/' . $check_trans->nomor_transaksi;
        $path_debt = $lamp_dir . '/debitur';
        $path_pas  = $lamp_dir . '/pasangan';
        $path_penj = $lamp_dir . '/penjamin';

        if($file = $deb_req->file('lamp_ktp')){
            $name       = 'ktp';
            $check_file = $c_deb->lamp_ktp;

            $lamp_ktp = Helper::uploadImg($check_file, $file, $path_debt, $name);
        }else{
            $lamp_ktp = $c_deb->lamp_ktp;
        }

        if($file = $deb_req->file('lamp_kk')){
            $name       = 'kk';
            $check_file = $c_deb->lamp_kk;
            
            $lamp_kk = Helper::uploadImg($check_file, $file, $path_debt, $name);
        }else{
            $lamp_kk = $c_deb->lamp_kk;
        }

        if($file = $deb_req->file('lamp_sertifikat')){
            $name       = 'sertifikat';
            $check_file = $c_deb->lamp_sertifikat;
            
            $lamp_sertifikat = Helper::uploadImg($check_file, $file, $path_debt, $name);
        }else{
            $lamp_sertifikat = $c_deb->lamp_sertifikat;
        }

        if($file = $deb_req->file('lamp_pbb')){
            $name       = 'pbb';
            $check_file = $c_deb->lamp_sttp_pbb;
            
            $lamp_sttp_pbb = Helper::uploadImg($check_file, $file, $path_debt, $name);
        }else{
            $lamp_sttp_pbb = $c_deb->lamp_sttp_pbb;
        }

        if($file = $deb_req->file('lamp_imb')){
            $name       = 'imb';
            $check_file = $c_deb->lamp_imb;
            
            $lamp_imb = Helper::uploadImg($check_file, $file, $path_debt, $name);
        }else{
            $lamp_imb = $c_deb->lamp_imb;
        }

        if($file = $deb_req->file('foto_agunan_rumah')){
            $name = 'foto_agunan_rumah';
            $check_file = $c_deb->foto_agunan_rumah;
            
            $foto_agunan_rumah = Helper::uploadImg($check_file, $file, $path_debt, $name);
        }else{
            $foto_agunan_rumah = $c_deb->foto_agunan_rumah;
        }

        if ($file = $deb_req->file('lamp_surat_cerai')) {
            $name       = 'lamp_surat_cerai';
            $check_file = $c_deb->lamp_surat_cerai;
            
            $lamp_surat_cerai = Helper::uploadImg($check_file, $file, $path_debt, $name);
        }else{
            $lamp_surat_cerai = $c_deb->lamp_surat_cerai;
        }

        // Data Calon Debitur
        $dataDebitur = array(
            'nama_lengkap'          => empty($deb_req->input('nama_lengkap')) ? $c_deb->nama_lengkap : $deb_req->input('nama_lengkap'),
            'gelar_keagamaan'       => empty($deb_req->input('gelar_keagamaan')) ? $c_deb->gelar_keagamaan : $deb_req->input('gelar_keagamaan'),
            'gelar_pendidikan'      => empty($deb_req->input('gelar_pendidikan')) ? $c_deb->gelar_pendidikan : $deb_req->input('gelar_pendidikan'),
            'jenis_kelamin'         => empty($deb_req->input('jenis_kelamin')) ? $c_deb->jenis_kelamin : $deb_req->input('jenis_kelamin'),
            'status_nikah'          => empty($deb_req->input('status_nikah')) ? $c_deb->status_nikah : $deb_req->input('status_nikah'),
            'ibu_kandung'           => empty($deb_req->input('ibu_kandung')) ? $c_deb->ibu_kandung : $deb_req->input('ibu_kandung'),
            'no_ktp'                => empty($deb_req->input('no_ktp')) ? $c_deb->no_ktp : $deb_req->input('no_ktp'),
            'no_ktp_kk'             => empty($deb_req->input('no_ktp_kk')) ? $c_deb->no_ktp_kk : $deb_req->input('no_ktp_kk'),
            'no_kk'                 => empty($deb_req->input('no_kk')) ? $c_deb->no_kk : $deb_req->input('no_kk'),
            'no_npwp'               => empty($deb_req->input('no_npwp')) ? $c_deb->no_npwp : $deb_req->input('no_npwp'),
            'tempat_lahir'          => empty($deb_req->input('tempat_lahir')) ? $c_deb->tempat_lahir : $deb_req->input('tempat_lahir'),
            'tgl_lahir'             => empty($deb_req->input('tgl_lahir')) ? $c_deb->tgl_lahir : Carbon::parse($deb_req->input('tgl_lahir'))->format('Y-m-d'),
            'agama'                 => empty($deb_req->input('agama')) ? $c_deb->agama : $deb_req->input('agama'),
            'alamat_ktp'            => $alamat_ktp  = empty($deb_req->input('alamat_ktp')) ? $c_deb->alamat_ktp : $deb_req->input('alamat_ktp'),
            'rt_ktp'                => empty($deb_req->input('rt_ktp')) ? $c_deb->rt_ktp : $deb_req->input('rt_ktp'),
            'rw_ktp'                => empty($deb_req->input('rw_ktp')) ? $c_deb->rw_ktp : $deb_req->input('rw_ktp'),
            'id_prov_ktp'           => empty($deb_req->input('id_provinsi_ktp')) ? $c_deb->id_prov_ktp : $deb_req->input('id_provinsi_ktp'),
            'id_kab_ktp'            => empty($deb_req->input('id_kabupaten_ktp')) ? $c_deb->id_kab_ktp : $deb_req->input('id_kabupaten_ktp'),
            'id_kec_ktp'            => empty($deb_req->input('id_kecamatan_ktp')) ? $c_deb->id_kec_ktp : $deb_req->input('id_kecamatan_ktp'),
            'id_kel_ktp'            => empty($deb_req->input('id_kelurahan_ktp')) ? $c_deb->id_kel_ktp : $deb_req->input('id_kelurahan_ktp'),

            'alamat_domisili'       => empty($deb_req->input('alamat_domisili')) ? $c_deb->alamat_domisili : $deb_req->input('alamat_domisili'),
            'rt_domisili'           => empty($deb_req->input('rt_domisili')) ? $c_deb->rt_domisili : $deb_req->input('rt_domisili'),
            'rw_domisili'           => empty($deb_req->input('rw_domisili')) ? $c_deb->rw_domisili : $deb_req->input('rw_domisili'),
            'id_prov_domisili'      => empty($deb_req->input('id_provinsi_domisili')) ? $c_deb->id_prov_domisili : $deb_req->input('id_provinsi_domisili'),
            'id_kab_domisili'       => empty($deb_req->input('id_kabupaten_domisili')) ? $c_deb->id_kab_domisili : $deb_req->input('id_kabupaten_domisili'),
            'id_kec_domisili'       => empty($deb_req->input('id_kecamatan_domisili')) ? $c_deb->id_kec_domisili : $deb_req->input('id_kecamatan_domisili'),
            'id_kel_domisili'       => empty($deb_req->input('id_kelurahan_domisili')) ? $c_deb->id_kel_domisili : $deb_req->input('id_kelurahan_domisili'),

            'pendidikan_terakhir'   => empty($deb_req->input('pendidikan_terakhir')) ? $c_deb->pendidikan_terakhir : $deb_req->input('pendidikan_terakhir') ,
            'jumlah_tanggungan'     => empty($deb_req->input('jumlah_tanggungan')) ? $c_deb->jumlah_tanggungan : $deb_req->input('jumlah_tanggungan') ,
            'no_telp'               => empty($deb_req->input('no_telp')) ? $c_deb->no_telp : $deb_req->input('no_telp') ,
            'no_hp'                 => empty($deb_req->input('no_hp')) ? $c_deb->no_hp : $deb_req->input('no_hp') ,
            'alamat_surat'          => empty($deb_req->input('alamat_surat')) ? $c_deb->alamat_surat : $deb_req->input('alamat_surat') ,
            'lamp_ktp'              => $lamp_ktp,
            'lamp_kk'               => $lamp_kk,
            'lamp_sertifikat'       => $lamp_sertifikat,
            'lamp_sttp_pbb'         => $lamp_sttp_pbb,
            'lamp_imb'              => $lamp_imb,
            'lamp_surat_cerai'      => $lamp_surat_cerai,
            'foto_agunan_rumah'     => $foto_agunan_rumah
        );
    
        $c_pas = Pasangan::where('id_transaksi', $id_transaksi)->first();

        if ($c_pas == null) {
            return response()->json([
                "code"    => 404,
                "status"  => "not found",
                "message" => "Data Pasangan dengan id transaksi ".$id_transaksi." tida ditemukan"
            ], 404);
        }
        
        // Lampiran Pasangan
        if($file = $pas_req->file('lamp_ktp_pas')){
            $name       = 'ktp';
            $check_file = $c_pas->lamp_ktp;
            
            $lamp_ktp_pas = Helper::uploadImg($check_file, $file, $path_pas, $name);
        }else{
            $lamp_ktp_pas = $c_pas->lamp_ktp;
        }

        if($file = $pas_req->file('lamp_buku_nikah_pas')){
            $name       = 'buku_nikah';
            $check_file = $c_pas->lamp_buku_nikah;
            
            $lamp_buku_nikah_pas = Helper::uploadImg($check_file, $file, $path_pas, $name);
        }else{
            $lamp_buku_nikah_pas = $c_pas->lamp_buku_nikah;
        }

        // Data Pasangan Calon Debitur
        $dataPasangan = array(
            'nama_lengkap'     => empty($pas_req->input('nama_lengkap_pas')) ? $c_pas->nama_lengkap : $pas_req->input('nama_lengkap_pas'),
            'nama_ibu_kandung' => empty($pas_req->input('nama_ibu_kandung_pas')) ? $c_pas->nama_ibu_kandung : $pas_req->input('nama_ibu_kandung_pas'),
            'jenis_kelamin'    => empty($pas_req->input('jenis_kelamin_pas')) ? $c_pas->jenis_kelamin : $pas_req->input('jenis_kelamin_pas'),
            'no_ktp'           => empty($pas_req->input('no_ktp_pas')) ? $c_pas->no_ktp : $pas_req->input('no_ktp_pas'),
            'no_ktp_kk'        => empty($pas_req->input('no_ktp_kk_pas')) ? $c_pas->no_ktp_kk : $pas_req->input('no_ktp_kk_pas'),
            'no_npwp'          => empty($pas_req->input('no_npwp_pas')) ? $c_pas->no_npwp : $pas_req->input('no_npwp_pas'),
            'tempat_lahir'     => empty($pas_req->input('tempat_lahir_pas')) ? $c_pas->tempat_lahir : $pas_req->input('tempat_lahir_pas'),
            'tgl_lahir'        => empty($pas_req->input('tgl_lahir_pas')) ? $c_pas->tgl_lahir : Carbon::parse($pas_req->input('tgl_lahir_pas'))->format('Y-m-d'),
            'alamat_ktp'       => empty($pas_req->input('nama_lengkap_pas')) ? $c_pas->nama_lengkap : $pas_req->input('nama_lengkap_pas'),
            'no_telp'          => empty($pas_req->input('no_telp_pas')) ? $c_pas->no_telp : $pas_req->input('no_telp_pas'),
            'lamp_ktp'         => $lamp_ktp_pas,
            'lamp_buku_nikah'  => $lamp_buku_nikah_pas
        );

        $c_pen = Penjamin::where('id_transaksi', $id_transaksi)->get();

        if ($c_pen == '[]') {
            return response()->json([
                "code"    => 404,
                "status"  => "not found",
                "message" => "Data Penjamin dengan id transaksi ".$id_transaksi." tida ditemukan"
            ], 404);
        }

        // Data Penjamin
        $dataPenjamin = array();
        foreach ($c_pen as $key => $value)
        {
            if($files = $pen_req->file('lamp_ktp_pen')){
                $name       = 'ktp_penjamin';
                
                $arrayPath = array();
                foreach($files as $file)
                {
                    $arrayPath[] = Helper::uploadImg($value->lamp_ktp[$key], $file, $path_penj, $name);
                }

                $lamp_ktp_pen = $arrayPath;
            }else{
                $lamp_ktp_pen = $value->lamp_ktp;
            }

            if($files = $pen_req->file('lamp_ktp_pasangan_pen')){
                $name       = 'ktp_pasangan_penjamin';

                $arrayPath = array();
                foreach($files as $file)
                {
                    $arrayPath[] = Helper::uploadImg($value->lamp_ktp_pasangan[$key], $file, $path_penj, $name);
                }

                $lamp_ktp_pasangan_pen = $arrayPath;
            }else{
                $lamp_ktp_pasangan_pen = $value->lamp_ktp_pasangan;
            }

            if($files = $pen_req->file('lamp_kk_pen')){
                $name       = 'kk_penjamin';

                $arrayPath = array();
                foreach($files as $file)
                {
                    $arrayPath[] = Helper::uploadImg($value->lamp_kk[$key], $file, $path_penj, $name);
                }

                $lamp_kk_pen = $arrayPath;
            }else{
                $lamp_kk_pen = $value->lamp_kk;
            }

            if($files = $pen_req->file('lamp_buku_nikah_pen')){
                $name       = 'buku_nikah_penjamin';
                $check_file = 'null';

                $arrayPath = array();
                foreach($files as $file)
                {
                    $arrayPath[] = Helper::uploadImg($value->lamp_buku_nikah[$key], $file, $path_penj, $name);
                }

                $lamp_buku_nikah_pen = $arrayPath;
            }else{
                $lamp_buku_nikah_pen = $value->lamp_buku_nikah;
            }

            $dataPenjamin[] = [
                'nama_ktp'         => empty($pen_req->nama_ktp_pen[$key])         ? $value->nama_ktp : $pen_req->nama_ktp_pen[$key],
                'nama_ibu_kandung' => empty($pen_req->nama_ibu_kandung_pen[$key]) ? $value->nama_ibu_kandung : $pen_req->nama_ibu_kandung_pen[$key],
                'no_ktp'           => empty($pen_req->no_ktp_pen[$key])           ? $value->no_ktp : $pen_req->no_ktp_pen[$key],
                'no_npwp'          => empty($pen_req->no_npwp_pen[$key])         ? $value->no_npwp : $pen_req->no_npwp_pen[$key],
                'tempat_lahir'     => empty($pen_req->tempat_lahir_pen[$key])     ? $value->tempat_lahir : $pen_req->tempat_lahir_pen[$key],
                'tgl_lahir'        => empty($pen_req->tgl_lahir_pen[$key])        ? $value->tgl_lahir : Carbon::parse($pen_req->tgl_lahir_pen[$key])->format('Y-m-d'),
                'jenis_kelamin'    => empty($pen_req->jenis_kelamin_pen[$key])    ? $value->jenis_kelamin : $pen_req->jenis_kelamin_pen[$key],
                'alamat_ktp'       => empty($pen_req->alamat_ktp_pen[$key])       ? $value->alamat_ktp : $pen_req->alamat_ktp_pen[$key],
                'no_telp'          => empty($pen_req->no_telp_pen[$key])          ? $value->no_telp : $pen_req->no_telp_pen[$key],
                'hubungan_debitur' => empty($pen_req->hubungan_debitur_pen[$key]) ? $value->hubungan_debitur : $pen_req->hubungan_debitur_pen[$key],
                'lamp_ktp'         => $lamp_ktp_pen[$key],
                'lamp_ktp_pasangan'=> $lamp_ktp_pasangan_pen[$key],
                'lamp_kk'          => $lamp_kk_pen[$key],
                'lamp_buku_nikah'  => $lamp_buku_nikah_pen[$key]
            ];
        }

        DB::connection('web')->beginTransaction();

        try{
            Transaksi::where('id', $id_transaksi)->update($dataTransaksi);

            FasilitasPinjaman::where('id_transaksi', $id_transaksi)->update($dataFasPin);

            Debitur::where('id_transaksi', $id_transaksi)->update($dataDebitur);

            if (!empty($dataPasangan)) {
                Pasangan::where('id_transaksi', $id_transaksi)->update($dataPasangan);
            }

            if (!empty($dataPenjamin)) {

                foreach ($dataPenjamin as $penjamin)
                {
                    Penjamin::where('id_transaksi', $id_transaksi)->update($penjamin);
                }

            }

            DB::connection('web')->commit();

            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'message'=> 'Data berhasil dibuat',
                'data'   => [
                    'transaksi'          => $dataTransaksi,
                    'fasilitas_pinjaman' => $dataFasPin,
                    'debitur'            => $dataDebitur,
                    'pasangan'           => $dataPasangan,
                    'penjamin'           => $dataPenjamin
                ]
            ], 200);
        }catch (\Exception $e) {
            $err = DB::connection('web')->rollback();
            return response()->json([
                'code'    => 501,
                'status'  => 'error',
                'message' => 'terjadi kesalahan, mohon beri laporan kepada backend'
            ], 501);
        }
    }

    public function search($search, Request $req)
    {
        $pic = $req->pic; // From PIC middleware

        $id_area   = $pic->id_area;
        $id_cabang = $pic->id_cabang;
        $scope     = $pic->jpic['cakupan'];

        $query_dir = DB::connection('web')->select("CALL cari_transaksi('{$search}')");

        $query = Helper::checkDir($scope, $query_dir, $id_area, $id_cabang);

        if (empty($query)) {
            return response()->json([
                'code'    => 404,
                'status'  => 'not found',
                'message' => 'Pencarian tidak ditemukan'
            ], 404);
        }

        $data = array();
        foreach ($query as $val) {
            $data[] = [
                'id'              => $val->id,
                'nomor_transaksi' => $val->nomor_transaksi,
                'nama_so'         => $val->nama_so,
                'area'            => $val->area,
                'cabang'          => $val->cabang,
                'asal_data'       => $val->asal_data,
                'nama_marketing'  => $val->nama_marketing,
                'nama_cadeb'      => $val->nama_cadeb,
                // 'fasilitas_pinjaman'  => [
                //      'id'             => $val->id_fasilitas_pinjaman,
                //     'jenis_pinjaman'  => $val->jenis_pinjaman,
                //     'tujuan_pinjaman' => $val->tujuan_pinjaman,
                //     'plafon'          => $val->plafon,
                //     'tenor'           => $val->tenor,
                // ],
                'plafon'          => $val->plafon,
                'tenor'           => $val->tenor,
                'tracking'  => [
                    'status' => [
                        'das'      => $val->status_das,
                        'hm'       => $val->status_hm,
                        'ao'       => $val->status_ao,
                        'ca'       => $val->status_ca,
                        'caa'      => $val->status_caa,
                        'approval' => $val->status_approval
                    ],
                    'pic'   => [
                        'so'    => $val->nama_so,
                        'das'   => $val->nama_das,
                        'hm'    => $val->nama_hm,
                        'ao'    => $val->nama_ao,
                        'ca'    => $val->nama_ca,
                        'caa'   => $val->nama_caa
                    ],
                    'tanggal' => [
                        'tgl_so'  => $val->tgl_so,
                        'tgl_das' => $val->tgl_das,
                        'tgl_hm'  => $val->tgl_hm,
                        'tgl_ao'  => $val->tgl_ao,
                        'tgl_ca'  => $val->tgl_ca,
                        'tgl_caa' => $val->tgl_caa
                    ]
                ],
                'tgl_so' => $val->tgl_so
            ];

        }

        try {
            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'count'  => sizeof($data),
                'data'   => $data
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                "code"    => 501,
                "status"  => "error",
                "message" => $e
            ], 501);
        }
    }

    public function index(Request $req)
    {
        $pic = $req->pic; // From PIC middleware

        $id_area   = $pic->id_area;
        $id_cabang = $pic->id_cabang;
        $scope     = $pic->jpic['cakupan'];

        $query_dir = DB::connection('web')->table('view_transaksi')->get()->toArray();
                
        $query = Helper::checkDir($scope, $query_dir, $id_area, $id_cabang);
        
        if (empty($query)) {
            return response()->json([
                "code"    => 404,
                "status"  => "not found",
                "message" => "Data di SO masih kosong"
            ], 404);
        }

        $data = array();
        foreach ($query as $val) {

            // dd($val);
            
            // $data[$key] = [
            //     'id'              => $val->id,
            //     'nomor_transaksi' => $val->nomor_transaksi,
            //     'nama_so'         => $val->nama_so,
            //     'area'            => $val->area,
            //     'cabang'          => $val->cabang,
            //     'asal_data'       => $val->asal_data,
            //     'nama_marketing'  => $val->nama_marketing,
            //     'nama_calon_debt' => $val->nama_cadeb,
            // 'fasilitas_pinjaman'  => [
            //     'jenis_pinjaman'  => $transaksi->jenis_pinjaman,
            //     'tujuan_pinjaman' => $transaksi->tujuan_pinjaman,
            //     'plafon'          => $transaksi->plafon,
            //     'tenor'           => $transaksi->tenor,
            // ],
                // 'tracking'  => [
                //     'status' => [
                //         'das'      => $transaksi->status_das,
                //         'hm'       => $transaksi->status_hm,
                //         'ao'       => $transaksi->status_ao,
                //         'ca'       => $transaksi->status_ca,
                //         'caa'      => $transaksi->status_caa,
                //         'approval' => $transaksi->status_approval
                //     ],
                //     'pic'   => [
                //         'so'    => $transaksi->nama_so,
                //         'das'   => $transaksi->nama_das,
                //         'hm'    => $transaksi->nama_hm,
                //         'ao'    => $transaksi->nama_ao,
                //         'ca'    => $transaksi->nama_ca,
                //         'caa'   => $transaksi->nama_caa
                //     ],
                //     'tanggal' => [
                //         'tgl_so'  => $transaksi->tgl_so,
                //         'tgl_das' => $transaksi->tgl_das,
                //         'tgl_hm'  => $transaksi->tgl_hm,
                //         'tgl_ao'  => $transaksi->tgl_ao,
                //         'tgl_ca'  => $transaksi->tgl_ca,
                //         'tgl_caa' => $transaksi->tgl_caa
                //     ]
                // ],
            //     'tgl_so' => $val->tgl_so
            // ];

            $data[] = [
                'id'              => $val->id,
                'nomor_so'        => $val->nomor_transaksi,
                'nama_so'         => $val->nama_so,
                'pic'             => $val->nama_so,
                'area'            => $val->area,
                'cabang'          => $val->cabang,
                'asal_data'       => $val->asal_data,
                'nama_marketing'  => $val->nama_marketing,
                'nama_debitur'    => $val->nama_cadeb,
                'nama_calon_debt' => $val->nama_cadeb,
                'plafon'          => $val->plafon,
                'tenor'           => $val->tenor,
                'status'          => $val->status_das,
                'das' => [
                    'status'  => $val->status_das,
                    'catatan' => $val->catatan_das
                ],
                'hm'  => [
                    'status'  => $val->status_hm,
                    'catatan' => $val->catatan_hm
                ],
                'tgl_transaksi' => $val->tgl_so
            ];
        }

        try {
            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'count'  => sizeof($data),
                'data'   => $data
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                "code"    => 501,
                "status"  => "error",
                "message" => $e
            ], 501);
        }

    }

    public function show($id_transaksi, Request $req)
    {
        $pic = $req->pic; // From PIC middleware

        $id_area   = $pic->id_area;
        $id_cabang = $pic->id_cabang;
        $scope     = $pic->jpic['cakupan'];

        $query_dir = DB::connection('web')->table('view_transaksi')->where('id', $id_transaksi)->get()->toArray();

        $query = Helper::checkDir($scope, $query_dir, $id_area, $id_cabang);

        if (!$query) {
            return response()->json([
                "code"    => 404,
                "status"  => "not found",
                "message" => "Data dengan id ".$id_transaksi." tidak ditemukan"
            ], 404);
        }

        $val = $query[0];

        // $data = [
        //     'id'              => $val->id,
        //     'nomor_transaksi' => $val->nomor_transaksi,
        //     'nama_so'         => $val->nama_so,
        //     'id_pic_so'       => $val->id_pic_so,
        //     'nama_pic'        => $val->nama_so,
        //     'nama_marketing'  => $val->nama_marketing,
        //     'area'   => [
        //         'id'      => $val->id_area,
        //         'nama'    => $val->area
        //     ],
        //     'cabang' => [
        //         'id'   => $val->id_cabang,
        //         'nama' => $val->cabang,
        //     ]
            // 'tracking'  => [
            //     'status' => [
            //         'das'      => $val->status_das,
            //         'hm'       => $val->status_hm,
            //         'ao'       => $val->status_ao,
            //         'ca'       => $val->status_ca,
            //         'caa'      => $val->status_caa,
            //         'approval' => $val->status_approval
            //     ],
            //     'pic'   => [
            //         'so'    => $val->nama_so,
            //         'das'   => $val->nama_das,
            //         'hm'    => $val->nama_hm,
            //         'ao'    => $val->nama_ao,
            //         'ca'    => $val->nama_ca,
            //         'caa'   => $val->nama_caa
            //     ],
            //     'tanggal' => [
            //         'tgl_so'  => $val->tgl_so,
            //         'tgl_das' => $val->tgl_das,
            //         'tgl_hm'  => $val->tgl_hm,
            //         'tgl_ao'  => $val->tgl_ao,
            //         'tgl_ca'  => $val->tgl_ca,
            //         'tgl_caa' => $val->tgl_caa
            //     ]
            // ],
        //     'asal_data' => [
        //         'id'   => $val->id_asal_data,
        //         'nama' => $val->asal_data,
        //     ],
            // 'fasilitas_pinjaman' => FasilitasPinjaman::where('id_transaksi', $id_transaksi)->first()->makeHidden('id_transaksi'),
            // 'calon_debitur' => Debitur::where('id_transaksi', $id_transaksi)->first()->makeHidden('id_transaksi'),
            // 'pasangan'      => Pasangan::where('id_transaksi', $id_transaksi)->first()->makeHidden('id_transaksi'),
            // 'penjamin'      => Penjamin::where('id_transaksi', $id_transaksi)->get()->makeHidden('id_transaksi'),
        //     'tgl_so'        => $val->tgl_so
        // ];

        $data = [
            'id'          => $val->id,
            'nomor_so'    => $val->nomor_transaksi,
            'nama_so'     => $val->nama_so,
            'id_pic'      => $val->id_pic_so,
            'nama_pic'    => $val->nama_so,
            'area'   => [
                'id'      => $val->id_area,
                'nama'    => $val->area
            ],
            'id_cabang'   => $val->id_cabang,
            'nama_cabang' => $val->cabang,
            'tracking'  => [
                'status' => [
                    'das'      => $val->status_das,
                    'hm'       => $val->status_hm,
                    'ao'       => $val->status_ao,
                    'ca'       => $val->status_ca,
                    'caa'      => $val->status_caa,
                    'approval' => $val->status_approval
                ],
                'pic'   => [
                    'so'    => $val->nama_so,
                    'das'   => $val->nama_das,
                    'hm'    => $val->nama_hm,
                    'ao'    => $val->nama_ao,
                    'ca'    => $val->nama_ca,
                    'caa'   => $val->nama_caa
                ],
                'tanggal' => [
                    'tgl_so'  => $val->tgl_so,
                    'tgl_das' => $val->tgl_das,
                    'tgl_hm'  => $val->tgl_hm,
                    'tgl_ao'  => $val->tgl_ao,
                    'tgl_ca'  => $val->tgl_ca,
                    'tgl_caa' => $val->tgl_caa
                ]
            ],
            'asal_data' => [
                'id'   => $val->id_asal_data,
                'nama' => $val->asal_data,
            ],
            'nama_marketing'     => $val->nama_marketing,
            'fasilitas_pinjaman' => FasilitasPinjaman::where('id_transaksi', $id_transaksi)->first()->makeHidden('id_transaksi'),
            'calon_debitur' => Debitur::where('id_transaksi', $id_transaksi)->first()->makeHidden('id_transaksi'),
            'pasangan'      => Pasangan::where('id_transaksi', $id_transaksi)->first()->makeHidden('id_transaksi'),
            'penjamin'      => Penjamin::where('id_transaksi', $id_transaksi)->get()->makeHidden('id_transaksi'),
            'flg_aktif'     => $val->flg_aktif,
            'tgl_transaksi' => $val->tgl_so
        ];

        try {
            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'data'   => $data
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                "code"    => 501,
                "status"  => "error",
                "message" => $e
            ], 501);
        }
    }
}