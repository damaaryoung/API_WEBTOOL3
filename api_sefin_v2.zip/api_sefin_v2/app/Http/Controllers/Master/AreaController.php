<?php

namespace App\Http\Controllers\Master;

use Laravel\Lumen\Routing\Controller as BaseController;
use App\Http\Requests\AreaKantor\AreaRequest;
use App\Models\Master\Area;
use App\Models\Wilayah\Provinsi;
use App\Models\Wilayah\Kabupaten;
use Carbon\Carbon;
use Cache;
use DB;

class AreaController extends BaseController
{
    public function __construct() {
        $this->time_cache = config('app.cache_exp');
    }

    public function index() 
    {
        $data = array();

        // $query = Cache::remember('area.index', $this->time_cache, function () use ($data) {

            Area::select('id', 'nama as nama_area', 'id_provinsi', 'id_kabupaten')
                ->addSelect([
                    'nama_provinsi'  => Provinsi::select('nama')->whereColumn('id_provinsi', 'master_provinsi.id'),
                    'nama_kabupaten' => Kabupaten::select('nama')->whereColumn('id_kabupaten', 'master_kabupaten.id')
                ])
                ->where('flg_aktif', 1)
                ->orderBy('nama', 'asc')
                ->chunk(50, function($chunks) use (&$data) {
                    foreach($chunks as $chunk) {
                        $data[] = $chunk;
                    }
                });

            // return $data;
        // });

        if (empty($data)) {
            return response()->json([
                'code'    => 404,
                'status'  => 'not found',
                'message' => 'Data kosong'
            ], 404);
        }

        try {
            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'count'  => sizeof($data),
                'data'   => $data
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                "code"    => 501,
                "status"  => "error",
                "message" => $e
            ], 501);
        }
    }

    public function store(AreaRequest $req) {
        $data = array(
            'nama'         => $req->input('nama'),
            'id_provinsi'  => $req->input('id_provinsi'),
            'id_kabupaten' => $req->input('id_kabupaten'),
            'flg_aktif'    => 1
        );

        Area::create($data);

        try {
            return response()->json([
                'code'    => 200,
                'status'  => 'success',
                'message' => 'Data berhasil dibuat',
                'data'    => $data
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                "code"    => 501,
                "status"  => "error",
                "message" => $e
            ], 501);
        }
    }

    public function show($id) {
        $query = Area::select(
            'id', 'nama as nama_area', 'id_provinsi', 'id_kabupaten', 'flg_aktif', 'created_at', 'updated_at'
        )
        ->addSelect([
            'nama_provinsi'  => Provinsi::select('nama')->whereColumn('id_provinsi', 'master_provinsi.id'),
            'nama_kabupaten' => Kabupaten::select('nama')->whereColumn('id_kabupaten', 'master_kabupaten.id')
        ])
        ->where('id', $id)->first();

        if (empty($query)) {
            return response()->json([
                'code'    => 404,
                'status'  => 'not found',
                'message' => 'Data tidak ada'
            ], 404);
        }

        try {
            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'data'   => $query
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'code'   => 501,
                'status' => 'error',
                'data'   => $e
            ], 501);
        }
    }

    public function update($id, AreaRequest $req) 
    {
        $check = Area::where('id', $id)->first();

        if (empty($check)) {
            return response()->json([
                'code'    => 404,
                'status'  => 'not found',
                'message' => 'Data tidak ada'
            ], 404);
        }

        $data = array(
            'nama'         => empty($req->input('nama'))
                ? $check->nama : $req->input('nama'),

            'id_provinsi'  => empty($req->input('id_provinsi'))
                ? $check->id_provinsi : $req->input('id_provinsi'),

            'id_kabupaten' => empty($req->input('id_kabupaten'))
                ? $check->id_kabupaten : $req->input('id_kabupaten'),

            'flg_aktif'    => empty($req->input('flg_aktif'))
                ? $check->flg_aktif : ($req->input('flg_aktif') == 'false' ? 0 : 1)
        );

        Area::where('id', $id)->update($data);

        try {
            return response()->json([
                'code'    => 200,
                'status'  => 'success',
                'message' => 'Data berhasil diupdate',
                'data'    => $data
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'code'   => 501,
                'status' => 'error',
                'data'   => $e
            ], 501);
        }
    }

    public function delete($id) 
    {
        Area::where('id', $id)->update(['flg_aktif' => 0]);
    
        try {
            return response()->json([
                'code'    => 200,
                'status'  => 'success',
                'message' => 'Data dengan id '.$id.' berhasil dihapus'
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'code'   => 501,
                'status' => 'error',
                'data'   => $e
            ], 501);
        }
    }

    public function trash() 
    {
        $data = array();

        Area::select('id', 'nama as nama_area', 'id_provinsi', 'id_kabupaten', 'flg_aktif')
        ->addSelect([
            'nama_provinsi'  => Provinsi::select('nama')->whereColumn('id_provinsi', 'master_provinsi.id'),
            'nama_kabupaten' => Kabupaten::select('nama')->whereColumn('id_kabupaten', 'master_kabupaten.id')
        ])
        ->where('flg_aktif', 0)
        ->orderBy('nama', 'asc')
        ->chunk(50, function($chunks) use (&$data) {
            foreach($chunks as $chunk) {
                $data[] = $chunk;
            }
        });

        if (empty($data)) {
            return response()->json([
                'code'    => 404,
                'status'  => 'not found',
                'message' => 'Data kosong'
            ], 404);
        }

        try {
            return response()->json([
                'code'    => 200,
                'status'  => 'success',
                'count'   => sizeof($data),
                'data'    => $data
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'code'   => 501,
                'status' => 'error',
                'data'   => $e
            ], 501);
        }
    }

    public function restore($id) 
    {
        Area::where('id', $id)->update(['flg_aktif' => 1]);

        try {
            return response()->json([
                'code'    => 200,
                'status'  => 'success',
                'message' => 'Data berhasil dikembalikan'
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'code'   => 501,
                'status' => 'error',
                'data'   => $e
            ], 501);
        }
    }

    public function search($search)
    {
        $query = DB::connection('web')->table('mk_area')
        ->leftJoin('master_provinsi', 'mk_area.id_provinsi', 'master_provinsi.id')
        ->leftJoin('master_kabupaten', 'mk_area.id_kabupaten', 'master_kabupaten.id')
        ->select('mk_area.id', 'mk_area.nama as nama_area', 'master_provinsi.nama as nama_provinsi', 'master_kabupaten.nama as nama_kabupaten', 'mk_area.flg_aktif')
        ->where("mk_area.id", "like", "%{$search}%")
        ->orWhere("mk_area.nama", "like", "%{$search}%")
        ->orWhere("master_provinsi.nama", "like", "%{$search}%")
        // ->orWhere("master_kabupaten.nama", "like", "%{$search}%")
        ->get()->toArray();

        if (empty($query)) {
            return response()->json([
                'code'    => 404,
                'status'  => 'not found',
                'message' => 'Pencarian tidak ditemukan'
            ], 404);
        }

        try {
            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'count'  => sizeof($query),
                'data'   => $query
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                "code"    => 501,
                "status"  => "error",
                "message" => $e
            ], 501);
        }
    }
}
