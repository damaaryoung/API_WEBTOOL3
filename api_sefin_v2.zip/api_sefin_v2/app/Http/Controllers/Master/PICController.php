<?php

namespace App\Http\Controllers\Master;

use Laravel\Lumen\Routing\Controller as BaseController;
// use App\Http\Controllers\Controller as Helper;
use App\Http\Requests\AreaKantor\PICRequest;
use App\Models\Master\PIC;
use App\Models\Master\JPIC;
use App\Models\Master\Area;
use App\Models\Master\Cabang;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Cache;
use DB;

class PICController extends BaseController
{
    public function __construct() {
        $this->time_cache = config('app.cache_exp');
        $this->chunk      = 50;
    }

    public function index() 
    {
        $data = array();

        // $query = Cache::remember('pic.index', $this->time_cache, function () use ($data) {
            
            PIC::select('id', 'nama', 'email', 'user_id', 'id_area', 'id_cabang', 'plafon_caa as plafon_max')
            ->addSelect([
                'jenis_pic'   => JPIC::select('nama_jenis')->whereColumn('id_mj_pic', 'mj_pic.id'),
                'nama_area'   => Area::select('nama')->whereColumn('id_area', 'mk_area.id'),
                'nama_cabang' => Cabang::select('nama')->whereColumn('id_cabang', 'mk_cabang.id'),
            ])
            ->where('flg_aktif', 1)
            ->orderBy('nama', 'asc')
            ->chunk($this->chunk, function($chunks) use (&$data) 
            {
               foreach($chunks as $chunk)
               {
                   $data[] = $chunk;
               }
            });

            // return $data;
        // });

        if (empty($data)) {
            return response()->json([
                'code'    => 404,
                'status'  => 'not found',
                'message' => 'Data kosong'
            ], 404);
        }

        try {
            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'count'  => count($data),
                'data'   => $data
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                "code"    => 501,
                "status"  => "error",
                "message" => $e
            ], 501);
        }
    }

    public function store(PICRequest $req)
    {
        $data = array(
            'user_id'       => $req->input('user_id'),
            'id_area'       => $req->input('id_mk_area'),
            'id_cabang'     => $req->input('id_mk_cabang'),
            'id_mj_pic'     => $req->input('id_mj_pic'),
            'nama'          => $req->input('nama'),
            'email'         => $req->input('email')
        );

        PIC::create($data);

        try {
            return response()->json([
                'code'    => 200,
                'status'  => 'success',
                'message' => 'Data berhasil dibuat',
                'data'    => $data
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                "code"    => 501,
                "status"  => "error",
                "message" => $e
            ], 501);
        }
    }

    public function show($id) 
    {
        $query = PIC::select(
            "id","nama","email","user_id","id_mj_pic as id_jenis_pic","id_area","id_cabang","plafon_caa as plafon_max","flg_aktif", "created_at"
        )->addSelect([
            'nama_jenis_pic' => JPIC::select('nama_jenis')->whereColumn('id_mj_pic', 'mj_pic.id'),
            'jabatan'        => JPIC::select('nama_jenis')->whereColumn('id_mj_pic', 'mj_pic.id'),
            'nama_area'      => Area::select('nama')->whereColumn('id_area', 'mk_area.id'),
            'nama_cabang'    => Cabang::select('nama')->whereColumn('id_cabang', 'mk_cabang.id'),
        ])->where('id', $id)->first();

        if (empty($query)) {
            return response()->json([
                'code'    => 404,
                'status'  => 'not found',
                'message' => 'Data tidak ada'
            ], 404);
        }
    
        try {
            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'data'   => $query
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'code'   => 501,
                'status' => 'error',
                'data'   => $e
            ], 501);
        }
    }

    public function update($id, PICRequest $req) 
    {
        $check = PIC::where('id', $id)->first();

        if (empty($check)) {
            return response()->json([
                'code'    => 404,
                'status'  => 'not found',
                'message' => 'Data tidak ada'
            ], 404);
        }

        $data = array(
            'nama'         => empty($req->input('nama')) ? $check->nama : $req->input('nama'),
            'email'        => empty($req->input('email')) ? $check->email : $req->input('email'),
            'user_id'      => empty($req->input('user_id')) ? $check->user_id : $req->input('user_id'),
            'id_area'      => empty($req->input('id_mk_area')) ? $check->id_area : $req->input('id_mk_area'),
            'id_cabang'    => empty($req->input('id_mk_cabang')) ? $check->id_cabang : $req->input('id_mk_cabang'),
            'id_mj_pic'    => empty($req->input('id_mj_pic')) ? $check->id_mj_pic : $req->input('id_mj_pic'),
            'flg_aktif'    => empty($req->input('flg_aktif')) ? $check->flg_aktif : ($req->input('flg_aktif') == 'false' ? 0 : 1)
        );

        PIC::where('id', $id)->update($data);

        try {
            return response()->json([
                'code'    => 200,
                'status'  => 'success',
                'message' => 'Data berhasil diupdate',
                'data'    => $data
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'code'   => 501,
                'status' => 'error',
                'data'   => $e
            ], 501);
        }
    }

    public function delete($id) 
    {
        PIC::where('id', $id)->update(['flg_aktif' => 0]);

        try {
            return response()->json([
                'code'    => 200,
                'status'  => 'success',
                'message' => 'Data dengan id '.$id.' berhasil dihapus'
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'code'   => 501,
                'status' => 'error',
                'data'   => $e
            ], 501);
        }
    }

    public function trash() 
    {
        $data = array();

        PIC::select('id', 'nama', 'email', 'user_id', 'id_area', 'id_cabang', 'plafon_caa as plafon_max')
        ->addSelect([
            'jenis_pic'   => JPIC::select('nama_jenis')->whereColumn('id_mj_pic', 'mj_pic.id'),
            'nama_area'   => Area::select('nama')->whereColumn('id_area', 'mk_area.id'),
            'nama_cabang' => Cabang::select('nama')->whereColumn('id_cabang', 'mk_cabang.id'),
        ])
        ->where('flg_aktif', 1)
        ->orderBy('nama', 'asc')
        ->chunk($this->chunk, function($chunks) use (&$data) 
        {
            foreach($chunks as $chunk)
            {
                $data[] = $chunk;
            }
        });

        if (empty($data)){
            return response()->json([
                'code'    => 404,
                'status'  => 'not found',
                'message' => 'Data kosong'
            ], 404);
        }

        try {
            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'count'  => sizeof($data),
                'data'   => $data
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                "code"    => 501,
                "status"  => "error",
                "message" => $e
            ], 501);
        }
    }

    public function restore($id) 
    {
        PIC::where('id', $id)->update(['flg_aktif' => 1]);

        try {
            return response()->json([
                'code'    => 200,
                'status'  => 'success',
                'message' => 'data berhasil dikembalikan'
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                "code"    => 501,
                "status"  => "error",
                "message" => $e
            ], 501);
        }
    }

    public function search($search)
    {
        $query = DB::connection('web')->table('m_pic')
        ->leftJoin('mj_pic', 'm_pic.id_mj_pic', 'mj_pic.id')
        ->leftJoin('mk_area', 'm_pic.id_area', 'mk_area.id')
        ->leftJoin('mk_cabang', 'm_pic.id_cabang', 'mk_cabang.id')
        ->select(
            'm_pic.id', 'm_pic.nama', 'm_pic.email',
            'mj_pic.nama_jenis as jenis_pic',
            'mk_area.nama as nama_area',
            'mk_cabang.nama as nama_cabang'
        )
        ->where("m_pic.id", "like", "%{$search}%")
        ->orWhere("m_pic.nama", "like", "%{$search}%")
        ->orWhere("m_pic.email", "like", "%{$search}%")
        ->orWhere("mj_pic.nama_jenis", "like", "%ao%")
        // ->orWhere("mk_area.nama", "like", "%{$search}%")
        ->orWhere("mk_cabang.nama", "like", "%{$search}%")
        ->get()->toArray();

        if (empty($query)) {
            return response()->json([
                'code'    => 404,
                'status'  => 'not found',
                'message' => 'Data kosong'
            ], 404);
        }

        try {
            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'count'  => sizeof($query),
                'data'   => $query
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                "code"    => 501,
                "status"  => "error",
                "message" => $e
            ], 501);
        }
    }

    public function team_caa(Request $req)
    {
        $pic = $req->pic; // From PIC middleware

        $id_area   = $pic->id_area;
        $id_cabang = $pic->id_cabang;
        $scope     = $pic->jpic['cakupan'];

        $query = PIC::with(['jpic', 'area','cabang'])
        ->whereHas('jpic', function($q) {
            // Query the name field in status table
            $q->where('bagian', '=', 'team_caa');
        })
        ->where('flg_aktif', 1);

        if($scope == 'PUSAT')
        {
            $parQuery = $query->get()->sortByDesc('jpic.urutan_jabatan');
        }
        elseif($scope == 'AREA')
        {
            $parQuery = $query->whereHas('area', function($q) use($id_area) {
                $q->where('id', $id_area);
                $q->orWhere('nama', 'Pusat');
            })
            ->get()
            ->sortByDesc('jpic.urutan_jabatan');
        }
        elseif($scope == 'CABANG')
        {
            $parQuery = $query->whereHas('cabang', function($q) use($id_cabang) {
                $q->where('id', $id_cabang);
                $q->orWhere('nama', 'Pusat');
            })
            ->get()
            ->sortByDesc('jpic.urutan_jabatan');
        }
        else // Untuk Kantor Kas
        {
            $parQuery = $query->whereHas('cabang', function($q) use($id_cabang) {
                $q->where('id', $id_cabang);
                $q->orWhere('iks', $id_cabang);
                $q->orWhere('nama', 'Pusat');
            })
            ->get()
            ->sortByDesc('jpic.urutan_jabatan');
        }

        if ($parQuery == '[]') {
            return response()->json([
                'code'    => 404,
                'status'  => 'not found',
                'message' => 'Data kosong'
            ], 404);
        }

        $data = array();
        foreach ($parQuery as $val) {

            $data[] = array(
                "id"        => $val->id,
                "user_id"   => $val->user_id,
                "plafon_max"=> $val->plafon_caa,
                "nama_area" => $val->area['nama'],
                "cabang"    => $val->cabang['nama'],
                "jabatan"   => $val->jpic['nama_jenis'],
                "nama"      => $val->nama,
                "email"     => $val->email,
                // "flg_aktif" => (bool) $val->flg_aktif,
            );

        }

        try {
            return response()->json([
                'code'   => 200,
                'status' => 'success',
                'data'   => $data
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                "code"    => 501,
                "status"  => "error",
                "message" => $e
            ], 501);
        }
    }
}
