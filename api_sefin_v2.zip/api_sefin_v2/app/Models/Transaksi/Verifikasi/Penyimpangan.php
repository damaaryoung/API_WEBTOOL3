<?php

namespace App\Models\Transaksi\Verifikasi;

use Illuminate\Auth\Authenticatable;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Database\Eloquent\Model;
use Laravel\Lumen\Auth\Authorizable;

// Relationship
use App\Models\Transaksi\Transaksi;

class Penyimpangan extends Model implements AuthenticatableContract, AuthorizableContract
{
    use Authenticatable, Authorizable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $connection = 'web';

    protected $table = 'penyimpangan_caa';
    protected $primaryKey = 'id';

    protected $fillable = [
       'biaya_provisi','biaya_admin','biaya_kredit','ltv','tenor','kartu_pinjaman','sertifikat_diatas_50','sertifikat_diatas_150', 'profesi_beresiko', 'jaminan_kp_tenor_48', 'id_transaksi', 'id_trans_caa'
    ];

    public $timestamps = false;

    protected $casts = [
        'id'                    => 'integer',
        'biaya_provisi'         => 'boolean',
        'biaya_admin'           => 'boolean',
        'biaya_kredit'          => 'boolean',
        'ltv'                   => 'boolean',
        'tenor'                 => 'boolean',
        'kartu_pinjaman'        => 'boolean',
        'sertifikat_diatas_50'  => 'boolean',
        'sertifikat_diatas_150' => 'boolean',
        'profesi_beresiko'      => 'boolean',
        'jaminan_kp_tenor_48'   => 'boolean',
        'id_transaksi'          => 'integer',
        'id_trans_caa'          => 'integer'
    ];

    public function transaksi(){
        return $this->belongsTo(Transaksi::class, 'id_transaksi')
            ->withDefault(function () {
                return new Transaksi();
            });
    }
}
