<?php

namespace App\Models\Transaksi\Rekomendasi;

use Illuminate\Auth\Authenticatable;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Database\Eloquent\Model;
use Laravel\Lumen\Auth\Authorizable;

// Relationship
use App\Models\Transaksi\Transaksi;

class RekomendasiPinjaman extends Model implements AuthenticatableContract, AuthorizableContract
{
    use Authenticatable, Authorizable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $connection = 'web';

    protected $table = 'rekomendasi_pinjaman';
    protected $primaryKey = 'id';

    protected $fillable = [
       'penyimpangan_struktur', 'penyimpangan_dokumen', 'recom_nilai_pinjaman', 'recom_tenor', 'recom_angsuran', 'recom_produk_kredit', 'note_recom', 'bunga_pinjaman', 'nama_ca', 'id_transaksi'
    ];

    protected $casts = [
        'id'                   => 'integer',
        'recom_nilai_pinjaman' => 'integer',
        'recom_tenor'          => 'integer',
        'recom_angsuran'       => 'integer',
        'bunga_pinjaman'       => 'float',
        'id_transaksi'         => 'integer'
    ];

    public $timestamps = false;

    public function transaksi(){
        return $this->belongsTo(Transaksi::class, 'id_transaksi')
            ->withDefault(function () {
                return new Transaksi();
            });
    }
}
