<?php

namespace App\Models\Transaksi\Kalkulasi;

use Illuminate\Auth\Authenticatable;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Database\Eloquent\Model;
use Laravel\Lumen\Auth\Authorizable;

// Relationship
use App\Models\Transaksi\Transaksi;

class MutasiBank extends Model implements AuthenticatableContract, AuthorizableContract
{
    use Authenticatable, Authorizable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $connection = 'web';

    protected $table = 'mutasi_bank';
    protected $primaryKey = 'id';

    protected $fillable = [
        'urutan_mutasi', 'nama_bank', 'no_rekening', 'nama_pemilik', 'periode', 'frek_debet', 'nominal_debet', 'frek_kredit', 'nominal_kredit', 'saldo', 'id_transaksi'
    ];

    public $timestamps = false;

    protected $casts = [
        'id'             => 'integer',
        'urutan_mutasi'  => 'integer',
        'nominal_debet'  => 'integer',
        'nominal_kredit' => 'integer',
        'saldo'          => 'integer',
        'id_transaksi'   => 'integer'
    ];

    public function transaksi(){
        return $this->belongsTo(Transaksi::class, 'id_transaksi')
            ->withDefault(function () {
                return new Transaksi();
            });
    }
}
