<?php

namespace App\Models\Transaksi\Kalkulasi;

use Illuminate\Auth\Authenticatable;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Database\Eloquent\Model;
use Laravel\Lumen\Auth\Authorizable;

// Relationship
use App\Models\Transaksi\Transaksi;

class KapBulanan extends Model implements AuthenticatableContract, AuthorizableContract
{
    use Authenticatable, Authorizable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $connection = 'web';

    protected $table = 'kapasitas_bulanan';
    protected $primaryKey = 'id';

    protected $fillable = [
       'pemasukan_cadebt', 'pemasukan_pasangan', 'pemasukan_penjamin', 'biaya_rumah_tangga', 'biaya_transport', 'biaya_pendidikan', 'telp_listr_air', 'angsuran', 'biaya_lain', 'total_pemasukan', 'total_pengeluaran', 'penghasilan_bersih', 'disposable_income', 'ao_ca', 'id_transaksi'
    ];

    protected $casts = [
        'id'                    => 'integer',
        'pemasukan_cadebt'      => 'integer',
        'pemasukan_pasangan'    => 'integer',
        'pemasukan_penjamin'    => 'integer',
        'biaya_rumah_tangga'    => 'integer',
        'biaya_transport'       => 'integer',
        'biaya_pendidikan'      => 'integer',
        'telp_listr_air'        => 'integer',
        'angsuran'              => 'integer',
        'biaya_lain'            => 'integer',
        'total_pemasukan'       => 'integer',
        'total_pengeluaran'     => 'integer',
        'penghasilan_bersih'    => 'integer',
        'disposable_income'     => 'integer',
        'id_transaksi'          => 'integer'
    ];

    public $timestamps = false;

    public function transaksi(){
        return $this->belongsTo(Transaksi::class, 'id_transaksi')
            ->withDefault(function () {
                return new Transaksi();
            });
    }
}
