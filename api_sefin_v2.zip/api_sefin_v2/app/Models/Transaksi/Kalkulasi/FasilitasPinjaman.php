<?php

namespace App\Models\Transaksi\Kalkulasi;

use Illuminate\Auth\Authenticatable;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Database\Eloquent\Model;
use Laravel\Lumen\Auth\Authorizable;

// Relationship
use App\Models\Transaksi\Transaksi;

class FasilitasPinjaman extends Model implements AuthenticatableContract, AuthorizableContract
{
    use Authenticatable, Authorizable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $connection = 'web';

    protected $table = 'fasilitas_pinjaman';
    protected $primaryKey = 'id';

    protected $fillable = [
        'jenis_pinjaman', 'tujuan_pinjaman', 'plafon', 'tenor', 'segmentasi_bpr', 'id_transaksi'
    ];

    protected $casts = [
        'id'           => 'integer',
        'plafon'       => 'integer',
        'tenor'        => 'integer',
        'id_transaksi' => 'integer'
    ];

    public $timestamps = false;

    public function transaksi(){
        return $this->belongsTo(Transaksi::class, 'id_transaksi')
            ->withDefault(function () {
                return new Transaksi();
            });
    }
}
