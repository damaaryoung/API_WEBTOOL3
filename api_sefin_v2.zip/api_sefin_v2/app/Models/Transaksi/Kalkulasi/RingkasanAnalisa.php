<?php

namespace App\Models\Transaksi\Kalkulasi;

use Illuminate\Auth\Authenticatable;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Database\Eloquent\Model;
use Laravel\Lumen\Auth\Authorizable;

// Relationship
use App\Models\Transaksi\Transaksi;

class RingkasanAnalisa extends Model implements AuthenticatableContract, AuthorizableContract
{
    use Authenticatable, Authorizable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $connection = 'web';

    protected $table = 'ringkasan_analisa_ca';
    protected $primaryKey = 'id';

    protected $fillable = [
        'kuantitatif_ttl_pendapatan', 'kuantitatif_ttl_pengeluaran', 'kuantitatif_pendapatan_bersih', 'kuantitatif_angsuran', 'kuantitatif_ltv', 'kuantitatif_dsr', 'kuantitatif_idir', 'kuantitatif_hasil', 'kualitatif_analisa', 'kualitatif_strenght', 'kualitatif_weakness', 'kualitatif_opportunity', 'kualitatif_threatness', 'id_transaksi'
    ];

    protected $casts = [
        'id'                            => 'integer',
        'kuantitatif_ttl_pendapatan'    => 'integer',
        'kuantitatif_ttl_pengeluaran'   => 'integer',
        'kuantitatif_pendapatan_bersih' => 'integer',
        'kuantitatif_angsuran'          => 'integer',
        'kuantitatif_ltv'               => 'float',
        'kuantitatif_dsr'               => 'float',
        'kuantitatif_idir'              => 'float',
        'id_transaksi'                  => 'integer'
    ];

    public $timestamps = false;

    public function transaksi(){
        return $this->belongsTo(Transaksi::class, 'id_transaksi')
            ->withDefault(function () {
                return new Transaksi();
            });
    }
}
