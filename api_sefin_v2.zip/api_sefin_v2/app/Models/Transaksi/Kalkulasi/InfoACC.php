<?php

namespace App\Models\Transaksi\Kalkulasi;

use Illuminate\Auth\Authenticatable;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Database\Eloquent\Model;
use Laravel\Lumen\Auth\Authorizable;

// Relationship
use App\Models\Transaksi\Transaksi;

class InfoACC extends Model implements AuthenticatableContract, AuthorizableContract
{
    use Authenticatable, Authorizable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $connection = 'web';

    protected $table = 'informasi_analisa_cc';
    protected $primaryKey = 'id';

    protected $fillable = [
       'nama_bank', 'plafon', 'baki_debet', 'angsuran', 'collectabilitas', 'jenis_kredit', 'id_transaksi'
    ];

    protected $casts = [
        'id'              => 'integer',
        'plafon'          => 'integer',
        'baki_debet'      => 'integer',
        'angsuran'        => 'integer',
        'collectabilitas' => 'integer',
        'id_transaksi'    => 'integer'
    ];

    public $timestamps = false;

    public function transaksi(){
        return $this->belongsTo(Transaksi::class, 'id_transaksi')
            ->withDefault(function () {
                return new Transaksi();
            });
    }
}
