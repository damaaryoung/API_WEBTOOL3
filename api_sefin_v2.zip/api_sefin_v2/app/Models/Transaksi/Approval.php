<?php

namespace App\Models\Transaksi;

use Illuminate\Auth\Authenticatable;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Database\Eloquent\Model;
use Laravel\Lumen\Auth\Authorizable;

// Relationship
use App\Models\Transaksi\Transaksi;
use App\Models\Transaksi\TransCAA;
use App\Models\Master\Area;
use App\Models\Master\Cabang;
use App\Models\Master\PIC;

class Approval extends Model implements AuthenticatableContract, AuthorizableContract
{
    use Authenticatable, Authorizable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $connection = 'web';

    protected $table = 'tb_approval';
    protected $primaryKey = 'id';

    protected $fillable = [
        'id_pic', 'id_area', 'id_cabang', 'plafon', 'tenor', 'rincian',	'status', 'tujuan_forward', 'id_transaksi', 'id_trans_caa'
    ];

    protected $casts = [
        'id'            => 'integer',
        'id_pic'        => 'integer',
        'id_area'       => 'integer',
        'id_cabang'     => 'integer',
        'plafon'        => 'integer',
        'tenor'         => 'integer',
        'id_transaksi'  => 'integer',
        'id_trans_caa'  => 'integer',
        'created_at'    => 'date:m-d-Y H:i:s',
        'updated_at'    => 'date:m-d-Y H:i:s'
    ];

    public function pic(){
        return $this->belongsTo(PIC::class, 'id_pic')
            ->withDefault(function () {
                return new PIC();
            });
    }

    public function area(){
        return $this->belongsTo(Area::class, 'id_area')
            ->withDefault(function () {
                return new Area();
            });
    }

    public function cabang(){
        return $this->belongsTo(Cabang::class, 'id_cabang')
            ->withDefault(function () {
                return new Cabang();
            });
    }

    public function transaksi(){
        return $this->belongsTo(Transaksi::class, 'id_transaksi')
            ->withDefault(function () {
                return new Transaksi();
            });
    }

    public function caa(){
        return $this->belongsTo(TransCAA::class, 'id_trans_caa')
            ->withDefault(function () {
                return new TransCAA();
            });
    }
}
