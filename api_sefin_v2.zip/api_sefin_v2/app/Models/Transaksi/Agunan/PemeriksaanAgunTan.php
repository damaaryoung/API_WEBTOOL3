<?php

namespace App\Models\Transaksi\Agunan;

use Illuminate\Auth\Authenticatable;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Database\Eloquent\Model;
use Laravel\Lumen\Auth\Authorizable;

// Relationship
use App\Models\Transaksi\Transaksi;

class PemeriksaanAgunTan extends Model implements AuthenticatableContract, AuthorizableContract
{
    use Authenticatable, Authorizable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $connection = 'web';

    protected $table = 'periksa_agunan_tanah';
    protected $primaryKey = 'id';

    protected $fillable = [
        'nama_penghuni', 'status_penghuni', 'bentuk_bangunan', 'kondisi_bangunan', 'fasilitas', 'listrik', 'nilai_taksasi_agunan', 'nilai_taksasi_bangunan', 'tgl_taksasi', 'nilai_likuidasi', 'nilai_agunan_independen', 'perusahaan_penilai_independen', 'id_transaksi'
    ];

    protected $casts = [
        'id'                     => 'integer',
        'nilai_taksasi_agunan'   => 'integer',
        'nilai_taksasi_bangunan' => 'integer',
        'id_transaksi'           => 'integer'
    ];

    public $timestamps = false;

    public function transaksi(){
        return $this->belongsTo(Transaksi::class, 'id_transaksi')
            ->withDefault(function () {
                return new Transaksi();
            });
    }
}
