<?php

namespace App\Models\Transaksi;

use Illuminate\Auth\Authenticatable;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Database\Eloquent\Model;
use Laravel\Lumen\Auth\Authorizable;

// Relationship
use App\Models\Transaksi\TransAO;

use App\Models\Master\PIC;
use App\Models\Master\Area;
use App\Models\Master\Cabang;
use App\Models\Master\AsalData;

class Transaksi extends Model implements AuthenticatableContract, AuthorizableContract
{
    use Authenticatable, Authorizable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $connection = 'web';

    protected $table = 'tb_transaksi';
    protected $primaryKey = 'id';

    protected $fillable = [
        'nomor_transaksi', 'id_asal_data', 'nama_marketing', 'id_pic_so', 'id_pic_das', 'id_pic_hm', 'id_pic_ao', 'id_pic_ca', 'id_pic_caa', 'id_pic_approval', 'id_area', 'id_cabang', 'status_das', 'catatan_das', 'status_hm', 'catatan_hm', 'status_ao', 'catatan_ao', 'status_ca', 'catatan_ca', 'status_caa', 'catatan_caa', 'status_approval', 'lamp_ideb', 'lamp_pefindo', 'form_persetujuan_ideb', 'flg_aktif', 'tgl_so', 'tgl_das', 'tgl_hm', 'tgl_ao', 'tgl_ca', 'tgl_caa', 'tgl_approval', 'tgl_rencana_cair'
     ];

     public $timestamps = false;

    protected $casts = [
        'id'            	=> 'integer',
        'id_asal_data'      => 'integer',
        'id_pic_so'         => 'integer',
        'id_pic_das'        => 'integer',
        'id_pic_hm'       	=> 'integer',
        'id_pic_ao'     	=> 'integer',
        'id_pic_ca'        	=> 'integer',
        'id_pic_caa'        => 'integer',
        'id_pic_approval'  	=> 'integer',
        'id_area'  			=> 'integer',
        'id_cabang'  		=> 'integer',
        'flg_aktif'  		=> 'boolean',
        'tgl_so'  			=> 'date:m-d-Y H:i:s',
        'tgl_das'           => 'date:m-d-Y H:i:s',
        'tgl_hm'            => 'date:m-d-Y H:i:s',
        'tgl_ao'  			=> 'date:m-d-Y H:i:s',
        'tgl_ca'  			=> 'date:m-d-Y H:i:s',
        'tgl_caa'  			=> 'date:m-d-Y H:i:s',
        'tgl_approval'  	=> 'date:m-d-Y H:i:s',
        'tgl_rencana_cair'  => 'date:m-d-Y H:i:s'
    ];

    public function asaldata(){
        return $this->belongsTo(AsalData::class, 'id_asal_data')
            ->withDefault(function () {
                return new AsalData();
            });
    }

    public function pic_so(){
        return $this->belongsTo(PIC::class, 'id_pic_so')
            ->withDefault(function () {
                return new PIC();
            });
    }

    public function pic_das(){
        return $this->belongsTo(PIC::class, 'id_pic_das')
            ->withDefault(function () {
                return new PIC();
            });
    }

    public function pic_hm(){
        return $this->belongsTo(PIC::class, 'id_pic_hm')
            ->withDefault(function () {
                return new PIC();
            });
    }

    public function pic_ao(){
        return $this->belongsTo(PIC::class, 'id_pic_ao')
            ->withDefault(function () {
                return new PIC();
            });
    }

    public function pic_ca(){
        return $this->belongsTo(PIC::class, 'id_pic_ca')
            ->withDefault(function () {
                return new PIC();
            });
    }

    public function pic_caa(){
        return $this->belongsTo(PIC::class, 'id_pic_caa')
            ->withDefault(function () {
                return new PIC();
            });
    }

    public function pic_approval(){
        return $this->belongsTo(PIC::class, 'id_pic_approval')
            ->withDefault(function () {
                return new PIC();
            });
    }

    public function area(){
        return $this->belongsTo(Area::class, 'id_area')
            ->withDefault(function () {
                return new Area();
            });
    }

    public function cabang(){
        return $this->belongsTo(Cabang::class, 'id_cabang')
            ->withDefault(function () {
                return new Cabang();
            });
    }
}
