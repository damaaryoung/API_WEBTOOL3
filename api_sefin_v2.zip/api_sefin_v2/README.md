## __RestAPI New Web Tool__
-------------------------------------

1 *open documentation to get __endPoint__ in google sheet* in [google sheet](https://docs.google.com/spreadsheets/d/1AGmod0OzPZA5B6D4CSoND3r0uRyzM7IXqRsulJcW-xw/edit?usp=sharing)

2 import *Collection* __POSTMAN__ from link in [google sheet](https://docs.google.com/spreadsheets/d/1AGmod0OzPZA5B6D4CSoND3r0uRyzM7IXqRsulJcW-xw/edit?usp=sharing)

3 My Local Base_URL: [192.168.1.38:4100](192.168.1.38:4100)

4 **Login**
> with user from **dpm_online**

> * user
> * password

5 get __token__ after login & insert to Header
> *Authorization* : _Bearer_ __{token}__
